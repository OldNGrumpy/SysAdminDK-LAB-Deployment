﻿# Version 1.0
# Author: Truesec Cyber Security Incident Response Team

# Prevent accidental execution
Break

# Import this module before running any of the commands later in this file
Import-Module C:\<PATH>\ADTiering\TSxTieringModule\TSxTieringModule.psm1 -Force -Verbose

<# -AccountName: When the user is created it will add T0, T1, T2 or TE as a suffix for the account, so Bob Builder will be admbobu in the commandline, 
   but the account will be named admbobut0 when created.
   -FirstName is the name of the user, like "Bob"
   -LastName is the surname, like "Builder"
   -AccountType is the tier, like T0 for tier 0
   -Prefix is ADM unless specified. Prefixes the account name like "admbobu" and the full name like "[ADM] Bob Builder"
   -Suffix is empty unless specified. Suffixes only the description, like "[ADM] Bob Builder [EXT]"
   -AccountName is admin account logon name. Will be generated with prefix, first 2 letters of first name, 2 first letters of last name unless specified here. Account name is always suffixed with tier, even when specified.
   -UPNDomain is the logon name Userprincialname domain. Unless specfied the domain dns name is used.
   -AddToSilo $true will add the user account to the correct tier silo when creating the account
   In general, the shortname in the command will be the same for a user that needs all 4 tiers on the command, like you see in the sample below.
#>

$FirstName = 'Mikael'
$LastName = 'Nystrom'
$Prefix = 'ADM'
$Suffix = 'EXT'

New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType T0 -Prefix $Prefix -Suffix $Suffix -AddToSilo $false -Verbose
New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType T1 -Prefix $Prefix -Suffix $Suffix -AddToSilo $false -Verbose
New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType TE -Prefix $Prefix -Suffix $Suffix -AddToSilo $false -Verbose
New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType Con -Prefix $Prefix -Suffix $Suffix -AddToSilo $false -Verbose

$FirstName = 'John'
$LastName = 'Doe'
$Prefix = 'ADM'
$Suffix = 'FTE'
$AccountName = 'admjohdoe'
$UPNDomain = 'example.com'

New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType T1 -Prefix $Prefix -Suffix $Suffix -AccountName $AccountName -AddToSilo $false -Verbose

New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType T0 -Prefix $Prefix -Suffix $Suffix -AccountName $AccountName -AddToSilo $true -Verbose
New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType T1 -Prefix $Prefix -Suffix $Suffix -AccountName $AccountName -AddToSilo $false -Verbose
New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType TE -Prefix $Prefix -Suffix $Suffix -AccountName $AccountName -AddToSilo $false -Verbose
New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType Con -Prefix $Prefix -Suffix $Suffix -AccountName $AccountName -UPNDomain $UPNDomain -AddToSilo $false -Verbose


$FirstName = 'Putte'
$LastName = 'Nystrom'
$Prefix = 'ADM'
$Suffix = 'EXT'

New-TSxAdminAccount -FirstName $FirstName -LastName $LastName -AccountType T1L -Prefix $Prefix -Suffix $Suffix -AddToSilo $false -Verbose

Set-TSxAdminADAuthenticationPolicySiloForComputer -ADComputerIdentity MGMT01 -Tier T0
Set-TSxAdminADAuthenticationPolicySiloForUser -ADUserIdentity ADMMINYT0 -Tier T0


<# Create new Service Accounts
   Not specifying AccountName will genererate a user name with the accountype and first 3 letter in the FirstName and 3 first in the LastName
   Example: t0svcserexa
   
   If LastName is not specified the FirstName will be used as the AccountName

   AccountName will be used as is. No characters added or removed.

   UserType is either a normal user account "User" or a group managed service account "gMSA" which is always prefered if the service supports it.
#>

# Tier 0
$FirstName = 'ServiceAccount IAM'
$LastName = 'ExampleIAMServer'
$UserType = 'User'

New-TSxServiceAccount -FirstName $FirstName -LastName $LastName -AccountType T0SVC -UserType $UserType

# Tier 1
$FirstName = 'ServiceAccount SQLServer'
$LastName = 'ExampleSQLServer1'
$UserType = 'gMSA'
$AccountName = 'svcsqlsrv01'

New-TSxServiceAccount -FirstName $FirstName -LastName $LastName -AccountType T1SVC -UserType $UserType -AccountName $AccountName

# Tier 2
$FirstName = 'ServiceAccount SQLServer'
$LastName = 'ExampleSQLServer2'
$UserType = 'gMSA'
$AccountName = 'svcsqlsrv02'

New-TSxServiceAccount -FirstName $FirstName -LastName $LastName -AccountType T2SVC -UserType $UserType -AccountName $AccountName

# Tier Endpoints
$FirstName = 'tesvcdevmgmt'
$UserType = 'User'
$UPNDomain = 'example.com'

New-TSxServiceAccount -FirstName $FirstName -AccountType TESVC -UserType $UserType -UPNDomain $UPNDomain


# Create new OUs in Admin Tier
# Variables
$TierOUName = 'Admin'
$CompanyName = 'Customer'

# Create OU in Tier T0 
New-TSxSubOU -Tier T0 -Name 'ExampleServers' -Description 'Tier0 ExampleServers' -TierOUName $TierOUName -CompanyName $CompanyName -Cleanup

# Create OU in Tier T1 
New-TSxSubOU -Tier T1 -Name 'ExampleServers' -Description 'Tier1 ExampleServers' -TierOUName $TierOUName -CompanyName $CompanyName -WindowsLAPSOnly -Cleanup

# Create OU in Tier TE 
New-TSxSubOU -Tier TE -Name 'ExampleEndpoints' -Description 'TierEndpoint ExampleEndpoints' -TierOUName $TierOUName -CompanyName $CompanyName -Cleanup
