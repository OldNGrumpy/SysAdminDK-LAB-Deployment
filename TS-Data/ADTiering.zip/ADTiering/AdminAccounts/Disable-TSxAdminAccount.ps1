﻿# Disable Admin Accounts
Param(
    $Identity
)

# Find the PDC
$PDC = (Get-ADForest | Select-Object -ExpandProperty RootDomain | Get-ADDomain | Select-Object -Property PDCEmulator).PDCEmulator

# Find the admin account
$ADUserAccount = Get-ADUser -Identity $Identity -Server $PDC
Write-Verbose "Selected AdminAccount is $($ADUserAccount.SamAccountName)" -Verbose

# Cleanup group membership
$GroupMemberShip = $ADUserAccount | Get-ADPrincipalGroupMembership  -Server $PDC
foreach($Group in $GroupMemberShip | Where-Object SID -NotLike *-513){

    # Remove from groups
    Write-Verbose "Remove from groups" -Verbose
    Remove-ADGroupMember -Identity $Group -Members $ADUserAccount -Verbose -Confirm: $false
}

# Generate a new password
Write-Verbose "Generate a new password" -Verbose
$SecureString = ConvertTo-SecureString -String $((New-Guid).Guid + "T-REX!!##%%") -AsPlainText -Force

# Set PasswordNeverExpires
Write-Verbose "Generate a new password" -Verbose
Get-ADUser $ADUserAccount | Set-ADUser -PasswordNeverExpires:$false -Server $PDC

# Set ChangePasswordAtLogon
Write-Verbose "Set ChangePasswordAtLogon" -Verbose
Get-ADUser $ADUserAccount | Set-ADUser -ChangePasswordAtLogon:$true -Server $PDC

# Set AccountExpirationDate
Write-Verbose "Set AccountExpirationDate" -Verbose
Get-ADUser $ADUserAccount | Set-ADUser -AccountExpirationDate (Get-Date).AddDays(-1) -Server $PDC

# Set new password
Write-Verbose "Set new password" -Verbose
Set-ADAccountPassword -Identity $ADUserAccount -Reset -NewPassword $SecureString -Server $PDC

# Disable Account
Write-Verbose "Disable Account" -Verbose
Get-ADUser $ADUserAccount | Set-ADUser -Enabled:$false -Server $PDC
