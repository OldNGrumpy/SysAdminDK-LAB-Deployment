<#
.SYNOPSIS
Delegates admin permission to Domain Legacy XXX Admins groups to non-tiered Active Directory Structure

.DESCRIPTION

.PARAMETER ComputerOrganizationalUnits
Single or array of organizational units with computer objects

.PARAMETER GroupOrganizationalUnits
Single or array of organizational units with group objects

.PARAMETER UserOrganizationalUnits
Single or array of organizational units with user objects

.PARAMETER GPOPrefix
The prefix to use for the GPOs created. The GPOs will be named GPOPrefix - GPOName
Default: Admin

.PARAMETER SkipLAPS
Skips delegation of AdmPwd and WindowsLAPS read permissions

.PARAMETER WindowsLAPSOnly
Only sets permissions and delegations for WindowsLAPS. LegacyLAPS is not required.

.PARAMETER Server
Choose which domain controller to use for the operations

.EXAMPLE
Add-TSxLegacyAdminPermissions.ps1
Will prompt for each of the computer, group and user organizational units. Only organizational units
containing the respective objects types will be shown.
.EXAMPLE
Add-TSxLegacyAdminPermissions.ps1 -ComputerOrganizationalUnits 'OU=Computers,OU=Company,DC=example,DC=com','OU=Servers,OU=Company,DC=example,DC=com'
Will use specified computer organizational units and will prompt for group and user organizational units

.NOTES
FileName: Add-TSxLegacyAdminPermissions.ps1
Author: Truesec Cyber Security Incident Response Team

Version
1.0.0 - 2023-10-06
1.0.1 - 2024-08-27
1.1.0 - 2024-10-24

License Info:
MIT License
Copyright (c) 2024 Truesec

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the \"Software\"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
#>
#requires -RunAsAdministrator
#requires -Modules ActiveDirectory, GroupPolicy

[CmdletBinding()]
Param(
  [Parameter(Position=0)]
    $ComputerOrganizationalUnits,
  [Parameter(Position=1)]
    $GroupOrganizationalUnits,
  [Parameter(Position=2)]
    $UserOrganizationalUnits,
  [string]$GPOPrefix = 'Admin',
  [switch]$SkipLAPS,
  [switch]$WindowsLAPSOnly,
  [string]$Server
)

# Import TSxADTieringModule. Exit if it can't.
if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\..\TSxTieringModule\TSxTieringModule.psm1" -ErrorAction SilentlyContinue) {
  Import-Module "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\..\TSxTieringModule\TSxTieringModule.psm1" -Force
  Write-Verbose 'Imported functions from TSxADTieringModule'
}
else {
  Throw "Could not read the required file:""$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\..\TSxTieringModule\TSxADTieringModule.psm1""."
}

# Verify chosen server responds. Otherwise choose the PDC or another server that responds
if ($Server) {
  $SpecifiedServer = $Server
  $Server = Get-TSxVerifiedDomainController -Server $Server
}
else {
  $Server = Get-TSxVerifiedDomainController
}
if ($Server -eq $false) {
  Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
}
if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
  Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
}

# Check if existing tiering group policy exist and exit if they use different prefix
$existingprefix = Get-TSxGPOPrefix -Server $Server
if ($existingprefix -ne 'DoesNotExist' -and $existingprefix -ne $GPOPrefix) {
  Throw "Existing GPOs with prefix $existingprefix found. Rerun script with -GPOPrefix $existingprefix or remove existing GPOs"
}

# Get domain distinguished name and domaincontroller OU
$ADDomain = Get-ADDomain
$DomainDN = $ADDomain.DistinguishedName
$DCOU = $ADDomain.DomainControllersContainer

# Get a list of root OU.s except the Admin and CompanyName OU.s
$RootOUs = Get-ChildItem AD:$DomainDN -Server $Server | Where-Object {$_.ObjectClass -eq 'organizationalUnit' -and $_.DistinguishedName -ne $DCOU}
foreach ($RootOU in $RootOUs) {
  $OU = Get-ChildItem AD:$RootOU -Server $Server
  if ($OU.Name -contains 'Tier0') {
    $AdminOU = $RootOU
  }
  if ($OU.Name -contains 'ComputerQuarantine') {
    $CompanyOU = $RootOU
  }
}
$RootOUs = $RootOUs | Where-Object {$_.DistinguishedName -ne $AdminOU -and $_.DistinguishedName -ne $CompanyOU}

# If no computer organizational units has been specified. Get a list of OU.s with computer objects and present them with out-gridview.
if (!($ComputerOrganizationalUnits)) {
  $ComputerOUs = @()
  $ComputerOUsObject = @()
  foreach ($RootOU in $RootOUs) {
    $ComputerOUs += Get-ADComputer -Filter * -SearchBase $RootOU -Properties cn -Server $Server | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.cn),"}} -Unique
  }
  foreach ($ComputerOU in $ComputerOUs) {
    $OUDNLength = $ComputerOU.OU.Length
    $NoDomainOU = $ComputerOU.OU -replace ",$DomainDN",''
    $SplitOU = ($NoDomainOU -split ',')
    $SplitOUCount = $SplitOU.Count
    $SplitOULastCount = $SplitOUCount - 1
    $RootOU = $SplitOU[$SplitOULastCount]
    $RootOU = $RootOU -replace 'OU=',''
    $ParentOU = $ComputerOU.OU -replace "$($SplitOU[0]),",''
    $object = [PSCustomObject]@{
      'OU' = $ComputerOU.OU
      'RootOU' = $RootOU
      'OUDNLength' = $OUDNLength
      'ParentOU' = $ParentOU
    }
    $ComputerOUsObject += $object
    if ($ParentOU -like '*OU=*' -and $ComputerOUsObject.OU -notcontains $ParentOU) {
      $OUDNLength = $ParentOU.Length
      $ParentParentOU = $ParentOU -replace "$($SplitOU[1]),",''
      $object = [PSCustomObject]@{
        'OU' = $ParentOU
        'RootOU' = $RootOU
        'OUDNLength' = $OUDNLength
        'ParentOU' = $ParentParentOU
      }
      $ComputerOUsObject += $object
    }
  }
  Write-Output 'Choose which OUs to delegate LAPS read, computer object and local admin permissions to:' ''
  $SelectedComputerOUs = $ComputerOUsObject | Sort-Object -Property @{Expression={$_.RootOU}}, @{Expression={[int]$_.OUDNLength}}, @{Expression={$_.ParentOU}} | Select-Object OU | Out-GridView -Title 'Choose OUs to delegate Computer admin permissions for "Domain Legacy Computer Admins" group. Cancel to skip!' -OutputMode Multiple
}
else {
  $SelectedComputerOUs = New-Object System.Collections.Generic.List[object]
  foreach ($ComputerOrganizationalUnit in $ComputerOrganizationalUnits) {
    $ComputerOUObject = [PSCustomObject]@{
      OU = $ComputerOrganizationalUnit
    }
    $SelectedComputerOUs += $ComputerOUObject
  }
}


# If no group organizational units has been specified. Get a list of OU.s with group objects and present them with out-gridview.
if (!($GroupOrganizationalUnits)) {
  $GroupOUs = @()
  $GroupOUsObject = @()
  foreach ($RootOU in $RootOUs) {
    $GroupOUs += Get-ADGroup -Filter * -SearchBase $RootOU -Properties cn -Server $Server | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.cn),"}} -Unique | Sort-Object OU
  }
  foreach ($GroupOU in $GroupOUs) {
    $OUDNLength = $GroupOU.OU.Length
    $NoDomainOU = $GroupOU.OU -replace ",$DomainDN",''
    $SplitOU = ($NoDomainOU -split ',')
    $SplitOUCount = $SplitOU.Count
    $SplitOULastCount = $SplitOUCount - 1
    $RootOU = $SplitOU[$SplitOULastCount]
    $RootOU = $RootOU -replace 'OU=',''
    $ParentOU = $GroupOU.OU -replace "$($SplitOU[0]),",''
    $object = [PSCustomObject]@{
      'OU' = $GroupOU.OU
      'RootOU' = $RootOU
      'OUDNLength' = $OUDNLength
      'ParentOU' = $ParentOU
    }
    $GroupOUsObject += $object
    if ($ParentOU -like '*OU=*' -and $GroupOUsObject.OU -notcontains $ParentOU) {
      $OUDNLength = $ParentOU.Length
      $ParentParentOU = $ParentOU -replace "$($SplitOU[1]),",''
      $object = [PSCustomObject]@{
        'OU' = $ParentOU
        'RootOU' = $RootOU
        'OUDNLength' = $OUDNLength
        'ParentOU' = $ParentParentOU
      }
      $GroupOUsObject += $object
    }
  }
  Write-Output 'Choose which OUs to delegate group object permissions to:' ''
  $SelectedGroupOUs = $GroupOUsObject | Sort-Object -Property @{Expression={$_.RootOU}}, @{Expression={[int]$_.OUDNLength}}, @{Expression={$_.ParentOU}} | Select-Object OU | Out-GridView -Title 'Choose OUs to delegate group admin permissions for "Domain Legacy Group Admins" group. Cancel to skip!' -OutputMode Multiple
}
else {
  $SelectedGroupOUs = New-Object System.Collections.Generic.List[object]
  foreach ($GroupOrganizationalUnit in $GroupOrganizationalUnits) {
    $GroupOUObject = [PSCustomObject]@{
      OU = $GroupOrganizationalUnit
    }
    $SelectedGroupOUs += $GroupOUObject
  }
}

# If no user organizational units has been specified. Get a list of OU.s with user objects and present them with out-gridview.
if (!($UserOrganizationalUnits)) {
  $UserOUs = @()
  $UserOUsObject = @()
  foreach ($RootOU in $RootOUs) {
    $UserOUs += Get-ADUser -Filter * -SearchBase $RootOU -Properties cn -Server $Server | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.cn),"}} -Unique | Sort-Object OU
  }
  foreach ($UserOU in $UserOUs) {
    $OUDNLength = $UserOU.OU.Length
    $NoDomainOU = $UserOU.OU -replace ",$DomainDN",''
    $SplitOU = ($NoDomainOU -split ',')
    $SplitOUCount = $SplitOU.Count
    $SplitOULastCount = $SplitOUCount - 1
    $RootOU = $SplitOU[$SplitOULastCount]
    $RootOU = $RootOU -replace 'OU=',''
    $ParentOU = $UserOU.OU -replace "$($SplitOU[0]),",''
    $object = [PSCustomObject]@{
      'OU' = $UserOU.OU
      'RootOU' = $RootOU
      'OUDNLength' = $OUDNLength
      'ParentOU' = $ParentOU
    }
    $UserOUsObject += $object
    if ($ParentOU -like '*OU=*' -and $UserOUsObject.OU -notcontains $ParentOU) {
      $OUDNLength = $ParentOU.Length
      $ParentParentOU = $ParentOU -replace "$($SplitOU[1]),",''
      $object = [PSCustomObject]@{
        'OU' = $ParentOU
        'RootOU' = $RootOU
        'OUDNLength' = $OUDNLength
        'ParentOU' = $ParentParentOU
      }
      $UserOUsObject += $object
    }
  }
  Write-Output 'Choose which OUs to delegate user object permissions to:' ''
  $SelectedUserOUs = $UserOUsObject | Sort-Object -Property @{Expression={$_.RootOU}}, @{Expression={[int]$_.OUDNLength}}, @{Expression={$_.ParentOU}} | Select-Object OU | Out-GridView -Title 'Choose OUs to delegate user admin permissions for "Domain Legacy User Admins" group. Cancel to skip!' -OutputMode Multiple
}
else {
  $SelectedUserOUs = New-Object System.Collections.Generic.List[object]
  foreach ($UserOrganizationalUnit in $UserOrganizationalUnits) {
    $UserOUObject = [PSCustomObject]@{
      OU = $UserOrganizationalUnit
    }
    $SelectedUserOUs += $UserOUObject
  }
}

# If selected computer organizational units exist. Add legacy computer admin permissions to legacy admin group
if ($SelectedComputerOUs) {
  foreach ($SelectedComputerOU in $SelectedComputerOUs) {
    Write-Output "Delegating computer object permissions and local admin access for $($SelectedComputerOU.OU)"
    Add-TSxLegacyComputerAdminPermissions -OrganizationalUnitDN $SelectedComputerOU.OU -GPOPrefix $GPOPrefix -SkipLAPS:$SkipLAPS -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference
  }
}
else {
  Write-Warning 'Either no organizational units with computer objects outside the tiering structure was found or user chose no organizational units to delegate permissions to.'
}

# If selected group organizational units exist. Add legacy group admin permissions to legacy admin group
if ($SelectedGroupOUs) {
  foreach ($SelectedGroupOU in $SelectedGroupOUs) {
    Write-Output "Delegating group object permissions for $($SelectedGroupOU.OU)"
    Add-TSxLegacyGroupAdminPermissions -OrganizationalUnitDN $SelectedGroupOU.OU -Server $Server -Verbose:$VerbosePreference
  }
}
else {
  Write-Warning 'Either no organizational units with group objects outside the tiering structure was found or user chose no organizational units to delegate permissions to.'
}

# If selected user organizational units exist. Add legacy user admin permissions to legacy admin group
if ($SelectedUserOUs) {
  foreach ($SelectedUserOU in $SelectedUserOUs) {
    Write-Output "Delegating user object permissions for $($SelectedUserOU.OU)"
    Add-TSxLegacyUserAdminPermissions -OrganizationalUnitDN $SelectedUserOU.OU -Server $Server -Verbose:$VerbosePreference
  }
}
else {
  Write-Warning 'Either no organizational units with user objects outside the tiering structure was found or user chose no organizational units to delegate permissions to.'
}
