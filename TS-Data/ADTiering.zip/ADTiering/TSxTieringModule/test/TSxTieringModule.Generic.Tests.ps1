BeforeDiscovery {
    $ModulePath = (get-item $PSScriptRoot ).parent.FullName
    $Script = Get-ChildItem -Path $ModulePath -Filter *.ps1 -Recurse | Where-Object { $_.Name -notlike "*.tests.ps1" }

}
BeforeAll {
    $ModulePath = (get-item $PSScriptRoot ).parent.FullName
    $ModuleManifestPath = Get-ChildItem -Path $ModulePath -Filter *.psd1
    $ModuleName = (get-item $PSScriptRoot ).parent.Name

}
#$testCase = $Script | Foreach-Object { @{file = $_ } }


Describe 'PSParser analysis' {

    It "Script <_> should be valid powershell" -ForEach $Script {
 
        $contents = Get-Content -Path $_.FullName -ErrorAction Stop
        $errors = $null
        $null = [System.Management.Automation.PSParser]::Tokenize($contents, [ref]$errors)
        $errors.Count | Should -Be 0
    }

}


Describe "Validate module manifest" {
    It 'Passes Test-ModuleManifest' {
        (Test-ModuleManifest -Path $ModuleManifestPath).Name | Should -Be $ModuleName
    }

    It "Module '$ModuleName' should import" {

        Import-Module  $ModuleManifestPath -force  | Should -Be $Null
    }
}




Describe 'PSScriptAnalyzer analysis' {
    It "<Filename> Should not violate: <IncludeRule>" -ForEach @(
        Foreach ($file in $Script) {
            Foreach ($r in (Get-ScriptAnalyzerRule | Where-Object { $_.RuleName -notlike "PSDSC*" })) {
                @{
                    IncludeRule = $r.RuleName
                    Path        = $file.FullName
                    FileName    = $file.Name
                }
            }
        }
    ) {
        param($IncludeRule, $Path, $FileName)
        
        $result = Invoke-ScriptAnalyzer -Path $Path -IncludeRule $IncludeRule

        if ($null -ne $result) {
            Write-Host "  [-] $($FileName) Fails  $($IncludeRule)" -ForegroundColor Cyan
            $result | ForEach-Object {
                Write-Host "      [Line $($_.Extent.StartLineNumber)]   $($_.Message)" -ForegroundColor Yellow
            }
        }
        
        $result | Should -BeNullOrEmpty
    }
}


