﻿Function New-TSxADOrganizationalUnit {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$Name,
    [Parameter(Position=1,Mandatory)]
      [string]$Path,
    [string]$Description,
    [string]$Server,
    [switch]$NoOut
  )
  #requires -Modules ActiveDirectory
  
  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Set erroraction preference to SilentlyContinue and then try to get organizational unit, otherwise create a new organizational unit and return object unless NoOut is set
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  $object = Get-ADOrganizationalUnit -Identity "OU=$Name,$Path" -Properties Description -Server $Server
  $ErrorActionPreference = $EAP
  if ($object) {
    Write-Verbose "OU: ""$Name"" exists and will be used."
    if (!$NoOut) {
      return $object
    }
  }
  else {
    # Create new organizational unit and verify it exists before returning the organizational unit as an object
    Try {
      New-ADOrganizationalUnit -Name $Name -Path $Path -Description $Description -Server $Server -ErrorAction Stop
      Write-Verbose "Created OU $Name in $Path."
    }
    Catch {
      Write-Error "Could not create OU $Name in $Path. Error: $($_.Exception.Message)"
      return $null
    }
    Do {
      $EAP = $ErrorActionPreference
      $ErrorActionPreference = 'SilentlyContinue'
      $success = Get-ADOrganizationalUnit -Identity "OU=$Name,$Path" -Properties Description -Server $Server
      if (!($success)) {
        Start-Sleep -Seconds 1
      }
    } Until ($success)
    $ErrorActionPreference = $EAP
    if (!$NoOut) {
      return $success
    }
  }
}
