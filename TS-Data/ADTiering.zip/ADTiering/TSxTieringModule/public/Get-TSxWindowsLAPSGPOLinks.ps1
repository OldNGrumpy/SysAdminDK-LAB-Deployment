Function Get-TSxWindowsLAPSGPOLinks {
  [CmdletBinding()]
  Param (
    [Parameter(Position=0,Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
      [string]$Identity,
    [string]$GPOPrefix='Admin',
    [string]$Server
  )
  #requires -Modules GroupPolicy

  # Set variables
  $GPOLinks = @()
  
  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  # Get all tiering LAPS GPOs
  $GPOs = Get-GPO -All -Server $Server | Where-Object {$_.DisplayName -like "$GPOPrefix - WindowsLAPS*"}

  # Get all LAPS GPO links for the specified organizational units
  $OrganizationalUnits = Get-ADOrganizationalUnit -Filter * -SearchBase $Identity -Server $Server
  foreach ($GPO in $GPOs) {
    $GPOLinks += ($OrganizationalUnits | Get-GPInheritance -Server $Server).GpoLinks | Where-Object GpoId -eq $GPO.Id
  }

  if ($GPOLinks) {
    return $GPOLinks
  }
  else {
    return $false;
  }
}
