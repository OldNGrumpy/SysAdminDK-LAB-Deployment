﻿Function New-TSxAuthenticationPolicy{
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [ValidateSet('T0','T1','T1Limited','T2','T2Limited','TP')]
      [string]$Tier,
    [switch]$ReturnObject,
    [string]$Server
  )
  #requires -Modules ActiveDirectory

  # Set variables
  $Path = $PSScriptRoot
  if ($Path -like '*TSxTieringModule\public') {
    $Path = $Path.Replace('TSxTieringModule\public','')
  }
  if ($Path -like '*TSxTieringModule\private') {
    $Path = $Path.Replace('TSxTieringModule\private','')
  }
  $Path = $Path.TrimEnd('\')
  $ADDomain = Get-ADDomain
  $ForestDomain = (Get-ADDomain -Identity $ADDomain.Forest)
  $ForestDomainSID = $ForestDomain.DomainSid.Value

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Create the authentication policy and verify it's created successfully before continuing
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  $ADAuth = Get-ADAuthenticationPolicy -Identity "1hr_$($Tier)Admin_TGT" -Server $Server -ErrorAction SilentlyContinue
  $ErrorActionPreference = $EAP
  if (!$ADAuth) {
    if ([System.Security.Principal.WindowsIdentity]::GetCurrent().Groups -contains "$ForestDomainSID-512") {
      Try {
        New-ADAuthenticationPolicy -Name "1hr_$($Tier)Admin_TGT" -Description "1hr_$($Tier)Admin_TGT" -UserTGTLifetimeMins 60 -ProtectedFromAccidentalDeletion $true -Server $Server -ErrorAction Stop
        Write-Verbose "Created authentication policy 1hr_$($Tier)Admin_TGT"
        Do {
          $EAP = $ErrorActionPreference
          $ErrorActionPreference = 'SilentlyContinue'
          $AuthPolicy = Get-ADAuthenticationPolicy -Identity "1hr_$($Tier)Admin_TGT" -Server $Server
          if (!($AuthPolicy)) {
            Start-Sleep -Seconds 2
          }
        } Until ($AuthPolicy)
        $ErrorActionPreference = $EAP
      }
      Catch {
        Write-Error "Unable to create Authentication Policy 1hr_$($Tier)Admin_TGT. ErrorMessage: $($_.Exception.Message)" -Verbose
        $ErrorActionPreference = $EAP
        return $null
      }
    }
    else {
      "New-ADAuthenticationPolicy -Name ""1hr_$($Tier)Admin_TGT"" -Description ""1hr_$($Tier)Admin_TGT"" -UserTGTLifetimeMins 60 -ProtectedFromAccidentalDeletion `$true" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
      "New-ADAuthenticationPolicySilo -Name ""Restricted_$($Tier)Admin_Logon"" -Description ""Restricted_$($Tier)Admin_Logon"" -UserAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ComputerAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ServiceAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ProtectedFromAccidentalDeletion `$true`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
      Write-Error "Only Domains Admins in the forest root domain can create Authentication Policies.`nRun:`nNew-ADAuthenticationPolicy -Name ""1hr_$($Tier)Admin_TGT"" -Description ""1hr_$($Tier)Admin_TGT"" -UserTGTLifetimeMins 60 -ProtectedFromAccidentalDeletion `$true`nin forest root domain."
      return $null
    }
  }
  
  # Create the authentication policy silo and verify it's created successfully before continuing
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  $ADAuthSilo = Get-ADAuthenticationPolicySilo -Identity "Restricted_$($Tier)Admin_Logon" -Server $Server -ErrorAction SilentlyContinue
  $ErrorActionPreference = $EAP
  if (!$ADAuthsilo) {
    if ([System.Security.Principal.WindowsIdentity]::GetCurrent().Groups -contains "$ForestDomainSID-512") {    
      Try {
        New-ADAuthenticationPolicySilo -Name "Restricted_$($Tier)Admin_Logon" -Description "Restricted_$($Tier)Admin_Logon" -UserAuthenticationPolicy "1hr_$($Tier)Admin_TGT" -ComputerAuthenticationPolicy "1hr_$($Tier)Admin_TGT" -ServiceAuthenticationPolicy "1hr_$($Tier)Admin_TGT" -ProtectedFromAccidentalDeletion $true -Server $Server -ErrorAction Stop
        Write-Verbose "Created authentication policy silo Restricted_$($Tier)Admin_Logon"
        Do {
          $EAP = $ErrorActionPreference
          $ErrorActionPreference = 'SilentlyContinue'
          $ADAuthSilo = Get-ADAuthenticationPolicySilo -Identity "Restricted_$($Tier)Admin_Logon" -Server $Server
          if (!($ADAuthSilo)) {
            Start-Sleep -Seconds 2
          }
        } Until ($ADAuthSilo)
        $ErrorActionPreference = $EAP
      }
      Catch {
        Write-Error "Unable to create Authentication Policy Silo Restricted_$($Tier)Admin_Logon. ErrorMessage: $($_.Exception.Message)" -Verbose
        $ErrorActionPreference = $EAP
        return $null
      }
    }
    else {
      "New-ADAuthenticationPolicySilo -Name ""Restricted_$($Tier)Admin_Logon"" -Description ""Restricted_$($Tier)Admin_Logon"" -UserAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ComputerAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ServiceAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ProtectedFromAccidentalDeletion `$true`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
      Write-Error "Only Domains Admins in the forest root domain can create Authentication Policy Silos.`nRun:`nNew-ADAuthenticationPolicySilo -Name ""Restricted_$($Tier)Admin_Logon"" -Description ""Restricted_$($Tier)Admin_Logon"" -UserAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ComputerAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ServiceAuthenticationPolicy ""1hr_$($Tier)Admin_TGT"" -ProtectedFromAccidentalDeletion `$true`nin forest root domain."
      return $null
    }
  }
  
  # Set computers users are allowed to authenticate from and enfore the policies
  Set-ADAuthenticationPolicy -Identity "1hr_$($Tier)Admin_TGT" -UserAllowedToAuthenticateFrom "O:SYG:SYD:(XA;OICI;CR;;;WD;(@USER.ad://ext/AuthenticationSilo == ""Restricted_$($Tier)Admin_Logon""))" -Enforce $true -UserAllowedNTLMNetworkAuthentication $true -Server $Server -ErrorAction Stop
  Set-ADAuthenticationPolicySilo -Identity "Restricted_$($Tier)Admin_Logon" -Enforce $true -Server $Server -ErrorAction Stop
  
  # Output object if specified
  if ($ReturnObject) {
    return $ADAuthSilo
  }
}
