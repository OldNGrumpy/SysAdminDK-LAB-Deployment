Function Set-TSxAdmPwdComputerSelfPermission {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$Identity,
    [switch]$WindowsLAPSOnly,
    [string]$Server
  )
  
  # Set variables
  $Path = $PSScriptRoot
  if ($Path -like '*TSxTieringModule\public') {
    $Path = $Path.Replace('TSxTieringModule\public','')
  }
  if ($Path -like '*TSxTieringModule\private') {
    $Path = $Path.Replace('TSxTieringModule\private','')
  }
  $Path = $Path.TrimEnd('\')

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Check if OS is WindowsLAPS capable
  $WindowsLAPSCapable = Get-TSxWindowsLAPSCapable -Verbose:$VerbosePreference
  
  # If WindowsLAPSOnly is not set, load legacy LAPS module
  if (!($WindowsLAPSOnly)) {
    if (Test-Path -Path "$Path\AdmPwd.PS\AdmPwd.PS.psd1" -ErrorAction SilentlyContinue) {
      Import-Module "$Path\AdmPwd.PS\AdmPwd.PS.psd1" -Force
    }
    else {
      Write-Error "Legacy LAPS powershell module required for legacy LAPS configuration. Make sure the AdmPwd.PS folder is in the same directory as the script."
      return;
    }
  }

  # Set erroraction preference to SilentlyContinue and then verify target organizational unit
  $i = 0
  Do {
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $success = Get-ADObject -Identity $Identity -Server $Server -ErrorAction SilentlyContinue | Where-Object {$_.ObjectClass -eq 'Container' -or $_.ObjectClass -eq 'organizationalUnit'}
    $i++
    if (!($success)) {
      Start-Sleep -Seconds 1
    }
  } Until ($success -or $i -gt 60)
  $ErrorActionPreference = $EAP

  if (!($success)) {
    Write-Error "$Identity does not exist!" -Verbose
    return;
  }
  
  # If OS i WindowsLAPS add LAPS read permissions to specified group under specified organizational unit
  if ($WindowsLAPSCapable) {
    if (Get-Module LAPS -ListAvailable) {
      Try {
        Set-LapsADComputerSelfPermission -Identity $Identity -DomainController $Server -ErrorAction Stop -Verbose:$false | Out-Null
        Write-Verbose "Set Windows LAPS self permissions in $Identity"
      }
      Catch {
        "Set-LapsADComputerSelfPermission -Identity ""$Identity""`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
        Write-Warning "Unable to assign Windows LAPS computer self permission! Run the following command manually:`nSet-LapsADComputerSelfPermission -Identity ""$Identity"""
      }
    }
  }

  # Unless WindowsLAPSOnly is set, add Legacy LAPS read permissions to specified group under specified organizational unit
  if (!($WindowsLAPSOnly)) {
    Try {
      Set-AdmPwdComputerSelfPermission -Identity $Identity -ErrorAction Stop -Verbose:$false | Out-Null
      Write-Verbose "Set legacy LAPS self permissions in $Identity"
    }
    Catch {
      "Set-AdmPwdComputerSelfPermission -Identity ""$Identity""`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
      Write-Warning "Unable to assign legacy LAPS computer self permission! Run the following command manually:`nSet-AdmPwdComputerSelfPermission -Identity ""$Identity"""
    }
  }
}
