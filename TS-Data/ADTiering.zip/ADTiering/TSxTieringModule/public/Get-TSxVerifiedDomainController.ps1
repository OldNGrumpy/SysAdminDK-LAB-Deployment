Function Get-TSxVerifiedDomainController {
  [CmdletBinding()]
  Param (
  [Parameter(Position=0)]
    [string]$Server
  )
  #requires -Modules ActiveDirectory

  # Reset counter parameter
  $i = 0

  # If server is not specified, use the Primary Domain Controller
  if (!($Server)) {
    $DomainController = (Get-ADDomain).PDCEmulator
  }
  else {
    $DomainController = $Server
  }

  # Check if server responds, otherwise choose another domain controller
  Do {
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $Response = Get-ADUser -Identity krbtgt -Server $DomainController -ErrorAction SilentlyContinue
    if (!($Response)) {
      $DomainController = (Get-ADDomainController).HostName
      Start-Sleep -Seconds 1
      $i++
    }
  }
  Until ($Response -or $i -ge 30)
  if ($Error.Count -ge 1) {
    $Error.Clear()
  }
  $ErrorActionPreference = $EAP
  
  # If the command is unable to get a response after 1 minute, return false
  if ($i -ge 30) {
    Write-Error "Unable to find a responding domain controller. Last tried $DomainController"
    return $false
  }
  else {
    return $DomainController
  }

}
