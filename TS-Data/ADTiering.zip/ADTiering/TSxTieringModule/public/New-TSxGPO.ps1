﻿Function New-TSxGPO {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$Name,
    [Parameter(Position=1)]
      [string]$Description = '',
    [string]$Server,
    [switch]$NoOut
  )
  #requires -Modules ActiveDirectory
   
  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  # Set erroraction preference to SilentlyContinue and then try to get group policy otherwise create a new group policy and return object unless NoOut is set
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  $object = Get-GPO -Name $Name -Server $Server
  $ErrorActionPreference = $EAP
  if ($object) {
    Write-Verbose "GPO: ""$Name"" already exists and will be used."
    if (!$NoOut) {
      return $object
    }
  }
  else {
    # Try to create new group policy and verify it exists before returning the group as an object
    Try {
      New-GPO -Name $Name -Comment $Description -Server $Server -ErrorAction Stop | Out-Null
      Write-Verbose "Created GPO $Name"
    }
    Catch {
      Write-Error "Could not create GPO $Name. Error: $($_.Exception.Message)"
      return $null
    }
    Do {
      $EAP = $ErrorActionPreference
      $ErrorActionPreference = 'SilentlyContinue'
      $success = Get-GPO -Name $Name -Server $Server -ErrorAction SilentlyContinue
      if (!($success)) {
        Start-Sleep -Seconds 1
      }
    } Until ($success)
    $ErrorActionPreference = $EAP
    if (!$NoOut) {
      return $success
    }
  }
}
