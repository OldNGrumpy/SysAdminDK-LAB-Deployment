﻿Function New-TSxADGroup {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$Name,
    [Parameter(Position=1,Mandatory)]
      [string]$Path,
    [Parameter(Position=2,Mandatory)]
    [ValidateSet('Security','Distribution')]
      [string]$GroupCategory,
    [Parameter(Position=3,Mandatory)]
    [ValidateSet('DomainLocal','Global','Universal')]
      [string]$GroupScope,
    [string]$Description,
    [string]$Server,
    [switch]$NoOut
  )
  #requires -Modules ActiveDirectory

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
    
  # Set erroraction preference to SilentlyContinue and then try to get group otherwise create a new group and return object unless NoOut is set
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  $object = Get-ADGroup -Identity $Name -Properties Description -Server $Server
  $ErrorActionPreference = $EAP
  if ($object) {
    Write-Verbose "Group: ""$Name"" exists and will be used."
    if (!$NoOut) {
      return $object
    }
  }
  else {
    # Try to create new group and verify it exists before returning the group as an object
    Try {
      New-ADGroup -Name $Name -Path $Path -GroupCategory $GroupCategory -GroupScope $GroupScope -Description $Description -Server $Server  -ErrorAction Stop
      Write-Verbose "Created group $Name in $Path"
    }
    Catch {
      Write-Error "Could not create group $Name in $Path. Error: $($_.Exception.Message)"
      return $null
    }
    Do {
      $EAP = $ErrorActionPreference
      $ErrorActionPreference = 'SilentlyContinue'
      $success = Get-ADGroup -Identity $Name -Properties Description -Server $Server
      if (!($success)) {
        Start-Sleep -Seconds 1
      }
    } Until ($success)
    $ErrorActionPreference = $EAP
    if (!$NoOut) {
      return $success
    }
  }
}
