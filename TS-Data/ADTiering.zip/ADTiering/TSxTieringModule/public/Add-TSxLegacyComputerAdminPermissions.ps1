Function Add-TSxLegacyComputerAdminPermissions {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
    [ValidateNotNullOrEmpty()]
      [string]$OrganizationalUnitDN,
    [string]$GPOPrefix='Admin',
    [switch]$SkipLAPS,
    [switch]$WindowsLAPSOnly,
    [string]$Server
  )
  #requires -Modules ActiveDirectory, GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  # Get Domain Controllers OU
  $DCOU = (Get-ADDomain).DomainControllersContainer

  # Write warning and break if domain controllers exists in specified OU
  $DomainControllerOUs = @()
  $DomainControllerOUs += Get-ADDomainController -Filter * -Server $Server | Select-Object @{n='OU';e={$_.ComputerObjectDN -replace "^CN=$($_.Name),"}} -Unique | Sort-Object OU
  foreach ($DomainControllerOU in $DomainControllerOUs) {
    if ($OrganizationalUnitDN -like "*$($DomainControllerOU.OU)") {
      Write-Error "There are domain controllers in the $OrganizationalUnitDN OU. Delegating permissions to this OU would break the entire tiering setup.`nMove the domain controllers to $DCOU and run this command again."
      return;
    }
  }

  # Check if legacy or Windows LAPS is already used on target Tier. Return error if wrong switch is used
  if ($WindowsLAPSOnly -and !($SkipLAPS)) {
    $legacylaps = Get-TSxLegacyLAPSGPOLinks -Identity $OrganizationalUnitDN -GPOPrefix $GPOPrefix -Server $Server
    if ($legacylaps) {
      Write-Error "Legacy LAPS GPOs found in $Tier. Rerun without -WindowsLAPSOnly or with -SkipLAPS switch"
      return $false
    }
  }
  elseif (!($SkipLAPS)) {
    $LegacyLAPSGPOs = Get-GPO -All -Server $Server | Where-Object {$_.DisplayName -like "$GPOPrefix - LAPS*"}
    $windowslaps = Get-TSxWindowsLAPSGPOLinks -Identity $OrganizationalUnitDN -GPOPrefix $GPOPrefix -Server $Server
    if ($windowslaps) {
      Write-Error "WindowsLAPS GPOs found in $Tier. Rerun with -WindowsLAPSOnly or -SkipLAPS switch"
      return $false
    }
    elseif (!($LegacyLAPSGPOs)) {
      Write-Warning 'No Legacy LAPS GPOs found in domain. Rerun with -WindowsLAPSOnly switch to enable LAPS!' -Verbose
    }
  }

  # Set permissions to create and delete computers, organizational units, modify permissions for computers and ability to link GPOs to specified OU
  Set-TSxOUPermission -OrganizationalUnitDN $OrganizationalUnitDN -GroupName 'Domain Legacy Computer Admins' -ObjectType ComputersFull -Server $Server
  Set-TSxOUPermission -OrganizationalUnitDN $OrganizationalUnitDN -GroupName 'Domain Legacy Computer Admins' -ObjectType OUsCreate -Server $Server

  # Set LAPS read and self permissions unless SkipLAPS switch used
  if (!($SkipLAPS)) {
    Set-TSxAdmPwdComputerSelfPermission -Identity $OrganizationalUnitDN -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server
    Set-TSxAdmPwdReadPasswordPermission -Identity $OrganizationalUnitDN -AllowedPrincipals 'Domain Legacy Computer Admins' -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server
  }
  
  # Link GPO to specified OU
  $AddLocalAdminGPO = Get-GPO -Name "$GPOPrefix - Add Domain Legacy Computer Admins to Local Admin group"
  $RestrictT1AdminGPO = Get-GPO -Name "$GPOPrefix - Restrict Admin Logon T1"
  $EnabledRDPRestrictedGPO = Get-GPO -Name "$GPOPrefix - Enable Remote Desktop w Restricted Admin Mode Enable"
  New-TSxGPLink -Id $AddLocalAdminGPO.Id -Target $OrganizationalUnitDN -LinkEnabled Yes -Server $Server | Out-Null
  New-TSxGPLink -Id $RestrictT1AdminGPO.Id -Target $OrganizationalUnitDN -LinkEnabled Yes -Server $Server | Out-Null
  New-TSxGPLink -Id $EnabledRDPRestrictedGPO.Id -Target $OrganizationalUnitDN -LinkEnabled Yes -Server $Server | Out-Null
  if ($WindowsLAPSOnly -and !($SkipLAPS)) {
    $WindowsLAPSGPO = Get-GPO -Name "$GPOPrefix - WindowsLAPS Settings - Legacy"
    New-TSxGPLink -Id $WindowsLAPSGPO.Id -Target $OrganizationalUnitDN -LinkEnabled Yes -Server $Server | Out-Null
  }
}
