Function Get-TSxGPOPrefix {
  [CmdletBinding()]
  Param (
    [string]$Server
  )
  #requires -Modules GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  # Check if existing tiering group policy exist and exit if they use different prefix
  $existingprefixgpo = Get-GPO -All -Server $Server | Where-Object {$_.DisplayName -like "*Restrict Admin Logon T1"}
  if ($null -ne $existingprefixgpo) {
    $existingprefix = ($existingprefixgpo.DisplayName -split ' - ')[0]
    return $existingprefix;
  }
  else {
    return 'DoesNotExist';
  }
}
