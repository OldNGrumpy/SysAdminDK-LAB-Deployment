Function Add-TSxLegacyUserAdminPermissions {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$OrganizationalUnitDN,
    [string]$Server
  )
  #requires -Modules ActiveDirectory, GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  # Get parameters and localized group names
  $ADDomain = Get-ADDomain
  $DomainSID= $ADDomain.DomainSid.Value
  $DomainAdminGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-512""").Name
  $DomainLocalAdminGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-544""").Name

  # Write warning and break if domain admins exists in specified OU
  $DomainAdminsOUs = @()
  $DomainAdminGroupMembers = Get-ADGroupMember $DomainAdminGroup -Recursive -Server $Server | Where-Object {$_.ObjectClass -eq 'user'}
  $DomainAdministratorsGroupMembers = Get-ADGroupMember $DomainLocalAdminGroup -Recursive -Server $Server | Where-Object {$_.ObjectClass -eq 'user'}
  $DomainAdminsOUs += $DomainAdminGroupMembers | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.Name),"}}
  $DomainAdminsOUs += $DomainAdministratorsGroupMembers | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.Name),"}}
  $DomainAdminsOUs = $DomainAdminsOUs | Select-Object OU -Unique
  foreach ($DomainAdminsOU in $DomainAdminsOUs) {
    if ($OrganizationalUnitDN -like "*$($DomainAdminsOU.OU)") {
      $AffectedUsersDN = @()
      $AffectedUsersDN += ($DomainAdminGroupMembers | Where-Object {$_.DistinguishedName -like "*$OrganizationalUnitDN"}).DistinguishedName
      $AffectedUsersDN += ($DomainAdministratorsGroupMembers | Where-Object {$_.DistinguishedName -like "*$OrganizationalUnitDN"}).DistinguishedName
      $AffectedUsersDN = $AffectedUsersDN | Select-Object -Unique
      Write-Warning "There are domain admins/administrators in the specified OU. Delegating permissions to domain admins may break tiering.`nMove these users to the Admins OU"
      Write-Warning "The affected users are:`n"
      $AffectedUsersDN
      pause
    }
  }

  # Set permissions to create and delete computers, organizational units, modify permissions for computers and ability to link GPOs to specified OU
  Set-TSxOUPermission -OrganizationalUnitDN $OrganizationalUnitDN -GroupName 'Domain Legacy User Admins' -ObjectType UsersFull -Server $Server
  Set-TSxOUPermission -OrganizationalUnitDN $OrganizationalUnitDN -GroupName 'Domain Legacy User Admins' -ObjectType OUsCreate -Server $Server
}
