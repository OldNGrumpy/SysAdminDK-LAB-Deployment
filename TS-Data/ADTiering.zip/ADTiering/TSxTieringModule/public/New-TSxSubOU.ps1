﻿Function New-TSxSubOU {
  [CmdletBinding()]
  Param (
    [Parameter(Position=0,Mandatory)]
      [ValidateSet('T0','Tier0','T1','Tier1','T2','Tier2','TE','TierEndpoints')]
      [string]$Tier,
    [Parameter(Position=1,Mandatory)]
      [string]$Name,
    [Parameter(Position=2)]
      [string]$Description,
    [Parameter(Position=3,Mandatory)]
      [string]$CompanyName,
    [Parameter(Position=4)]
      [string]$TierOUName='Admin',
    [string]$GPOPrefix='Admin',
    [string]$Server,
    [switch]$SkipLAPS,
    [switch]$SkipImportGPOs,
    [switch]$WindowsLAPSOnly,
    [switch]$Cleanup
  )
  #requires -Modules ActiveDirectory, GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Check if existing tiering group policy exist and exit if they use different prefix
  $existingprefix = Get-TSxGPOPrefix -Server $Server
  if ($existingprefix -ne 'DoesNotExist' -and $existingprefix -ne $GPOPrefix) {
    Throw "Existing GPOs with prefix $existingprefix found. Rerun script with -GPOPrefix $existingprefix or remove existing GPOs"
  }

  # Get domain distinguished name
  $DomainDN=(Get-ADDomain -Server $Server).DistinguishedName
  
  # Create Tier 0 OU and exit or set parameters and create objects for other OUs
  if ($Tier -eq 'T0' -or $Tier -eq 'Tier0') {
    $Tier = 'Tier0'

    # Set default description if none specified
    if ($null -like $Description) {
      $Description = "$Tier $Name"
    }
    $ou = New-TSxADOrganizationalUnit -Name "$Name" -Path "OU=Servers,OU=Tier0,OU=$TierOUName,$DomainDN" -Description "$Description" -Server $Server -ErrorAction Stop -Verbose:$VerbosePreference
    if (!$ou) {
      Write-Error "OU $Name not created in $Path"
      return $false
    }
  }
  else {
    if ($Tier -eq 'T1' -or $Tier -eq 'Tier1') {
      $Tier = 'Tier1'
      $TierServerOU = "OU=Servers,OU=$Tier,OU=$TierOUName,$DomainDN"
      $TierGroupOU = "OU=Groups,OU=$Tier,OU=$TierOUName,$DomainDN"
      $TierGroupName = "Domain $Tier Admin - $Name"
      $TierGroupDescription = "$Tier $TierGroupName Admins"
      $TierWindowsLAPSGroup = "Domain $Tier WindowsLAPS Password Decryptors"
      $TierWindowsLAPSGroupDescription = "Members can decrypt WindowsLAPS passwords in $Tier structure"
      $GPOName = "$GPOPrefix - Add $TierGroupName to Local Admin group"
      $GPODescription = "Adds $TierGroupName to local Administrators group"
    }
    if ($Tier -eq 'T2' -or $Tier -eq 'Tier2') {
      $Tier = 'Tier2'
      $TierServerOU = "OU=Servers,OU=$Tier,OU=$TierOUName,$DomainDN"
      $TierGroupOU = "OU=Groups,OU=$Tier,OU=$TierOUName,$DomainDN"
      $TierGroupName = "Domain $Tier Admin - $Name"
      $TierGroupDescription = "$Tier $TierGroupName Admins"
      $TierWindowsLAPSGroup = "Domain $Tier WindowsLAPS Password Decryptors"
      $TierWindowsLAPSGroupDescription = "Members can decrypt WindowsLAPS passwords in $Tier structure"
      $GPOName = "$GPOPrefix - Add $TierGroupName to Local Admin group"
      $GPODescription = "Adds $TierGroupName to local Administrators group"
    }
    if ($Tier -eq 'TE' -or $Tier -eq 'TierEndpoints') {
      $Tier = 'TierEndpoints'
      $TierServerOU = "OU=Endpoints,OU=$CompanyName,$DomainDN"
      $TierGroupOU = "OU=Groups,OU=$Tier,OU=$TierOUName,$DomainDN"
      $TierGroupName = "Domain Company Admin - $Name"
      $TierGroupDescription = "$Tier $TierGroupName OU Admins"
      $TierWindowsLAPSGroup = "Domain $Tier WindowsLAPS Password Decryptors"
      $TierWindowsLAPSGroupDescription = "Members can decrypt WindowsLAPS passwords in $Tier and Company structure"
      $GPOName = "$GPOPrefix - Add $TierGroupName to Local Remote Desktop Users group"
      $GPODescription = "Adds $TierGroupName to local Remote Desktop Users group"
    }

    # Exit if the tier does not exist
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $CheckTierServerOU = Get-ADOrganizationalUnit -Identity $TierServerOU -ErrorAction SilentlyContinue -Server $Server
    if ($CheckTierServerOU.DistinguishedName -ne $TierServerOU) {
      Write-Error "$Tier does not exist in $DomainDN. Make sure your TierOU is called $TierOUName" -Verbose
      return
    }
    $ErrorActionPreference = $EAP

    # Check if legacy or Windows LAPS is already used on target Tier. Return error if wrong switch is used
    if ($WindowsLAPSOnly -and !($SkipLAPS)) {
      $legacylaps = Get-TSxLegacyLAPSGPOLinks -Identity $TierServerOU -GPOPrefix $GPOPrefix -Server $Server
      if ($legacylaps) {
        Write-Error "Legacy LAPS GPOs found in $Tier. Rerun without -WindowsLAPSOnly or with -SkipLAPS switch"
        return $false
      }
    }
    elseif (!($SkipLAPS)) {
      $windowslaps = Get-TSxWindowsLAPSGPOLinks -Identity $TierServerOU -GPOPrefix $GPOPrefix -Server $Server
      if ($windowslaps) {
        Write-Error "WindowsLAPS GPOs found in $Tier. Rerun with -WindowsLAPSOnly or -SkipLAPS switch"
        return $false
      }
    }

    # Create OU, group and GPO. Links GPO to OU and sets LAPS read permissions to group.
    # Set default description if none specified
    if ($null -like $Description) {
      $Description = "$Tier $Name"
    }

    # Create organizational unit
    $ou = New-TSxADOrganizationalUnit -Name $Name -Path $TierServerOU -Description $Description -Server $Server -Verbose:$VerbosePreference
    
    # Create domain group
    $group = New-TSxADGroup -Name $TierGroupName -Path $TierGroupOU -GroupCategory Security -GroupScope Global -Description $TierGroupDescription -Server $Server -Verbose:$VerbosePreference
    
    # Add group to WindowsLAPS group if WindowsLAPSOnly switch is used
    if ($WindowsLAPSOnly) {
      $decryptgroup = New-TSxADGroup -Name $TierWindowsLAPSGroup -Path $TierGroupOU -GroupCategory Security -GroupScope Global -Description $TierWindowsLAPSGroupDescription -Server $Server -Verbose:$VerbosePreference
      Add-ADGroupMember -Identity $decryptgroup -Members $group.Name -Server $Server
    }
    if ($global:createdgroups) {
      $global:createdgroups += $group
    }
  
    # Create group policy
    $gpo = New-TSxGPO -Name $GPOName -Description $GPODescription -Server $Server -Verbose:$VerbosePreference
    
    if ($global:createdgpos) {
      $global:createdgpos += $gpo
    }
    
    Write-Verbose "Created group:$($group.Name), OU:$($ou.Name) and GPO:$($gpo.DisplayName) in $Tier"

    # Import GPO settings
    if (!($SkipImportGPOs)) {
      Import-TSxSubOUGPO -Tier $Tier -GPOName $gpo.DisplayName -GroupName $group.Name -CompanyName $CompanyName -TierOUName $TierOUName -GPOPrefix $GPOPrefix -Cleanup:$Cleanup -Server $Server -Verbose:$VerbosePreference
    }
    
    # Link GPO to target OU
    New-TSxGPLink -Id ($gpo.id).Guid -Target $ou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null

    # Add created group to admin accounts fine-grained password policy
    Add-ADFineGrainedPasswordPolicySubject -Identity PWDPolicy-AdminAccounts -Subjects $group.Name -Server $Server

    # Set LAPS permissions for created group in created OU
    if (!($SkipLAPS)) {
      Set-TSxAdmPwdReadPasswordPermission -Identity $ou.DistinguishedName -AllowedPrincipals $group.Name -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference
    }

    # Set organizational unit permissions for created group
    Set-TSxOUPermission -OrganizationalUnitDN $ou.DistinguishedName -GroupName $group.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference

    Write-Verbose "Created SubOU $Name and dependencies in $Tier..."
  }
}
