﻿Function New-TSxGPLink {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$Id,
    [Parameter(Position=1,Mandatory)]
      [string]$Target,
    [Parameter(Position=2,Mandatory)]
      [ValidateSet('Yes','No')]
      [string]$LinkEnabled,
    [string]$Server
  )
  #requires -Modules ActiveDirectory, GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
    
  # Set erroraction preference to SilentlyContinue and then try to get group policy and organizational unit
  Do {
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $success = Get-GPO -Id $Id -Server $Server -ErrorAction SilentlyContinue
    if (!($success)) {
      Start-Sleep -Seconds 1
    }
  } Until ($success)
  $ErrorActionPreference = $EAP

  Do {
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $success2 = Get-ADOrganizationalUnit -Identity $Target -Server $Server -ErrorAction SilentlyContinue
    if (!($success2)) {
      Start-Sleep -Seconds 1
    }
  } Until ($success2)
  $ErrorActionPreference = $EAP

  # Create new group policy link in target organizational unit or return with null
  Try {
    New-GPLink -Id $Id -Target $Target -LinkEnabled $LinkEnabled -Server $Server -ErrorAction Stop
    Write-Verbose "Created GPLink for $($success.DisplayName) in $Target."
    return $true
  }
  Catch [System.ArgumentException] {
    Write-Verbose "Link for $($success.DisplayName) already exists in $Target"
  }
  Catch {
    Write-Error "Could not GPOLink $Id in $Target. Error: $($_.Exception.Message)"
    return $false
  }
}
