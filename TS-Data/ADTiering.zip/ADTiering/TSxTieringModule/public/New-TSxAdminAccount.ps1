﻿Function New-TSxAdminAccount{
  #requires -Modules ActiveDirectory
  
  [CmdletBinding()]
  Param(
    [parameter(mandatory=$true,ValueFromPipelineByPropertyName=$true)]
    [ValidateNotNullOrEmpty()]
      [string]$FirstName,
    [parameter(mandatory=$true,ValueFromPipelineByPropertyName=$true)]
      [ValidateNotNullOrEmpty()]
      [string]$LastName,
    [parameter(mandatory=$true,ValueFromPipelineByPropertyName=$true)]
      [ValidateSet('T0','T1','T1L','T1Limited','T2','T2L','T2Limited','TE','Con')]
      [string]$AccountType,
    [parameter(mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$Prefix = 'ADM',
    [parameter(mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$Suffix = 'NA',
    [parameter(mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$AccountName = 'NA',
    [parameter(mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$UPNDomain = 'NA',
    [parameter(mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [boolean]$AddToSilo = $false,
    [parameter(Mandatory=$false)]
      [string]$Server
  )
  
  # Convert old limited naming convention
  if ($AccountType -like '*Limited') {
    $AccountType = $AccountType.Substring(0,3)
  }
  
  # Get AD domain information
  $ADDomain = Get-ADDomain -ErrorAction Stop
  
  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Generate or set account logon name
  if ($AccountName -eq 'NA') {
    $LogonName = New-TSxAdminAccountName -Prefix $Prefix -FirstName $FirstName -LastName $LastName -AccountType $AccountType -Verbose:$VerbosePreference
    Write-Verbose "New-TSxAdminAccountName generated account name: $LogonName"
  }
  elseif ($AccountName.Length -lt 4) {
    Write-Warning "AccountName specified was less than 4 characters long. Using generated account name instead!"
    $LogonName = New-TSxAdminAccountName -Prefix $Prefix -FirstName $FirstName -LastName $LastName -AccountType $AccountType -Verbose:$VerbosePreference
    Write-Verbose "New-TSxAdminAccountName generated account name: $LogonName"
  }
  else {
    $LogonName = $AccountName + $AccountType
    $LogonName = $LogonName.ToLower()
  }

  if((Test-TSxAccount -SamAccountName $LogonName) -eq $true -or $null -eq $LogonName){
    Write-Error "$LogonName already exist"
    return
  }

  # Get and set UserPrincipalName logon domain
  if ($UPNDomain -eq 'NA') {
    $UserPrincipalName = $LogonName + "@" + $($ADDomain.DnsRoot)
  }
  else {
    $UserPrincipalName = $LogonName + "@" + $UPNDomain
    $UserPrincipalName = $UserPrincipalName.ToLower()
  }
  Write-Verbose "Using the UserPrincipalName: $UserPrincipalName"

  # Get AccountType configuration from settings file
  $Settings = $TSxTieringModuleSettings.Settings.Configs.Config | Where-Object Name -EQ $AccountType
  
  # Verify target OU exits
  $AccountOUDN = "$($Settings.AccountOUDN),$($ADDomain.DistinguishedName)"
  $TargetOU = (Get-ADOrganizationalUnit -Identity $AccountOUDN)
  if (!($TargetOU)) {
    Write-Error "$AccountOUDN does not exist"
    return
  }
  Write-Verbose "Creating user $LogonName in Organizational Unit: $TargetOU"
  
  # Generate and set admin account password
  $AccountPW = New-TSxRandomPassword -PasswordLength $Settings.PasswordLength
  $SecurePassword = ConvertTo-SecureString -String $AccountPW -AsPlainText -Force

  # Modify AccountType for description
  if ($AccountType -eq 'T1L' -or $AccountType -eq 'T2L') {
    $AccountType = $AccountType + 'imited'
  }
  
  # Set description for admin account
  if ($Suffix -eq 'NA' -or $Suffix.Length -lt 1) {
    $Description = $FirstName + " " + $LastName + " " + $Prefix + " " + $AccountType
  }
  else {
    $Description = $FirstName + " " + $LastName + " " + $Prefix + " " + $AccountType + " " + "[$Suffix]"
  }

  # Create admin account
  $NewAccount = New-ADUser `
  -Description $Description `
  -DisplayName $("[" + $AccountType + " " + $Prefix + "]" + " " + $FirstName + " " + $LastName) `
  -GivenName $FirstName `
  -Surname $LastName `
  -Name $("[" + $AccountType + " " + $Prefix + "]" + " " + $FirstName + " " + $LastName) `
  -Path $TargetOU `
  -SamAccountName $LogonName `
  -CannotChangePassword $false `
  -PasswordNeverExpires $false `
  -ChangePasswordAtLogon $false `
  -UserPrincipalName $UserPrincipalName `
  -KerberosEncryptionType 'RC4, AES128, AES256' `
  -PassThru  `
  -Server $Server `
  -Verbose:$VerbosePreference

  # Set password and enable account
  Try {
    Set-ADAccountPassword -Identity $NewAccount -NewPassword $SecurePassword -Server $Server -ErrorAction Stop | Out-Null
    Write-Verbose "Set password for $LogonName"
  }
  Catch {
    Write-Error "Failed to set password on $LogonName. Set password manually!"
  }
  Try {
    Enable-ADAccount -Identity $NewAccount -Server $Server -ErrorAction Stop | Out-Null
    Write-Verbose "Enabled account $LogonName"
  }
  Catch {
    Write-Error "Failed to enable account $LogonName. Enable account manually!"
  }

  # Set admin account group membership
  foreach($ADGroup in $Settings.GroupMemberShips.GroupMemberShip){
    if ($ADGroup -eq 'Domain Admins') {
      $DomainSID=(Get-ADDomain).DomainSid.Value
      $ADGroup = Get-ADGroup -Filter "SID -eq ""$DomainSID-512""" -Server $Server
    }
    $Group = Get-ADGroup $ADGroup -Server $Server
    Add-ADGroupMember -Identity $Group -Members $NewAccount -Server $Server
    Write-Verbose "Added user $LogonName to group: $Group"
  }

  # If Tier0, Tier1 or Tier2 account set not permitted to be delegated
  if ($AccountType -eq 'T0' -or $AccountType -eq 'T1' -or $AccountType -eq 'T2'-or $AccountType -eq 'T1Limited'-or $AccountType -eq 'T2Limited') {
    Set-ADUser -Identity $NewAccount.SamAccountName -AccountNotDelegated $true -Server $Server
    Write-Verbose "Set preference ""Account is sensitive and cannot be delegated"" for $LogonName"
  }

  # If AddToSilo is true add account to tier silo
  if($AddToSilo -eq $true) {
    if ($AccountType -eq 'TE' -or $AccountType -eq 'Con') {
      Write-Warning "Connection accounts and TierEndpoint admin account does not have silos"
    }
    else {
      if ($AccountType -eq 'T1L' -or $AccountType -eq 'T2L') {
        $AccountType = $AccountType + 'imited'
      }
      Set-TSxAdminADAuthenticationPolicySiloForUser -Tier $AccountType -ADUserIdentity $NewAccount -Verbose:$VerbosePreference
      Write-Verbose "Added $LogonName to $AccountType Authentication Silo"
    }
  }

  # Create and display output object
  $object = New-Object PSCustomObject
  $object | Add-Member NoteProperty DisplayName $NewAccount.Name
  $object | Add-Member NoteProperty SamAccountName $NewAccount.SamAccountName
  $object | Add-Member NoteProperty UserPrincipalName $NewAccount.UserPrincipalName
  $object | Add-Member NoteProperty Password $AccountPW
  return $object
}