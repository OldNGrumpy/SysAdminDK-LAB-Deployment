Function Add-TSxLegacyGroupAdminPermissions {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$OrganizationalUnitDN,
    [string]$Server
  )
  #requires -Modules ActiveDirectory, GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  # Get parameters and localized group names
  $ADDomain = Get-ADDomain
  $DomainSID= $ADDomain.DomainSid.Value
  $DomainAdminGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-512""").Name
  $DomainLocalAdminGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-544""").Name

  # Write warning if domain admin groups exists in specified OU
  $DomainAdminGroupsOUs = @()
  $DomainAdminGroupObject = Get-ADGroup $DomainAdminGroup -Server $Server
  $DomainAdministratorsGroupObject = Get-ADGroup $DomainLocalAdminGroup -Server $Server
  $DomainAdminGroupGroupMembers = Get-ADGroupMember $DomainAdminGroup -Server $Server | Where-Object {$_.ObjectClass -eq 'group'}
  $DomainAdministratorsGroupGroupMembers = Get-ADGroupMember $DomainLocalAdminGroup -Server $Server | Where-Object {$_.ObjectClass -eq 'group'}
  $DomainAdminGroupsOUs += $DomainAdminGroupObject | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.Name),"}}
  $DomainAdminGroupsOUs += $DomainAdministratorsGroupObject | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.Name),"}}
  $DomainAdminGroupsOUs += $DomainAdminGroupGroupMembers | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.Name),"}}
  $DomainAdminGroupsOUs += $DomainAdministratorsGroupGroupMembers | Select-Object @{n='OU';e={$_.distinguishedName -replace "^CN=$($_.Name),"}}
  $DomainAdminGroupsOUs = $DomainAdminGroupsOUs | Select-Object OU -Unique
  foreach ($DomainAdminGroupsOU in $DomainAdminGroupsOUs) {
    if ($OrganizationalUnitDN -like "*$($DomainAdminGroupsOU.OU)") {
      $AffectedGroupsDN = @()
      $AffectedGroupsDN += ($DomainAdminGroupObject | Where-Object {$_.DistinguishedName -like "*$OrganizationalUnitDN"}).DistinguishedName
      $AffectedGroupsDN += ($DomainAdministratorsGroupObject | Where-Object {$_.DistinguishedName -like "*$OrganizationalUnitDN"}).DistinguishedName
      $AffectedGroupsDN += ($DomainAdminGroupGroupMembers| Where-Object {$_.DistinguishedName -like "*$OrganizationalUnitDN"}).DistinguishedName
      $AffectedGroupsDN += ($DomainAdministratorsGroupGroupMembers | Where-Object {$_.DistinguishedName -like "*$OrganizationalUnitDN"}).DistinguishedName
      $AffectedGroupsDN = $AffectedGroupsDN | Select-Object -Unique
      Write-Warning "There are groups which are members of domain admins/administrators in the specified OU. Delegating permissions to domain admins will break tiering.`nMove these groups to the Admins OU"
      Write-Warning "The affected groups are:`n"
      $AffectedGroupsDN
      pause
    }
  }

  # Set permissions to create and delete computers, organizational units, modify permissions for computers and ability to link GPOs to specified OU
  Set-TSxOUPermission -OrganizationalUnitDN $OrganizationalUnitDN -GroupName 'Domain Legacy Group Admins' -ObjectType GroupsCreate -Server $Server
  Set-TSxOUPermission -OrganizationalUnitDN $OrganizationalUnitDN -GroupName 'Domain Legacy Group Admins' -ObjectType OUsCreate -Server $Server
}
