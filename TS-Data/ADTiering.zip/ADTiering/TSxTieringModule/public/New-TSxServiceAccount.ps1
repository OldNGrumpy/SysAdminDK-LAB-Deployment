﻿Function New-TSxServiceAccount{
  [CmdletBinding(SupportsShouldProcess=$true)]
  Param(
    [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
      [ValidateNotNullOrEmpty()]
      [string]$FirstName,
    [Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$LastName='',
    [Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$AccountName,
    [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
      [ValidateSet('User','gMSA')]
      [string]$UserType,
    [Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
      [ValidateSet('T0SVC','T1SVC','T2SVC','TESVC')]
      [string]$AccountType,
    [Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
      [string]$UPNDomain='NA',
    [Parameter(Mandatory=$false)]
      [string]$Server
  )

  # Get AD domain information
  $ADDomain = Get-ADDomain -ErrorAction Stop
  
  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Generate or set account logon name
  if ($AccountName) {
    $LogonName = $AccountName.ToLower()
  }
  elseif ($LastName -eq '') {
    $LogonName = $FirstName.ToLower()
  }
  else {
    $FirstShort = Remove-Diacritics ($FirstName.Replace(' ','')).Substring(0,3)
    $LastShort = Remove-Diacritics ($LastName.Replace(' ','')).Substring(0,3)
    $LogonName = $AccountType + $FirstShort + $LastShort
    $LogonName = $LogonName.ToLower()
  }
  Write-Verbose "Creating the service account with AccountName: $LogonName"

  # Get and set UserPrincipalName logon domain
  if ($UPNDomain -eq 'NA') {
    $UserPrincipalName = $LogonName + "@" + $($ADDomain.DnsRoot)
  }
  else {
    $UserPrincipalName = $LogonName + "@" + $UPNDomain
    $UserPrincipalName.ToLower()
  }
  Write-Verbose "Using UserPrincipalName: $UserPrincipalName"

  # Get AccountType configuration from settings file
  $Settings = $TSxTieringModuleSettings.Settings.Configs.Config | Where-Object Name -EQ $AccountType

  # Verify target OU exits
  $AccountOUDN = "$($Settings.AccountOUDN),$($ADDomain.DistinguishedName)"
  $TargetOU = (Get-ADOrganizationalUnit -Identity $AccountOUDN -ErrorAction SilentlyContinue)
  if (!($TargetOU)) {
    Write-Warning "TargetOU $AccountOUDN does not exist!"
    return
  }
  Write-Verbose "Creating user $LogonName in Organizational Unit: $TargetOU"
  
  # Create user or gMSA service account if it does not exist
  if ($UserType -eq 'User') {
    if((Test-TSxAccount -SamAccountName $LogonName) -eq $true) {
      Write-Warning "$LogonName already exist"
      return
    }

    # Generate and set admin account password
    $AccountPW = New-TSxRandomPassword -PasswordLength $Settings.PasswordLength
    $SecurePassword = ConvertTo-SecureString -String $AccountPW -AsPlainText -Force
    
    # Create user service account
    $NewAccount = New-ADUser `
    -Description $($FirstName + " " + $LastName + " " + $AccountType) `
    -DisplayName $("[" + $AccountType + "]" + " " + $FirstName + " " + $LastName) `
    -GivenName $($FirstName) `
    -Surname $($LastName) `
    -Name $("[" + $AccountType + "]" + " " + $FirstName + " " + $LastName) `
    -AccountPassword $SecurePassword `
    -Path $TargetOU `
    -SamAccountName $($LogonName) `
    -KerberosEncryptionType 'RC4, AES128, AES256' `
    -CannotChangePassword $true `
    -PasswordNeverExpires $true `
    -ChangePasswordAtLogon $false `
    -AccountNotDelegated $true `
    -UserPrincipalName $UserPrincipalName `
    -Enabled $true `
    -PassThru  `
    -Server $Server `
    -Verbose:$VerbosePreference
  }
  elseif ($UserType -eq 'gMSA') {
    if((Test-TSxGMSAAccount -SamAccountName $LogonName) -eq $true) {
      Write-Warning "$LogonName already exist"
      return
    }

    # Check for usable KDSRootKey otherwise create one
    $KDSRootKey = (Get-KdsRootKey) | Where-Object EffectiveTime -le (Get-Date).AddHours(-10)
    if ($null -eq $KDSRootKey) {
      Add-KdsRootKey -EffectiveTime (Get-Date).AddHours(-10)
    }

    # Create gMSA service account
    $NewAccount = New-ADServiceAccount `
    -Description $($FirstName + " " + $LastName + " " + $AccountType) `
    -DisplayName $("[" + $AccountType + "]" + " " + $FirstName + " " + $LastName) `
    -Name $("[" + $AccountType + "]" + " " + $FirstName + " " + $LastName) `
    -Path $TargetOU `
    -SamAccountName $($LogonName) `
    -DNSHostName $($LogonName + '.' +  $($ADDomain.Forest)) `
    -KerberosEncryptionType 'RC4, AES128, AES256' `
    -AccountNotDelegated $true `
    -Enabled $true `
    -PassThru  `
    -Server $Server `
    -Verbose:$VerbosePreference
  }

  # Set service account group membership
  foreach($ADGroup in $Settings.GroupMemberShips.GroupMemberShip){
    $Group = Get-ADGroup $ADGroup -Server $Server
    Add-ADGroupMember -Identity $Group -Members $NewAccount -Server $Server
    Write-Verbose "Added user $LogonName to group: $Group"
  }

  # Create and display output object
  $object = New-Object PSCustomObject
  $object | Add-Member NoteProperty DisplayName $NewAccount.Name
  $object | Add-Member NoteProperty SamAccountName $NewAccount.SamAccountName
  if ($UserType -eq 'User') {
    $object | Add-Member NoteProperty UserPrincipalName $NewAccount.UserPrincipalName
    $Object | Add-Member NoteProperty Password $AccountPW
  }
  return $object
}
