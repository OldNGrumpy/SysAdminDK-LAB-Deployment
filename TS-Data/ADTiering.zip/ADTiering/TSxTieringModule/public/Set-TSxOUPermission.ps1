﻿function Set-TSxOUPermission {
  [CmdletBinding()]
  Param (
    [Parameter(Position=0,Mandatory)]
      [string]$OrganizationalUnitDN,
    [Parameter(Position=1,Mandatory)]
      [string]$GroupName,
    [Parameter(Position=2,Mandatory)]
      [ValidateSet('ComputersCreate','ComputersCreateGPLink','ComputersFull','BitLocker','GroupsMembers','GroupsCreate','Users','UsersCreate','UsersCreateGPLink','UsersFull','OUsCreate','DenyGPLink','Contacts','ContactsCreate','SiloMembers')]
      [string]$ObjectType,
    [string]$Server
  )
  
  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Set erroraction preference to SilentlyContinue and then verify target group and organizational unit. Exit if they can't be found.
  $i = 0
  $j = 0
  if ($GroupName -ne 'Everyone' -and $GroupName -notlike '*\*') {
    Do {
      $EAP = $ErrorActionPreference
      $ErrorActionPreference = 'SilentlyContinue'
      $success = Get-ADObject -Filter "Name -eq '$GroupName'" -Server $Server -ErrorAction SilentlyContinue
      $i++
      if (!($success)) {
        Start-Sleep -Seconds 1
      }
    } Until ($success -or $i -gt 60)
    $ErrorActionPreference = $EAP
  }
  else {
    $success = 'Everyone'
  }

  Do {
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $success2 = Get-ADObject -Identity $OrganizationalUnitDN -Server $Server -ErrorAction SilentlyContinue | Where-Object {$_.ObjectClass -eq 'Container' -or $_.ObjectClass -eq 'organizationalUnit' -or $_.ObjectClass -eq 'msDS-AuthNPolicySilo'}
    $j++
    if (!($success2)) {
      Start-Sleep -Seconds 1
    }
  } Until ($success2 -or $j -gt 60)
  $ErrorActionPreference = $EAP

  if (!($success -and $success2)) {
    if (!($success)) {
      Write-Error "$GroupName does not exist!" -Verbose
    }
    if (!($success2)) {
      Write-Error "$OrganizationalUnitDN does not exist!" -Verbose
    }
    return;
  }

  # Set parameters
  $NBDomainName = (Get-ADDomain).NetBIOSName
  if ($GroupName -ne 'Everyone' -and $GroupName -notlike '*\*') {
    $TargetGroup = "$NBDomainName\$GroupName"
  }
  else {
    $TargetGroup = $GroupName
  }

  # Add server if Server variable is set
  if ($Server) {
    $Server = Get-TSxVerifiedDomainController -Server $Server
    $ServerName = (($Server).Split('.'))[0]
    $OrganizationalUnitDN = "\\$ServerName\$OrganizationalUnitDN"
  }
  
  Write-Verbose "Adding $ObjectType permissions to $GroupName at $OrganizationalUnitDN"
  # Computer objects only: Create, Delete, Read/write all properties, Reset password, Change password
  if ($ObjectType -eq 'ComputersCreate') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;Computer" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":LCCCDCRCWDRPWPSD;;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Reset Password;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Change Password;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":WS;Validated write to service principal name;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":WS;Validated write to DNS host name;Computer" /I:S | Out-Null
  }

  # Computer objects: Create, Delete, Read/write all properties, Reset password, Change password. Read GPOptions, Read/Write GPLinks
  if ($ObjectType -eq 'ComputersCreateGPLink') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;Computer" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":LCCCDCRCWDRPWPSD;;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Reset Password;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Change Password;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":WS;Validated write to service principal name;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":WS;Validated write to DNS host name;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RP;GPOptions;" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;GPLink;" /I:T | Out-Null
  }

  # Computer object, Create, Delete, Full permissions. Read GPOptions, Read/Write GPLinks
  if ($ObjectType -eq 'ComputersFull') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;Computer" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":GA;;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RP;GPOptions;" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;GPLink;" /I:T | Out-Null
  }

  # Computer objects only: Read TPM Owner Info, Read BitLocker RecoveryInformation and password
  if ($ObjectType -eq 'BitLocker') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RP;msTPM-OwnerInformation;Computer" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RP;;msFVE-RecoveryInformation" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;msFVE-RecoveryPassword;msFVE-RecoveryInformation" /I:S | Out-Null
  }

  # Group objects only: Manage membership
  if ($ObjectType -eq 'GroupsMembers') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;Member;Group" /I:S | Out-Null
  }

  # Group objects only: Create, Delete, Read/write all properties.
  if ($ObjectType -eq 'GroupsCreate') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;Group" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWPSD;;Group" /I:S | Out-Null
  }

  # User objects only: Read/write all properties, Reset password
  if ($ObjectType -eq 'Users') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;;User" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Reset Password;User" /I:S | Out-Null
  }

  # User objects only: Create, Delete, Read/write all properties, Reset password
  if ($ObjectType -eq 'UsersCreate') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;User" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWPSD;;User" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Reset Password;User" /I:S | Out-Null
  }

  # User objects only: Create, Delete, Read/write all properties, Reset password. Read GPOptions, Read/Write GPLinks
  if ($ObjectType -eq 'UsersCreateGPLink') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;User" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWPSD;;User" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CA;Reset Password;User" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RP;GPOptions;" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;GPLink;" /I:T | Out-Null
  }

  # User objects only: Create, Delete, Full permissions. Read GPOptions, Read/Write GPLinks
  if ($ObjectType -eq 'UsersFull') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;User" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":GA;;User" /I:S | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RP;GPOptions;" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;GPLink;" /I:T | Out-Null
  }

  # Contact objects only: Read/write all properties
  if ($ObjectType -eq 'Contacts') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWP;;Contact" /I:T | Out-Null
  }

  # Contact objects only: Create, Delete, Read/write all properties
  if ($ObjectType -eq 'ContactsCreate') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;Contact" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWPSD;;Contact" /I:S | Out-Null
  }

  # OU objects only: Create, Delete, Read/write all properties
  if ($ObjectType -eq 'OUsCreate') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":CCDC;Organizationalunit" /I:T | Out-Null
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":RPWPSD;;Organizationalunit" /I:S | Out-Null
  }

  # Deny create GPOLinks
  if ($ObjectType -eq 'DenyGPLink') {
    dsacls.exe $OrganizationalUnitDN /D $TargetGroup":WP;GPLink;" /I:P | Out-Null
  }

  # Add and remove members from authentication policy silo
  if ($ObjectType -eq 'SiloMembers') {
    dsacls.exe $OrganizationalUnitDN /G $TargetGroup":WP;msDS-AuthNPolicySiloMembers" | Out-Null
  }

  # Write verbose information
  Write-Verbose "Gave $Targetgroup permission $ObjectType under $OrganizationalUnitDN"
}
