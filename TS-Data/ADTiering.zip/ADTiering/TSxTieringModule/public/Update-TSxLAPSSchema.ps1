function Update-TSxLAPSSchema {
  [CmdletBinding()]
  Param(
    [switch]$WindowsLAPSOnly
  )
  #requires -Modules ActiveDirectory
  
  # Set parameters
  $ADDomain = Get-ADDomain
  $ForestDomain = (Get-ADDomain -Identity $ADDomain.Forest)
  $ForestDomainSID = $ForestDomain.DomainSid.Value
  $Path = $PSScriptRoot
  if ($Path -like '*TSxTieringModule\public') {
    $Path = $Path.Replace('TSxTieringModule\public','')
  }
  if ($Path -like '*TSxTieringModule\private') {
    $Path = $Path.Replace('TSxTieringModule\private','')
  }
  $Path = $Path.TrimEnd('\')

  # Check if OS is WindowsLAPS capable
  $WindowsLAPSCapable = Get-TSxWindowsLAPSCapable -Verbose:$VerbosePreference

  # If WindowsLAPSOnly is not set, load legacy LAPS module
  if (!($WindowsLAPSOnly)) {
    if (Test-Path -Path "$Path\AdmPwd.PS\AdmPwd.PS.psd1" -ErrorAction SilentlyContinue) {
      Import-Module "$Path\AdmPwd.PS\AdmPwd.PS.psd1" -Force
    }
    else {
      Write-Error "Legacy LAPS powershell module required for legacy LAPS configuration. Make sure the AdmPwd.PS folder is in the same directory as the script."
      return $false
    }
  }
  
  # If OS i WindowsLAPS capable update AD with Windows LAPS schema extensions
  if ($WindowsLAPSCapable) {
    Write-Verbose 'Looks for Windows LAPS schema extensions. Adds them if they cant be found.'
    if (!(Get-ADObject -SearchBase ((Get-ADRootDSE).schemaNamingContext) -SearchScope OneLevel -Filter * -Property name | Where-Object {$_.Name -like 'ms-LAPS-*'})) {
      Write-Verbose 'Windows LAPS schema extensions not found. Adding schema extension...'
      if ([System.Security.Principal.WindowsIdentity]::GetCurrent().Groups -contains "$ForestDomainSID-518") {
        Try {
          Update-LapsADSchema -Confirm:$false
          Write-Verbose "Updated Active Directory with Windows LAPS schema extensions"
          $success = $true
        }
        Catch {
          return $false
        }
      }
      else {
        return $false
      }
    }
    else {
      $success = $true
    }
  }

  # Looks for AdmPwd schema extensions. Adds them if they can't be found unless WindowsLAPSOnly switch is used
  if (!($WindowsLAPSOnly)) {
    Write-Verbose 'Looks for AdmPwd schema extensions. Adds them if they cant be found.'
    if (Get-ADObject -SearchBase ((Get-ADRootDSE).schemaNamingContext) -SearchScope OneLevel -Filter * -Property name | Where-Object {$_.Name -like '*AdmPwd*'}) {
      return $true;
    }
    else {
      Write-Verbose 'AdmPwd LAPS schema extensions not found. Adding schema extension...'
      if ([System.Security.Principal.WindowsIdentity]::GetCurrent().Groups -contains "$ForestDomainSID-518") {
        Try {
          Update-AdmPwdADSchema
          Write-Verbose "Updated Active Directory with legacy LAPS schema extensions"
          return $true
        }
        Catch {
          return $false
        }
      }
      else {
        return $false
      }
    }
  }
  elseif ($success) {
    return $true
  }
  
  # Throw error if WindowsLAPSOnly switch is used and OS is not WindowsLAPS capable
  if ($WindowsLAPSOnly -and !($WindowsLAPSCapable)) {
    Throw "This OS is not Windows LAPS capable. Use -WindowsLAPSOnly switch only on Windows LAPS capable OS."
    return $false
  }
}
