Function Set-TSxAdmPwdReadPasswordPermission {
  [CmdletBinding()]
  Param(
    [Parameter(Position=0,Mandatory)]
      [string]$Identity,
    [Parameter(Position=1,Mandatory)]
      [string]$AllowedPrincipals,
    [switch]$WindowsLAPSOnly,
    [string]$Server
  )

  # Set variables
  $Path = $PSScriptRoot
  if ($Path -like '*TSxTieringModule\public') {
    $Path = $Path.Replace('TSxTieringModule\public','')
  }
  if ($Path -like '*TSxTieringModule\private') {
    $Path = $Path.Replace('TSxTieringModule\private','')
  }
  $Path = $Path.TrimEnd('\')

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Check if OS is WindowsLAPS capable
  $WindowsLAPSCapable = Get-TSxWindowsLAPSCapable -Verbose:$VerbosePreference

  # If WindowsLAPSOnly is not set, load legacy LAPS module
  if (!($WindowsLAPSOnly)) {
    if (Test-Path -Path "$Path\AdmPwd.PS\AdmPwd.PS.psd1" -ErrorAction SilentlyContinue) {
      Import-Module "$Path\AdmPwd.PS\AdmPwd.PS.psd1" -Force
    }
    else {
      Write-Error "Legacy LAPS powershell module required for legacy LAPS configuration. Make sure the AdmPwd.PS folder is in the same directory as the script."
      return;
    }
  }
  
  # Set erroraction preference to SilentlyContinue and then verify target group and organizational unit
  $i = 0
  $j = 0
  Do {
    if ($AllowedPrincipals -like '*\*') {
      $CheckPrincipals = $AllowedPrincipals.Split('\')[1]
    }
    else {
      $CheckPrincipals = $AllowedPrincipals
    }
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $success = Get-ADGroup -Identity $CheckPrincipals -Server $Server -ErrorAction SilentlyContinue
    $i++
    if (!($success)) {
      Start-Sleep -Seconds 1
    }
  } Until ($success -or $i -gt 60)
  $ErrorActionPreference = $EAP

  Do {
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $success2 = Get-ADObject -Identity $Identity -Server $Server -ErrorAction SilentlyContinue | Where-Object {$_.ObjectClass -eq 'Container' -or $_.ObjectClass -eq 'organizationalUnit'}
    $j++
    if (!($success2)) {
      Start-Sleep -Seconds 1
    }
  } Until ($success2 -or $i -gt 60)
  $ErrorActionPreference = $EAP

  if (!($success -and $success2)) {
    if (!($success)) {
      Write-Error "$AllowedPrincipals does not exist!" -Verbose
    }
    if (!($success2)) {
      Write-Error "$Identity does not exist!" -Verbose
    }
    return;
  }

  # Add domain netbios name to group
  $ADNetBIOSName = (Get-ADDomain).NetBIOSName
  if ($AllowedPrincipals -notlike "$ADNetBIOSName\*") {
    $AllowedPrincipalsWithDomain = "$ADNetBIOSName\$AllowedPrincipals"
  }
  else {
    $AllowedPrincipalsWithDomain = $AllowedPrincipals
  }

  # If OS i WindowsLAPS add LAPS read permissions to specified group under specified organizational unit
  if ($WindowsLAPSCapable) {
    if (Get-Module LAPS -ListAvailable) {
      Try {
        Start-Sleep -Seconds 1
        Set-LapsADReadPasswordPermission -Identity $Identity -AllowedPrincipals $AllowedPrincipalsWithDomain -DomainController $Server -ErrorAction Stop -Verbose:$false | Out-Null
        Write-Verbose "Set Windows LAPS read permissions for $AllowedPrincipals under $Identity"
      }
      Catch {
        "Set-LapsADReadPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain""`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
        Write-Warning "Unable to assign Windows LAPS permission! Run the following command manually:`nSet-LapsADReadPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain"""
      }
      Try {
        Set-LapsADResetPasswordPermission -Identity $Identity -AllowedPrincipals $AllowedPrincipalsWithDomain -DomainController $Server -ErrorAction Stop -Verbose:$false | Out-Null
        Write-Verbose "Set Windows LAPS reset permissions for $AllowedPrincipals under $Identity"
      }
      Catch {
        "Set-LapsADResetPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain""`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
        Write-Warning "Unable to assign Windows LAPS permission! Run the following command manually:`nSet-LapsADResetPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain"""
      }
    }
  }

  # Unless WindowsLAPSOnly is set, add Legacy LAPS read permissions to specified group under specified organizational unit
  if (!($WindowsLAPSOnly)) {
    Try {
      Start-Sleep -Seconds 1
      Set-AdmPwdReadPasswordPermission -Identity $Identity -AllowedPrincipals $AllowedPrincipalsWithDomain -ErrorAction Stop -Verbose:$false | Out-Null
      Write-Verbose "Set legacy LAPS read permissions for $AllowedPrincipals under $Identity"
    }
    Catch {
      "Set-AdmPwdReadPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain""`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
      Write-Warning "Unable to assign legacy LAPS permission! Run the following command manually:`nSet-AdmPwdReadPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain"""
    }
    Try {
      Set-AdmPwdResetPasswordPermission -Identity $Identity -AllowedPrincipals $AllowedPrincipalsWithDomain -ErrorAction Stop -Verbose:$false | Out-Null
      Write-Verbose "Set legacy LAPS reset permissions for $AllowedPrincipals under $Identity"
    }
    Catch {
      "Set-AdmPwdResetPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain""`n" | Out-File -FilePath "$Path\RetryCommands.ps1" -Append
      Write-Warning "Unable to assign legacy LAPS permission! Run the following command manually:`nSet-AdmPwdResetPasswordPermission -Identity ""$Identity"" -AllowedPrincipals ""$AllowedPrincipalsWithDomain"""
    }
  }
}
