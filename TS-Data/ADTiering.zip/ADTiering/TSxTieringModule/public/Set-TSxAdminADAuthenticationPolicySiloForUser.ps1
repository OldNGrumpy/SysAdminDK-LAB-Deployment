﻿Function Set-TSxAdminADAuthenticationPolicySiloForUser{
  [CmdletBinding()]
  Param(
    [parameter(mandatory=$True)]
      [ValidateNotNullOrEmpty()]
      [string]$ADUserIdentity,
    [parameter(mandatory=$True)]
      [ValidateSet('T0','T1','T1Limited','T2','T2Limited','TP')]
      [string]$Tier,
      [string]$Server
  )

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $SpecifiedServer = $Server
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($Server -eq $false) {
    Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }

  $AuthenticationPolicySiloName = "Restricted_$($Tier)Admin_Logon"
  $UserDistinguishedName = (Get-ADUser -Identity $ADUserIdentity -ErrorAction Stop -Server $Server).DistinguishedName
  $AuthenticationPolicySilo = (Get-ADAuthenticationPolicySilo -Identity $AuthenticationPolicySiloName -ErrorAction Stop -Server $Server).DistinguishedName
  Grant-ADAuthenticationPolicySiloAccess -Identity $AuthenticationPolicySilo -Account $UserDistinguishedName -Server $Server
  Set-ADAccountAuthenticationPolicySilo -Identity $UserDistinguishedName -AuthenticationPolicySilo $AuthenticationPolicySilo -Server $Server
}
