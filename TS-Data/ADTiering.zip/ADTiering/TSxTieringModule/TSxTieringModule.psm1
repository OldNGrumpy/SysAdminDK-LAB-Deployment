
#Dot source all functions in all ps1 files located in the module folder
If (Test-Path "$PSScriptRoot\private") {
    Get-ChildItem -Path $PSScriptRoot\private\*.ps1 -Exclude *.tests.ps1, *profile.ps1 |
    ForEach-Object {
        . $_.FullName
    }
}
If (Test-Path "$PSScriptRoot\public") {

    Get-ChildItem -Path $PSScriptRoot\public\*.ps1 -Exclude *.tests.ps1, *profile.ps1 |
    ForEach-Object {
        . $_.FullName
    }

}


if (Test-Path -Path "$PSScriptRoot\TSxTieringModuleSettings.xml"){
    [xml]$Global:TSxTieringModuleSettings = Get-Content -Path "$PSScriptRoot\TSxTieringModuleSettings.xml"
}

$PublicScriptBlock = [ScriptBlock]::Create((Get-ChildItem -Path $PSScriptRoot\public\*.ps1 -Exclude *.tests.ps1, *profile.ps1 -ErrorAction SilentlyContinue | Get-Content | Out-String))
$PublicFunctions = $PublicScriptBlock.Ast.FindAll( { $args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $false).Name
Export-ModuleMember -Function $PublicFunctions