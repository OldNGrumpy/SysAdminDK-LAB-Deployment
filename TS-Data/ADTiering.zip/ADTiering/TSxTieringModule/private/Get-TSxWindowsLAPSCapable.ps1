Function Get-TSxWindowsLAPSCapable {
  [CmdletBinding()]
  Param()
  
  # Create VersionInfo object with needed information from registry
  $VersionInfo = [PSCustomObject]@{
    'ProductName' = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name ProductName).ProductName
    'CurrentBuild' = [int32](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name CurrentBuild).CurrentBuild
    'UBR' = [int32](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name UBR).UBR
  }

  # Switch to set Result to true if OS is patched with CU from april 2023
  switch ($VersionInfo) {
    {($_.ProductName -like '*Server*') -and ($_.CurrentBuild -eq 17763) -and ($_.UBR -ge 4252)} {$Result = $true}
    {($_.ProductName -like '*Server*') -and ($_.CurrentBuild -eq 20348) -and ($_.UBR -ge 1668)} {$Result = $true}
    {($_.ProductName -like '*Server*') -and ($_.CurrentBuild -gt 20348)} {$Result = $true}
    {($_.CurrentBuild -eq 19042) -and ($_.UBR -ge 2846)} {$Result = $true}
    {($_.CurrentBuild -eq 19044) -or ($_.CurrentBuild -eq 19045) -and ($_.UBR -ge 2846)} {$Result = $true}
    {($_.CurrentBuild -eq 22000) -and ($_.UBR -ge 1817)} {$Result = $true}
    {($_.CurrentBuild -eq 22621) -and ($_.UBR -ge 1555)} {$Result = $true}
    {($_.CurrentBuild -gt 22621)} {$Result = $true}
    default {$Result = $false}
  }
 
  # Check if the LAPS module is present
  if ((Get-Module LAPS -ListAvailable).Count -ge 1) {
    Write-Verbose "OS is Windows LAPS capable and LAPS module is present"
    return $Result
  }
  else {
    Write-Verbose "OS is not Windows LAPS capable or LAPS module is not present"
    return $false
  }
}
