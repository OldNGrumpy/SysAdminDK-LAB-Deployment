Function Import-TSxSubOUGPO {
  [CmdletBinding()]
  Param (
    [Parameter(Position=0,Mandatory)]
      [ValidateSet('T0','Tier0','T1','Tier1','T2','Tier2','TE','TierEndpoints')]
      [string]$Tier,
    [Parameter(Position=1,Mandatory)]
      [string]$GPOName,
    [Parameter(Position=2,Mandatory)]
      [string]$GroupName,
    [Parameter(Position=3,Mandatory)]
      [string]$CompanyName,
    [Parameter(Position=4)]
      [string]$TierOUName='Admin',
    [string]$GPOPrefix='Admin',
    [string]$Server,
    [switch]$Cleanup
  )
  #requires -Modules ActiveDirectory, GroupPolicy

  # Verify chosen server responds. Otherwise choose the PDC or another server that responds
  if ($Server) {
    $Server = Get-TSxVerifiedDomainController -Server $Server
  }
  else {
    $Server = Get-TSxVerifiedDomainController
  }
  if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
    Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
  }
  
  # Set parameters
  $Path = $PSScriptRoot
  if ($Path -like '*TSxTieringModule\public') {
    $Path = $Path.Replace('TSxTieringModule\public','')
  }
  if ($Path -like '*TSxTieringModule\private') {
    $Path = $Path.Replace('TSxTieringModule\private','')
  }
  $Path = $Path.TrimEnd('\')
  $ADDomain = Get-ADDomain -Server $Server
  $NewFQDNDomainName = $ADDomain.DnsRoot
  $NewShortDomainName = $ADDomain.NetBIOSName

  # Write zip file based on Tier Type
  if ($Tier -eq 'T1' -or $Tier -eq 'Tier1' -or $Tier -eq 'T2' -or $Tier -eq 'Tier2') {
    $FolderName = 'TierSubOUPolicy'
    $ZipFile = "$Path\$FolderName.zip"
    $GPOBackupName = 'Admin - Add Domain Tier Template Group - TSxUnique to Local Admin group'

    # Convert base64 to bytes and write zip file unless it already exists
    if (!(Test-Path -LiteralPath $ZipFile -PathType Leaf)) {
      $TierSubOUGPOTemplate64 = 'UEsDBBQAAAAIAK50J1fHmiXIdAQAAGUPAAB5AAAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgQWRtaW4gZ3JvdXAvezhCQzU5RDcxLUNDNjAtNDIxOS1BNTNBLUZCNDkwN0E1OTg0RX0vQmFja3VwLnhtbN1X62+jRhD/ftL9D1Okk9qT1maX50a2rxhMLtIlsWqn/RBHFYYloTGPAk5iRfnfu4AfgH1JLtL1qiLLXsbzm+fuzGzv00O4gDuWZkEc9QXcEQVgkRt7QXTdF5a5j3Th06D3E0JgxskqDa5vcvjZ/QVOAzeNs9jPOT1N4tTJuYAOgLFYQMmVQcoylt4xrwMIDXrHabxMxvEicFdDx71dJhP3hoUM5rfJ0VY/KfQXlHyVsL6wh5myMFk4OROAmx1lR5y1L9zkeXLU7d7f33fCjVUdNw67NXj3eHx+nrDKzGwNfxN08P4d8Kfuz/n8L+bmg96Eucs0yFflX9na5dKdSbxMXe6QncahZZhfBM4ceDyul6ZlTI3LCcJIQQQjLMtEkTSdIEnEVNclKhdLRVcVTeVUBdOrq0GvW6InTmi4bryM8jMnZDtpoyhnaZIGGQPDC4MoqyAt7ikP8Q5zEQVFFpxFaXQJqBjOWD48OZ9YcegEUVOPYZV8BzisKDsEcLxOzrKc761Oxkpsi/FifPaMG7/u40tAla3vFG/ycrwrD14f6+NFPP8vBbph/0tB7rZ3uR0s2NjJb7Ju45DzssAmLC/kcKYTa6fuUXeZKHnuHPkeVZHseTLSVV9DmuP6cyphnfn6U6m5gFXWPevbmmNjmcUyNw2SPE4HIgZRBFEG6paLlz5Yrr2Wa1YB9RpdAZEA2VLw3kIE3QffA8cF5sFcAt8HDwPGMJcBewWDI4JLQdXBpyDREluD7xTN20RSWsUFFq/+Rq9yAItrREUFIgGlhSOOCq5SSOCGUQIqBZmv1ZKT1CSQ/4sura2ryjKVa2Z8Lf60SfkmbCt3G2zbx0NYTJoU59VYqf66O621M9Gzgox30VWrxhSnHxCvAh6sC8I0YClsWi5U1RXBdPLAm8XfSwZ5DF9i11lUlQOutwWtoeA8KRvnThMuebbkCz4l/F4NAGfLcM7SHadYlZ99hlPHvQki9hUYlrCoySX2MOOaOnrIWVTQj5eBVzPw8lFcP+jA1+Z5etSoTYmqUiQTIiNZU01ETcVE6sgeypauWbZsPF1dPmLN0qk9MpFiypyPagQNMbEQkbFpjGxNVkT6Wml1r9r2F4Fq0nhJ/uP0hFdo3km7mxp+oD5DNdS0B5utsLKpnlh94VEquuXI4Gbpko0wtggydGrwyJiibA+Hpm2Qp2qGK7ZcsQX6wm/sOsjydLUZnjbPc289e1LNVUV/KeUVTaYvfODj2J/2ZGxMP3+Y8Y03+9j5KNSa/ughcSKPeRX3bJald6IozbJVdhcvZo3mMSu9DFg2e11L2qrr1vxoBHUbsBrD91m9kCYb872mmhbSiSEi2eS7zSBYRIolWtwbYshY30vTRXQbxfcRbOXxsWmTBStI20k4NczP20yMU+azlF8dWPZvZWN9CvZVF0UpL+8TVSGbVNq4zQcx3Td5Oavmnx/obMOCb/N5A625fuiYveD7+qfDL1M/Pgx7xrwpInUprYK5O9sN8vry9/5dg1q/4g7+AVBLAwQUAAAACACudCdX6+HH5GUBAABoAgAAewAAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIEFkbWluIGdyb3VwL3s4QkM1OUQ3MS1DQzYwLTQyMTktQTUzQS1GQjQ5MDdBNTk4NEV9L2JrdXBJbmZvLnhtbF2SX0/CMBTF3038DpX3srL/JUgyhhISFRLnE+GhaztsXNu5FYEYvruDBTZ5u+n9nXNPbzuaEPq1LeaqMmAvc1U99j6NKYaWtdvt+lLQUlc6M32qpTUr9bZY6lzQgzVbLhYFL4kRWlXWK1Ei45XpjUd1Y7YVbDx6WMXTKIlWvyHlyGE0hRnDPnQZc2HoZwEMCM1S7AxCnoXH9Xo8sq7auphqSYRqbQjrm3qCUJt+xS/0BbqWt6Nd5HOCObRDxqGbpinEFPnQ8zh17YDaJA2O/81uAsRamVLnOS9b26r8Qcj5L+tyzUoTIXmrsZHtQIQhCpKBPXSCoe2fDbrsfNqNPok9PA0GMI59BF17gGHkORF8nrgYBZGHQ/epiX6SxVpKrkyrP3eup6eYoipycngj3VQRk0IBCCLGQHMPkAhegoTLGjYcnJ+8BpL3/YcS31sOjAYvmpIcNNrNCbiuojvDan/W+P7uD1BLAwQUAAAACACGcydXzaIw0Z4BAACGAgAApQAAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIEFkbWluIGdyb3VwL3s4QkM1OUQ3MS1DQzYwLTQyMTktQTUzQS1GQjQ5MDdBNTk4NEV9L0RvbWFpblN5c3ZvbC9HUE8vTWFjaGluZS9QcmVmZXJlbmNlcy9Hcm91cHMvR3JvdXBzLnhtbIWSPW/bMBCG9wL9DwSndrha/NJHYDmQRLlTgwC2ty6yzLoEJNIVqdRFkf9eSmqcbAGX43t3uOdecn1/7Tv0pAanrckx+RJhpExrT9qcczz6H5Di+83HD+uvgx0vDrWd06cc/2WEijpjCdQliYEfeQtZxjgIzrdVLCmXNH7Gm6Xt1hVLXiRZHcpoVgHnKYGilBFsRSmTushYWSTPGJmmVzkuTr022vmh8XZw6NNx1J0HbT5jpPvmHCooRqNTQ2WNV1ef48A+qN4+qUfb6fbPLLQ/G3NWYTiNKIMogyhBhN7R9I6E7DhjSVHIiDMJWRqnwEUVQVpUCRAm6rKWktJqOy3zONiLGrxWDjWtnw07BFr1+2EGxuikXDvoy5Karp3yqui6Q6B0M85NWvx8w1y0rR2NX6TzlN1NcDsgIIDRydn/+sM79mzW31R/DBNfghdD5Xdp+0YbtNdB3Kv+0jVeoeWNAO1314PRv0aFb+sVUmLkXjkoAcI5FSxJKbCIZGnKMj6FIo1FEgeVROHg1Wa9ulGsXo0Ll3nc9KWWyIXwH1BLAwQUAAAACACudCdXuccRbigIAACwPwAAewAAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIEFkbWluIGdyb3VwL3s4QkM1OUQ3MS1DQzYwLTQyMTktQTUzQS1GQjQ5MDdBNTk4NEV9L2dwcmVwb3J0LnhtbO1bbXPaRhDez53pf2D6KZkpNmDAL6HJUGOnnrENY3DddPpF5sV2azCxcJpMJn+97bPPSZwkJBCOg51Go5F0utv329vdE+jff2rySt7LUK4lJ++kL7fiypXcyEh+kh+kKGtSwD2HkZF00d/D6EguOHonExlIHlBVPL2Sl/K9fCc1eS0taQLH0B2B4g7aLnAV6xJYExmjbx3H3zzWcG7gegP+F+gtgWsBdNflNzmSQ2mD9yVkGIpDaaKUrx6Ecp66uaDhUNt+hFcyjyEwu+BwA6gb2GSCPrXWEDCv2X8HnBbu14T8gP426CstY08XtI39cjhqcgBrqc11fIBTZ8aOJ8N8OXk7uI7Bw0j6UbZooQKs20PrHNYboLUNX8hLGa0ernlAVdG/idYmrNpF+xwwG5iBLWAPcP0ETdZT6dughA4ttio9Hci1Brw+/cLM1RrafUodlCg4e4v0qckxsIbofSl1QA49nfI467RdLqJtZzq/HXrrGBI7lCsX0MRQ6MC33ssp8K7kLfoVZgKIHPz9Blo6XO1BvhdTCiq7lS3oj7oirgGjeu1StqGnoQvICSjceVZZBGup7gKr7+nRo46Gr67SErwkj/s2r5sYLaJvB2cV1yJGlVcSBcvjyItaZhbSc9kilwK5JNOwfE4oR1r6G2gbXdbQU6Q+Vamg53dynKVmOWnk6MK6txibwFsb9M4un8ec6dm10wZUA/O/inWzPiOhrqQmeDTgda+9ewP3Fu4H8gxjdXmBuTzg9QRXtbKJFz3MxIDRRWPHBvNNEb1FtM4RY7SdZ1R3cHYZgRRDo8w2KL0A7VN5Di51Pu3iaOA8xNmWM3Br4dpCXwd9TVrqBGNnuJ/h+QUPldin4cv5mHTatEMeHpOHzxT5VMZRQo/61hZaebQ0123jaYvWKE97K4zMFUBWPdgKIcOyHXI2WpRDZTC89yBJGrig3T9P1zchOgccuR+tXbSeY2xn6nmnU6oN9CuPM1JqEH5Aa/VxPYdvqZ226YmFiB9WmQmNH+qhma3ANb0JvCKpGqsFOTYjXMP8znG/P79zroEq865DPykwHlenlJSmw0hXma4gh3eVoQzsPkbvJ/ngCUleY0Qy8S8aF5uIdyNZVeUUHxmDEvnRWq27ComU/5eJJSXP7qpJnI5+lbEqLTXj/CHhqsrWQG5C5ePXc9ZPomPB6uvLa5J50NfqQZZHdKxFv1Iqrvi7bxe9t+Rs6uZV6BjvW8HKPo2k6bR7PH1m/Uj3K5eUUqFc2SflIeg61MxoNeC+yd/5pcOZ5dWhNXUv2ccRb5tZvDjceCgD+Xirf3vumrUSrnrtHuM5x4q0I7+wSj1A6w3W8x7H9lg/am8bbd19N7Hr0xrxGE9aNSrUCe6HOBS6PWe9Wz3XU81abSptznuftUN/1R61Spyf+BhxPm3pzsPUiHaN4wY2TlrdFjZZv/kQ4ZWi+7r5a8lAxNOqg9PYm2MHdeIV22qpeTboQBONBNfgG45n4ZH5FPxdtq5t3ZvqCm9Chj9FY4x5sxHWKy3W8nx3OTcTLwuZt7azmqXHXCTBFWOayhtH04VGI+j9IcEC6bGTfGzZedcIaN7i9hiPkzzKwJr31TaOqAfWwalLaV2s9hH6h6Dhv5Ux+TwtVpJW6WSshageAdaVvwBb8CwTNzabd6JxKG3m+f9nLH0T/bXlLH0j0mbWOsqyUJaFsiz0TWWhPemR74/A69Fv+vRYfR6K/0vFBzy5Et7/ZHlrEV4c7tPMWw/3nuWp7tnM+5Y9rk+dvTH92KUE6d67WNmzDJhlwEVYy/PNMmCWAbMM+FgZUH8LfJqZK3nnVhf919ylmDfEZh2ZWJsDtOtFgiyjZRkty2jfUkbz5dCcFfxFORhlsty1CC8O92nmrofbvc3/ldzquuoceP9fy63MWY7LctwirOX5ZjnucXJctmubn8GSosgsnO4ijC3VDy/kqfxXKOy/86W0OtViqPm+rs+z/2mvyT69eEJrNcThzNblHVfmNb1cvSu8qtPiWC67tMeYe7Z+SAIz/quYGGDmKbhWVV5dXyY7L4abR7cNCBdy6kzEUwxDhGnpuvB160UsEh2LYr6n3qOA5MZqcR4/Cx3+TustapWH9Ub1meAXVOtyCCjzLVV8JaAy7EyhovhJtUBtiud/PXNKL1b71xlPrIQu4LtcA1divnf7KBus0iqw0DbrvDxaP0vR+1JKv2Ho8p9TOlpmVadV4T68rwqLl9DWa1U+LahWjJTB3UNUEqVXhsyb4LXn8SqhvUtJyqgqtSqtQ7oG/2O9j3FtbwK6Tvl+JvYnWlh9Z+hZ1lZ2GrnUxxzPu9Uiz6Dlnbf68oR6TgpXrA0vPBol9t15tvVzbZ9+pePmS0RdOZot9GvFoD9YCP2iz+Gc9j3N477EyUn0Sx/D3VqrAe3rtEQZuA3O0RZrb7VWBRKqjbYAs8tZ1W94Kpxb/UJC56yEkf0F8xaeO81xYb9syi2zpUYf874rHWwafi36ypgYSqPP2XIYmcwaVkucerPdx0o9Dsy59vYkHKctlj/qZ3lTLduVY+drFiq4nuJn3uRhhTFVkIW6mOK2p3MZ3HlteDsn9fcw/PFn+vN8mwftfkRNzmVRBbkIN7oGZ3dcHfmc7wbVPlFvqNO3dcRGloff2RYJq6dyWk9hI7sylrGuxYpbC4twDWawrlDvmCdtcP361k+uWJfJO/FV6GxWjoOz+/DgF6KWW05M3ZwLcUzewcdznq0eFC65xqpNJVi+7io8eN0VR3GZuitcGydVXjoW1trufV7Kf1BLAwQUAAAACACudCdXCW4+C30BAADVAgAAVAAAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIEFkbWluIGdyb3VwL21hbmlmZXN0LnhtbKWSzU7rMBCFX8V078T5j6MQKU2hQoILEmGFWDi2AxaxHWKXgq54d9IG2sCW3dg+58zn0eRLQp83vQFvslPmdPFkbZ+57na7daSggza6tQ7V0l0PetPf6E7Qd3d9c33d84FYoZVxr4gSLTd2MWVksjX2j0G7iOyVD2a8P114DloU+QR6oYwt8tG33ghW5Cf31aqsy/v/KeUoYLSBLcMxDBkLYRq3CUwIbRsceClv04+HhyJ3D96xWGlJhDrGEObYEUCoR8fwb/W36FD+bh2imBPMoZ8yDsOmaSCmKIZRxGnoJ9QnTfLxM+wXQKWVHXTX8eEYa4ZXhIKftrluGkctJD96fOQHEGGIktrzsyDJ/HgfMNderOboyyrCq8SDVRUjGPoehmUUlPB8GWKUlBFOw7MJfWertJRc2aN//3K43WEK03fk/R+ZU5VMCgUgKBkD0z9ALfgAai5HseVgvxGjoL59u1PiZcOB1eBSU9KByfu4ExxGMe/hzrfi62CKT1BLAwQUAAAACADpdCdXfzPCc1gBAAC0AwAAEQAAAE1pZ1RhYmxlLm1pZ3RhYmxlrZHNT8JAFMTnbOL/0HCnoCYeTC0eSLxoJAETrwUqNOkXFPz459XfPkgWDOiFbMou783OzM77/orU04cK5Qr0plRLNcpUqdStWrpQqC57QKfUhPqUbqmZddda6VVtUNf86ynWuc4U6RHMDKaE/oZrxHmMRgrTRq1E54ZzA6PjmoNdqabWYb3bCvmu+K3gmlG9xEsXtY5e0HjQEEdzOAvYWweYs5Mwt+3FDRyJZZD+0jquUXBzgkIFqiKpFTWXYQHm3upr7gzYc0N+Wn2gJ1Zts/AJNvT+yrW1TT9guQkkMNTbWfnOpjtCyfHHqOXwjEHnO44itDxm/+7QMEvLIVbfXpOYTsCdzFy7k8uuhtV5dVP37AGJOsSQDJ+5l2lBPdUd2CkJOXxjL3TeQ86pOdpX3nfV37nj0zm1vwm7U3GcjifEr+cPmfCCSmlujznyM+ocnFL0z5xj/QBQSwECFAAUAAAACACudCdXx5olyHQEAABlDwAAeQAAAAAAAAABACAAAAAAAAAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgQWRtaW4gZ3JvdXAvezhCQzU5RDcxLUNDNjAtNDIxOS1BNTNBLUZCNDkwN0E1OTg0RX0vQmFja3VwLnhtbFBLAQIUABQAAAAIAK50J1fr4cfkZQEAAGgCAAB7AAAAAAAAAAEAAgAAAAsFAABBZG1pbiAtIEFkZCBEb21haW4gVGllciBUZW1wbGF0ZSBHcm91cCAtIFRTeFVuaXF1ZSB0byBMb2NhbCBBZG1pbiBncm91cC97OEJDNTlENzEtQ0M2MC00MjE5LUE1M0EtRkI0OTA3QTU5ODRFfS9ia3VwSW5mby54bWxQSwECFAAUAAAACACGcydXzaIw0Z4BAACGAgAApQAAAAAAAAABACAAAAAJBwAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgQWRtaW4gZ3JvdXAvezhCQzU5RDcxLUNDNjAtNDIxOS1BNTNBLUZCNDkwN0E1OTg0RX0vRG9tYWluU3lzdm9sL0dQTy9NYWNoaW5lL1ByZWZlcmVuY2VzL0dyb3Vwcy9Hcm91cHMueG1sUEsBAhQAFAAAAAgArnQnV7nHEW4oCAAAsD8AAHsAAAAAAAAAAQAgAAAAagkAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIEFkbWluIGdyb3VwL3s4QkM1OUQ3MS1DQzYwLTQyMTktQTUzQS1GQjQ5MDdBNTk4NEV9L2dwcmVwb3J0LnhtbFBLAQIUABQAAAAIAK50J1cJbj4LfQEAANUCAABUAAAAAAAAAAEAIgAAACsSAABBZG1pbiAtIEFkZCBEb21haW4gVGllciBUZW1wbGF0ZSBHcm91cCAtIFRTeFVuaXF1ZSB0byBMb2NhbCBBZG1pbiBncm91cC9tYW5pZmVzdC54bWxQSwECFAAUAAAACADpdCdXfzPCc1gBAAC0AwAAEQAAAAAAAAAAACAAAAAaFAAATWlnVGFibGUubWlndGFibGVQSwUGAAAAAAYABgCNAwAAoRUAAAAA'

      $bytes = [System.Convert]::FromBase64String($TierSubOUGPOTemplate64)
      [System.IO.File]::WriteAllBytes($ZipFile, $bytes)
    }
  }
  if ($Tier -eq 'TE' -or $Tier -eq 'TierEndpoints') {
    $FolderName = 'CompanySubOUPolicy'
    $ZipFile = "$Path\$FolderName.zip"
    $GPOBackupName = 'Admin - Add Domain Tier Template Group - TSxUnique to Local Remote Desktop Users group'

    # Convert base64 to bytes and write zip file unless it already exists
    if (!(Test-Path -LiteralPath $ZipFile -PathType Leaf)) {
      $CompanySubOUGPOTemplate64 = 'UEsDBBQAAAAIAK10J1e93wqlfQQAAHQPAACIAAAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgUmVtb3RlIERlc2t0b3AgVXNlcnMgZ3JvdXAvezg5MjNFRjZDLTA5MTgtNDZERC1BQjQ4LUREM0Q5MTc0NzIyMX0vQmFja3VwLnhtbN1XW2+bSBR+r9T/cBap0m6lsZnhOpHtLgaTRmoSqzi7D3W0wjBO2JhLASexovz3HcAXwG6SRup2tShKhpPvO9eZc4beh/twAbcszYI46gu4IwrAIi/2g+iqLyzzOdKFD4PeLwiBGSerNLi6zuFX7zc4Dbw0zuJ5zuVpEqduzhV0AIzFAkpUBinLWHrL/A4gNOgdp/EyGceLwFsNXe9mmTjeNQsZzG6So619UtgvJPkqYX1hjzNhYbJwcyYAdzvKjji0L1zneXLU7d7d3XXCjVcdLw67NXr3eHx+nrDKzWxNfxV18PYN8Kcez/nsb+blg57DvGUa5KvyX9k65DIcJ16mHg/ITuPQMsxPAgcHPs/rF9MyJsYXB2GkIIIRlmWiSJpOkCRiqusSlYuloquKpnKpgunl5aDXLdmOGxqeFy+j/MwN2U7bKMpZmqRBxsDwwyDKKkoLPeEp3nEuoqCogrsonS4JFeCM5cOTc8eKQzeImnYMq8QdQFhRdojg+p2cZTnfW52MldwW8GJ89kQYv+/zS0JVrR+Ub/J8vqsIXp7r40U8+y8luuH/c0nutne5HSzY2M2vs27jkPO2wByWF3o46MTamXvAIpElTcVoLro6kn0PI5e6KvKJqxKqSC7VvMfSckGrvHsytjVi45nFMi8NkjxOByIGUQRRBuqVi+d+sFx7LdesIuo1uQIiAbKV4L2FCPoc5j64HjAfZhLM5+BjwBhmMmC/ALgieBRUHeYUJFpya/SdoVlbSEqvuMLidb6xqxzg4ppQUYFIQGkRiKuCpxQauGOUgEpB5mu1RJKaBvJ/saW1bVVVpnLNjW/lnzYl38Vt1W7Dbcd4iItJU+K+mCvVX3entXYmelaQ8Sm6avWY4vQD4l3Ah3VDmAQshc3Ihaq7Ipg493xYfF0yyGP4FHvuAj6zMOYIbuMmjxO44HM/g6ttf2vYO0/KObozjEvMVlyQ/6juA2fLcMbSHVKsutE+4NT1roOIfYOGJSxqcsk9DFxLR/c5iwr58TLwaw5+eRDXDzrwa/M8PmjUpkRVKZIJkZGsqSaipmIidWQPZUvXLFs2Hi95+9MsndojEymmzHFUI2iIiYWIjE1jZGuyItKXaqtH1fa/SFRTxjv0n6cnvGHzwdrdtPQD7RqqO077nrNVVs7YE6svPEjF8BwZ3C1dshHGFkGGTg2eGVOU7eHQtA3yWF3pih1YbIG+8JldBVmerjZ3qc3z1FvPdqprVjFuSn3FzOkL7/jt7C/bGRuTj++mfA9P33feC7U7wOg+cSOf+RV6Os3SW1GUptkqu40X08YsmZZRBiybvmxCbc11a3E0krpNWA3wY1bPlMnGfK+ppoV0YohINvluMwgWkWKJloS5UMb6Xpkuopsovotgq4/fojZVsIK0XYRTw/y4rcQ4ZXOW8i8Jlv1b1Vifgn3TRY/Ky8+Lqq85lTXu80FO91VRTqvr0E8MtuHB98W8odZCP3TMnol9/afDv61+fhr2nHlVRupaWg1zd7Yb4vW34Ns3DWn9i3fwD1BLAwQUAAAACACtdCdXBNM9DnIBAAB3AgAAigAAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIFJlbW90ZSBEZXNrdG9wIFVzZXJzIGdyb3VwL3s4OTIzRUY2Qy0wOTE4LTQ2REQtQUI0OC1ERDNEOTE3NDcyMjF9L2JrdXBJbmZvLnhtbF2SUU/CMBSF3038D5X3sq4bGyNIMqkSExWi88nwULqLNq7tXItoDP/dAYEN3m56v3Pu6W2HN1x8rsp7bR36UYW2150P58qB563X666SojLWLF1XGOVNKrMqZ6aQ4tebzKbTEirupNHWe+RaLsG6zmhYNyYrmY+GV29jlmbp259PaBjEkY+XhPdxmAsf84RHOKc8okkv4EksNvP5aOgdtXXBjOJSNzY877p6gtTvXQsH+gAdy7PR/ZBEwBPAtJ8DDheLBU4EiXCvByKksaB8EW9Ozc4CjI12lSkKqBpbW30TEpzK2tx+pZlU0GgooQEmCSZx5tNBEA8o3Rm02XvWjp7Q4PYuGtciv95axBhOb8I+ZixgiR+HMaX+PvpWNjZKgXaNftc5nm5jSlsW/PeJt1OluZIaYZTmOdrfA2USKpSBqmEHaPfkNZC9/Lxq+bUC5Ax6MIIX6BmUqQkG9tOZEr1aqCx63/LHzbRHes1HG11e/ANQSwMEFAAAAAgArnMnV1PDXAyPAQAAcQIAALQAAABBZG1pbiAtIEFkZCBEb21haW4gVGllciBUZW1wbGF0ZSBHcm91cCAtIFRTeFVuaXF1ZSB0byBMb2NhbCBSZW1vdGUgRGVza3RvcCBVc2VycyBncm91cC97ODkyM0VGNkMtMDkxOC00NkRELUFCNDgtREQzRDkxNzQ3MjIxfS9Eb21haW5TeXN2b2wvR1BPL01hY2hpbmUvUHJlZmVyZW5jZXMvR3JvdXBzL0dyb3Vwcy54bWyNUstu2zAQvBfIPxA8tYet+ZTEwHJAmXJPDYLavvUiy6xLRKJUPdIARf69lJQ4PRa87M7ucmaHXN891xV6sl3vGp9i+plgZH3ZnJ2/pHgcfkCC7zY3H9ZfumZse1RWvTun+A+nTOaKx5BnNAJxEiUoxQVIIXbbyDBhWPSCN8vYdSoyQscqD21MbUGIhILODIGdzEyca8UzHb9g5IvapvibrZvBImP7x6Fp0bEPItHH0+iqAZz/hJGri0voYxiVPwt/sYGBEcaBKCAxouyWqVsWYTTO3HHg4EoKiLaEg2A6A53IGHYJkzQzKmfcTIofuqa13eBsj4pymF05Bkn29/2sCqOz7cvOtUtpSis7WF1Vs8AUk3+gxbQZ68I2T1aXZTP6YYEuU3U/idsDBQmcgZTyFb//Lw8266+2PgXwLXj1TpvvpqkL59HBBfBg67YqwkXLcwA67J+P3v0aLb4uqY3BqH9XwyhQIZjkccKAE6qShCsxhTKJZBwFlJJw8GqzXl1VrN7tC8lMN/2eJepD+BdQSwMEFAAAAAgArXQnVzjAWCsaCAAApD8AAIoAAABBZG1pbiAtIEFkZCBEb21haW4gVGllciBUZW1wbGF0ZSBHcm91cCAtIFRTeFVuaXF1ZSB0byBMb2NhbCBSZW1vdGUgRGVza3RvcCBVc2VycyBncm91cC97ODkyM0VGNkMtMDkxOC00NkRELUFCNDgtREQzRDkxNzQ3MjIxfS9ncHJlcG9ydC54bWztW1tvGkcUPs+V+h9Qn2KpNhdj8IU6IgYnlmyDDK6bqi9rLrZbg4kXp4mi/PW23/lml72wC4tDsNOsVnubOfc5Z86Zhfn3n4q8lA8ykFvJyHvpyb3YciN3MpRf5CfJy4bkcM+gZygdtHfRO5Qr9j7IWPqyDqgS3l7KvvwoP0hFXktTGsAxdIeguItnG7iKdQ2ssYzQlsXxN48NnJu43oH/FVoL4JoD3az8JidyLC3wvoYMA7EoTZjyzVIor1M3GzQsatsL8YrnMQBmBxzuAHUHm4zRptYaAOY12x+A08T9lpAf0d4CfaVl7GmDtrFfBkdFjmAttbn293HqyHj98TBfT942riPwMJJ+gg1zsGYR1i1j/POwXh8tlmzjqQjJOmyzZAdnCU9dQOtTAS1bwNKeMqA+Q5NsIn1rlNCixValpwW5NoDXo1+YsdrAc49S+yXyj948fSpyCqwBWvelCsiBo9M6Tn3v4h7Utj0Z3za9dQSJLcqV8WliKLThWx/kHHg38g7tCjMGRAb+fgctLUb7GencOTRq1PAvwimdc+qos0EGGrv0VTNPcr+3arzcAka1PqDkA0d/G5BjUHhwbDYP1qN6AKyeo2WXFjB8C/S8Teiagw/ptYzePNp2cZZw3cRVecVR8HicOHOaGaPkXHYcXsolnobH54xyJKWvMbXL6NpgdBUBoTqV5HdynKbmcdJ5pQPr3qNvDF82I9vh+4jjOx1ZLUDV4B2riKrslIQaZw3wqMH3Xzv3Gu5N3I/kBfqqsoexPOL1DFe1sgUafdy3mYP6OC5pzTyOLueeS9hNn9c551s4O7BjiRhqzx1Q2gPtc1kDlyrfDnDUcB7jbMkFuDVxbaKtjbYGLXWGvgvcL/C+x0Mldmm4cj4lnRbtsI55dh1elOdbEUeBM28ZFiigbZOZcAdv27RGcdK6hZYSrmVaq0BKChmU7Zij0aQcKoPhXYckSeD8dv8yXd8G6Byx53G0DvC0hr7dieedT6jW0K48LkipRvg+rdXD9RK+pXbaoSfmQn5YQsum44d69GHVHCO6zDy5R4prIY6NENcgv0vcH8/vkjGg7xaOLcLqfFyaUMoxexeAuTWJIIt3lUFnpB56Hyd5/xlJXuGMZOa/8LzYwHw3lFXVVdEzo18id7ZW665CIuX/deaSgmN31SRKR7fKWJWWmnH+kGDN5VVmdkzl41Z7np+E+/y12dfXJPWgb9WDPB7hvib9SqnY4q7NbbTek7Opm1ehY7Rv+Sv7JJIm0+7p9Jn2I12vXFNKhbLlkJQHoGtRM6NVn6sqd12YDGeaV5vW1JVmD0e0babxonCjoQzk00X/zsyY9SRcdeye4j3DirQtb1ilHuHpLeK5zr4660dtbeFZV8sNrPq0RjzFm1aNCnWG+zEOhW7NiHdPz2yiUatMpM04X7t26a/aolaJ8hMXI8qnPbqzMHVGu8VxBxvHRbcHG6/fbIhgpOi6bnYsGYhoWlVwGjljbKFOvOGzWmqWDdrQRGeCW/ANzmfBntkU3FW2xrauTTXCG5DhT9E5xnzZCOqVFGtxvgccm7GThcxXnGnNkmPOk+CGc5rKG0XThkZD6P0xxgLJseN8bNFx1xnQfOPtcj6O8ygDa75me/OIemAVnDqU1ka0D9E+AA33q4zJ50mx4rRKJmMlQPUEsPoVbx9Vk7FMVN903gnPQ0kzz/8/Y+VRcX5rOUu/iLSYtU7SLJRmoTQLfVdZqC5d8v0ZeF36TY8eq+/6e4/5peIj3mwJrn/SvDUPLwr3eeat5X1nea5rNvO9pc741NEb0Y9tSpDsu4sne5oB0ww4D2txvmkGTDNgmgGfKgPqb4HPM3PFr9yqov+puxbzhdjEkZlr/f/ISTNamtHSjPY9ZTRXDs1Z/l+U/bNMmrvm4UXhPs/ctbzV2+xfyT1dV50DH/9ruSdzmuPSHDcPa3G+aY57mhyXrtpmZ7C4WWQaTlcRxpbqh1fyXP4rFPTf2VJ6OlUiqLm+ru/T/2mvyCG9eExr1cTiyFblPSPzll6u3hWM6qQ4HpcD2mPENVsvIIHp/1XMHGDGyR+rKq/Gl8nO8+Fm0W0BwoacOhLRFIMQQVoaF65u3ZBFwn1hzA/Ue+iT3FgtyuOnoYO7uN6hVlmuN6rP+PdXZeUYUGanVXQloDLsTqDC+HG1QGWC5+6tOacXq/2rnE88CW3AdxgDN2J2w31C7ZZnjVfnnoQy6ra6vJI8/89cFN3D0OE/p7S3yKpOq8JDeF8JFtc9Inotyec51YqR0r96CEui9IqQuQxedYeX7nQ5oCRFVJValVYhXY3/sT5Evz6XAV2lfK+I/ZkWVt8ZOJZNvtfoBTR+cCJxnbZfI7Ub1olXDr0C23TnnsXR6Tk6RO2pyUh4z47iPvj0Ljt6aD29Rb1L0Nn8D13ra9VY9d5mda16b3PE8sRSWynP2pwRCI6CZqughzWYdcw8Yr5cJYNNwq/JUR8RQ2n0aGuLc4yJRrXEuTNuPcTcqW/0tLUrwRnXw3J73Xxt6l5vTBUmFwPljwwP7t7xlveE6zDSH8TUMx7U1QS3NRlL/xpq01kD6RGEP12iZ862v38MTsjpUubVhfNwg5EVtY5qy5fsFVRbhT1DudTYY0faejnr1Txh9VRO2QQ28qJkEet6WFFxMQ/XYPqrBfWOWdL6Y9m1fnwdukg2ia4tp3NtFJy3uvbvCvV7vKmGMwGO8evyaM7TNYHCxVdOlYkEi1dTuaVXU1EUF6mmghVvXD2lfUGtvRXNvvwHUEsDBBQAAAAIAK10J1eDbXePjQEAAOQCAABjAAAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgUmVtb3RlIERlc2t0b3AgVXNlcnMgZ3JvdXAvbWFuaWZlc3QueG1spZJPb6MwEMW/ijd3gzEEAqJINN6NKvWfdump6sExk65VbFPsNK1W/e7rhG1Ce93b2P69N8+jKc+5eNr2Fr2qTtuz2W/n+iIMd7tdoKQYjDUbFwijwtVgtv2t6aR4C1e3Nzc9DNxJo214xbXcgHWz0aNQG+v+02hvUbzAYP392SwKyKwqx6AX2rqq9LrVVrZV+e1+yeqmvv8TEZrEWRrhDeELnLQiwjznKW4pT2k+j3meifeHh6oMj1pfMKO41Ccb3gbOB5D6MbDwQX9Ax/JL60VCUuA5YLpoASfr9RrngqR4PgeR0ExQvs7eP5t9CbA02g2m62A42drhhZD4s2zKjeNopIKThhIaY5JjkjURLeKsoPRgMGUv2DR6TuPvP9KlF0V+ailjuD5PFpixmOVRlmSURmP0vWxplALtTvrDy/F2H1PavuNv13yaqm6V1Aijum3R+A/USBhQA8rDDtBhIzzQ/Hq90/J5C8gZdGkE79BPUMYTDOyTMz26s34n0OOeP05m2jKcLsm/g63+AlBLAwQUAAAACADpdCdXfzPCc1gBAAC0AwAAEQAAAE1pZ1RhYmxlLm1pZ3RhYmxlrZHNT8JAFMTnbOL/0HCnoCYeTC0eSLxoJAETrwUqNOkXFPz459XfPkgWDOiFbMou783OzM77/orU04cK5Qr0plRLNcpUqdStWrpQqC57QKfUhPqUbqmZddda6VVtUNf86ynWuc4U6RHMDKaE/oZrxHmMRgrTRq1E54ZzA6PjmoNdqabWYb3bCvmu+K3gmlG9xEsXtY5e0HjQEEdzOAvYWweYs5Mwt+3FDRyJZZD+0jquUXBzgkIFqiKpFTWXYQHm3upr7gzYc0N+Wn2gJ1Zts/AJNvT+yrW1TT9guQkkMNTbWfnOpjtCyfHHqOXwjEHnO44itDxm/+7QMEvLIVbfXpOYTsCdzFy7k8uuhtV5dVP37AGJOsSQDJ+5l2lBPdUd2CkJOXxjL3TeQ86pOdpX3nfV37nj0zm1vwm7U3GcjifEr+cPmfCCSmlujznyM+ocnFL0z5xj/QBQSwECFAAUAAAACACtdCdXvd8KpX0EAAB0DwAAiAAAAAAAAAABACAAAAAAAAAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgUmVtb3RlIERlc2t0b3AgVXNlcnMgZ3JvdXAvezg5MjNFRjZDLTA5MTgtNDZERC1BQjQ4LUREM0Q5MTc0NzIyMX0vQmFja3VwLnhtbFBLAQIUABQAAAAIAK10J1cE0z0OcgEAAHcCAACKAAAAAAAAAAEAAgAAACMFAABBZG1pbiAtIEFkZCBEb21haW4gVGllciBUZW1wbGF0ZSBHcm91cCAtIFRTeFVuaXF1ZSB0byBMb2NhbCBSZW1vdGUgRGVza3RvcCBVc2VycyBncm91cC97ODkyM0VGNkMtMDkxOC00NkRELUFCNDgtREQzRDkxNzQ3MjIxfS9ia3VwSW5mby54bWxQSwECFAAUAAAACACucydXU8NcDI8BAABxAgAAtAAAAAAAAAABACAAAAA9BwAAQWRtaW4gLSBBZGQgRG9tYWluIFRpZXIgVGVtcGxhdGUgR3JvdXAgLSBUU3hVbmlxdWUgdG8gTG9jYWwgUmVtb3RlIERlc2t0b3AgVXNlcnMgZ3JvdXAvezg5MjNFRjZDLTA5MTgtNDZERC1BQjQ4LUREM0Q5MTc0NzIyMX0vRG9tYWluU3lzdm9sL0dQTy9NYWNoaW5lL1ByZWZlcmVuY2VzL0dyb3Vwcy9Hcm91cHMueG1sUEsBAhQAFAAAAAgArXQnVzjAWCsaCAAApD8AAIoAAAAAAAAAAQAgAAAAngkAAEFkbWluIC0gQWRkIERvbWFpbiBUaWVyIFRlbXBsYXRlIEdyb3VwIC0gVFN4VW5pcXVlIHRvIExvY2FsIFJlbW90ZSBEZXNrdG9wIFVzZXJzIGdyb3VwL3s4OTIzRUY2Qy0wOTE4LTQ2REQtQUI0OC1ERDNEOTE3NDcyMjF9L2dwcmVwb3J0LnhtbFBLAQIUABQAAAAIAK10J1eDbXePjQEAAOQCAABjAAAAAAAAAAEAIgAAAGASAABBZG1pbiAtIEFkZCBEb21haW4gVGllciBUZW1wbGF0ZSBHcm91cCAtIFRTeFVuaXF1ZSB0byBMb2NhbCBSZW1vdGUgRGVza3RvcCBVc2VycyBncm91cC9tYW5pZmVzdC54bWxQSwECFAAUAAAACADpdCdXfzPCc1gBAAC0AwAAEQAAAAAAAAAAACAAAABuFAAATWlnVGFibGUubWlndGFibGVQSwUGAAAAAAYABgDYAwAA9RUAAAAA'

      $bytes = [System.Convert]::FromBase64String($CompanySubOUGPOTemplate64)
      [System.IO.File]::WriteAllBytes($ZipFile, $bytes)
    }
  }

  # Extract zip file
  Try {
    Expand-Archive $ZipFile -DestinationPath "$Path\$FolderName" -Force -ErrorAction Stop
  }
  Catch {
    Add-Type -Assembly "System.IO.Compression.Filesystem"
    [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipFile, "$Path\$FolderName")
  }

  # Update groups.xml GPO Preference for each GPO with new domain and group SID
  $PrefGroupXMLs = Get-ChildItem -Path $Path\$FolderName -Recurse -Filter groups.xml
  foreach ($PrefGroupXML in $PrefGroupXMLs){
    [XML]$XMLFile = Get-Content -Path $PrefGroupXML.FullName
    foreach($Member in $XMLFile.Groups.Group.Properties.Members.Member){
      $Object = $Member.name.Replace("AD\Domain Tier Template Group - TSxUnique","$NewShortDomainName\$GroupName")
      $Member.name = $Object

      $NewSid = (Get-ADObject -Filter 'Name -EQ $GroupName' -Properties objectSid -Server $Server).objectSid.value
      if ($null -ne $NewSid) {
        $Member.sid = $NewSid
      }
      else {
        Write-Warning "Could not find group:""$GroupName"" while attempting SID lookup. Remove then Add group manually in GPO after completion!" -Verbose
      }
    }
    $XMLFile.Save($PrefGroupXML.FullName)
  }
  
  # Update migration table and write new migration file
  $MigTable = Get-Content -Path $Path\$FolderName\MigTable.migtable
  $MigTable = $MigTable -replace "customer.domain.fqdn", "$NewFQDNDomainName"
  $MigTable = $MigTable -replace "<Destination>Domain Tier Template Group - TSxUnique", "<Destination>$GroupName"

  $MigTable | Set-Content -Path $Path\$FolderName\UpdatedMigTable.migtable -Encoding UTF8

  # Create backup of GPO if it already exists and is modified
  Do { 
    $GPO = Get-GPO -Name $GPOName -Server $Server -ErrorAction SilentlyContinue
    if (!($GPO)) {
      Start-Sleep -Seconds 2
    }
  }
  Until ($GPO)
  if ($GPO.User.DSVersion -ne 0 -or $GPO.Computer.DSVersion -ne 0) {
    if (Test-Path -LiteralPath "$Path\GPOBackup$(Get-Date -Format "yyyyMMdd_HHmm")" -PathType Container) {
      $CurrentGPOBackup = Get-Item -Path "$Path\GPOBackup$(Get-Date -Format "yyyyMMdd_HHmm")" -Force
    }
    else {
      $CurrentGPOBackup = New-Item -Path "$Path\GPOBackup$(Get-Date -Format "yyyyMMdd_HHmm")" -ItemType Directory
    }
    if (Test-Path -LiteralPath "$($CurrentGPOBackup.FullName)\$($GPO.DisplayName)" -PathType Container) {
      $CurrentGPOBackupPath = Get-Item -Path "$($CurrentGPOBackup.FullName)\$($GPO.DisplayName)" -Force
    }
    else {
      $CurrentGPOBackupPath = New-Item -Path "$($CurrentGPOBackup.FullName)\$($GPO.DisplayName)" -ItemType Directory
    }
    Backup-GPO -Guid $GPO.Id -Path $CurrentGPOBackupPath -Verbose:$VerbosePreference
    Write-Warning "Existing GPO ""$($GPO.DisplayName)"" has been modified after creation.`nThe GPO was overwritten but a backup of the old GPO was created in:`n""$CurrentGPOBackupPath"""
  }

  # Import GPO Settings with updated migration table
  Try {
    Import-GPO -Path $Path\$FolderName\$GPOBackupName -BackupGpoName $GPOBackupName -MigrationTable $Path\$FolderName\UpdatedMigTable.migtable -TargetName $GPOName -Server $Server -ErrorAction SilentlyContinue -Verbose:$VerbosePreference | Out-Null
    Write-Verbose "Created GPO: $GPOName and imported settings for group: $GroupName"
  }
  Catch {
    Write-Error "Could not import GPO $GPOName. Configure manually!"
  }
  
  # If cleanup switch is set cleanup zip files and extracted content
  if ($Cleanup) {
    if (Test-Path "$Path\TierSubOUPolicy.zip" -PathType Leaf) {
      Remove-Item -LiteralPath "$Path\TierSubOUPolicy.zip" -Force
    }
    if (Test-Path "$Path\CompanySubOUPolicy.zip" -PathType Leaf) {
      Remove-Item -LiteralPath "$Path\CompanySubOUPolicy.zip" -Force
    }
    if (Test-Path "$Path\TierSubOUPolicy" -PathType Container) {
      Remove-Item -LiteralPath "$Path\TierSubOUPolicy" -Recurse -Force
    }
    if (Test-Path "$Path\CompanySubOUPolicy" -PathType Container) {
      Remove-Item -LiteralPath "$Path\CompanySubOUPolicy" -Recurse -Force
    }
  }
}
