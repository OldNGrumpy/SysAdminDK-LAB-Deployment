Function New-TSxAdminAccountName{
  [CmdletBinding()]
  Param(
    [parameter(mandatory=$true)]
        [string]$Prefix,
    [parameter(mandatory=$true)]
      [ValidateNotNullOrEmpty()]
      [string]$FirstName,
    [parameter(mandatory=$true)]
      [ValidateNotNullOrEmpty()]
      [string]$LastName,
    [parameter(mandatory=$true)]
      [ValidateSet('T0','T1','T1L','T2','T2L','TE','Con')]
      [string]$AccountType
  )

  # Remove special chars from first and last name
  $FirstName = Remove-Diacritics $FirstName
  $LastName = Remove-Diacritics $LastName

  # Create a login name based on prefix, first and last name
  $FirstShort = ($FirstName.Replace(' ','')).Substring(0,2)
  $LastShort = ($LastName.Replace(' ','')).Substring(0,2)
  $LogonName = $Prefix + $FirstShort + $LastShort + $AccountType
  $LogonName = $LogonName.ToLower()
 
  # Verify logon name does not exist. If it does genereate a new logonname
  $i = 1
  Do {
    $Testresult = Test-TSxAccount -SamAccountName $LogonName
    if ($Testresult -eq $true) {
      Write-Warning "$LogonName already exists"
      $ExistingUser = Get-ADUser -Identity $LogonName
      if ($ExistingUser.GivenName -eq $FirstName -and $ExistingUser.surname -eq $LastName) {
        Write-Warning "User $($ExistingUser.SamAccountName) with same first and last name already exists"
          Break
        }
      $LogonName = $Prefix + $FirstShort + $LastShort + $i + $AccountType
      $LogonName = $LogonName.ToLower()
      Write-Warning "Trying $LogonName"
      $i++
    }
  }
  Until ($Testresult -eq $false)

  # Return verified logon name
  return $LogonName
}