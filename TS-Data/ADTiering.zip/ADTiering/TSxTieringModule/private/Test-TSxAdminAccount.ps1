﻿Function Test-TSxAdminAccount{
  Param(
    $SamAccountName 
  )

  $PDC = (Get-ADDomain).PDCEmulator
  $User = $(try{Get-ADUser $SamAccountName -Server $PDC}catch{$null})
  if ($User) {
    Return $true
  }
  else {
    Return $false
  }
}

Function Test-TSxAccount{
  Param(
    $SamAccountName 
  )

  $PDC = (Get-ADDomain).PDCEmulator
  $User = $(try{Get-ADUser $SamAccountName -Server $PDC}catch{$null})
  if ($User) { 
    Return $true
  }
  else {
    Return $false
  }
}

Function Test-TSxGMSAAccount{
  Param(
    $SamAccountName 
  )

  $PDC = (Get-ADDomain).PDCEmulator
  $User = $(try{Get-ADServiceAccount -Identity $SamAccountName -Server $PDC}catch{$null})
  if ($User) { 
    Return $true
  }
  else {
    Return $false
  }   
}
