﻿<#
.DESCRIPTION
    Generate a password
.EXAMPLE
    New-TSxRandomPassword.ps1
    Generates a 30 character complex password
.EXAMPLE
    New-TSxRandomPassword.ps1 -PasswordLength 12 -Complex $false
    Generate a 12 character simple password
.PARAMETER PasswordLength
    Length of password
.PARAMETER Simple
    Make a simple password, no special character
#>
Function New-TSxRandomPassword {
  [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = "Low")]
  [OutputType("System.String")]
  param(
    [parameter(mandatory = $false)]
      [int]$PasswordLength = 30,
    [parameter(mandatory = $false)]
      [switch]$Simple
  )
  if ($pscmdlet.ShouldProcess("Generating a $PasswordLength char password")) {
    #Characters to use based
    $strCharacters = "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"
    $strComplex = "!", "_", "?", "*", "%", "-", "(", ")", "="
    $strNumbers = "2", "3", "4", "5", "6", "7", "8", "9", "0"
  
    #Check to see if password contains at least 1 digit
    $bolHasNumber = $false
    $pass = $null
    #Sets which Character Array to use based on $Complex
    #Loop to actually generate the password
    for ($i = 0; $i -lt $PasswordLength; $i++) {
      $c = Get-Random -InputObject $strCharacters
      if ([char]::IsDigit($c)) {$bolHasNumber = $true}
      $pass += $c
    }
    if ($Simple -ne $true) {
      # Get 4 random characters, and replace them with special characters
      $RandomChar = 1..($PasswordLength - 1) | Get-Random -count 4
      foreach ($Char in $RandomChar) {
        $NewChar = Get-Random -InputObject $strComplex
        if ([char]::IsDigit($NewChar)) {$bolHasNumber = $true}
          $pwArray = $pass.ToCharArray()
          $pwArray[$Char] = $NewChar
          $pass = ""
          foreach ($s in $pwArray) {
            $pass += $s
          }
        }
    }
    #Check to see if a Digit was seen, if not, fixit
    if ($bolHasNumber) {
      return $pass
    }
    else {
      $RandomChar = Get-Random -Maximum ($PasswordLength - 1)
      $NewChar = Get-Random -InputObject $strNumbers
      $pwArray = $pass.ToCharArray()
      $pwArray[$RandomChar] = $NewChar
      $pass = ""
      foreach ($s in $pwArray) {
        $pass += $s
      }
      return $pass
    }
  }
}
