function Remove-Diacritics {
  param (
    [String]$sToModify = [String]::Empty
  )

  # If input string is empty, return empty string
  if ($sToModify -eq $null) {
    return [string]::Empty
  }
  
  # Replace unhandled special characters with their ASCII equivalent
  $charsets = @( @([char]223,"s"), @([char]254,"th"), @([char]240,"d") )
  foreach ($charset in $charsets) {
    $sToModify = $sToModify -ireplace $charset[0], $charset[1]
  }
  
  # Replace diacritics with their ASCII equivalent and return result
  $res = [Text.Encoding]::ASCII.GetString([Text.Encoding]::GetEncoding("Cyrillic").GetBytes($sToModify))

  return $res
}
