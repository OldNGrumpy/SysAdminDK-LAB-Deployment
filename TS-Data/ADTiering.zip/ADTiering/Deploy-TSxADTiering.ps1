<#
.SYNOPSIS
Creates an organizational structure together with supporting objects for Administrative Tiering
in Active Directory
Supported operatingsystems are Server 2016 or Windows 10 and newer.

.DESCRIPTION
This script is based on the Microsoft on-premises Active Directory tiering documentation and examples,
but has been modified and supplemented based on the real world experience of Truesec experts.

It will create an organizational unit structure in Active Directory as well as group policies,
groups with delegated permissions, fine-grained password policies and authentication policies
and silos.
If objects exists it will use the current objects so it can be run multiple times to add
(but NOT remove!) tiers or capabilities

Reads the ExtraOrganizationalUnits.csv file and builds Servers and Endpoint OU.s and delegates
permissions based the file contents 

.PARAMETER CompanyName
This name will be used as a base to create organizational units for the company endpoints and users

.PARAMETER TierOUName
This name will be used as a base to create the organizational units for the administrative tiers
Default: Admin

.PARAMETER NoOfTiers
The number of additional tiers to add. Can be 1 or 2. Tier0 is always created!
Default: 2

.PARAMETER GPOPrefix
The prefix to use for the GPOs created. The GPOs will be named GPOPrefix - GPOName
Default: Admin

.PARAMETER SkipLAPS
Skips LAPS schema extension and delegation of AdmPwd and WindowsLAPS read permissions

.PARAMETER SkipTierEndPointsPAW
Skips creating TierEndpointPAW OU and related objects and permissions

.PARAMETER SkipTierEndpoints
Skips creating TierEndpoints, Company OU and related objects and permissions

.PARAMETER SkipComputerRedirect
Skips redirecting new computer objects to \CompanyOU\ComputerQuarantine

.PARAMETER SkipImportGPOs
Skips importing GPO settings GPOs, but will still create and link empty GPOs

.PARAMETER Minimal
Equivalent of running the script with -NoOfTier 1, SkipTierEndpointsPAW, SkipLAPS, SkipTierEndpoints
and only creates a minimal version of the Company OU

.PARAMETER WindowsLAPSOnly
Only sets permissions and delegations for WindowsLAPS. LegacyLAPS powershell module is not required.
NOTE: Use only when Windows Server 2019 and Windows 10 22H2 are the oldest operating systems in the domain.

.PARAMETER Server
Choose which domain controller to use for the operations

.EXAMPLE
Deploy-TSxADTiering.ps1 -CompanyName 'Template Inc'
Creates the full tieringstructure with everything and tier 0,1 and 2.
.EXAMPLE
Deploy-TSxADTiering.ps1 -CompanyName 'Template Inc' -NoOfTiers 1 -SkipTierEndpointsPAW -SkipComputerRedirect
Creates the tieringstructure Tier0 and Tier1 but with no TierEndpointsPAW and does
not redirect new computer objects
.EXAMPLE
Deploy-TSxADTiering.ps1 -CompanyName 'Template Inc' -NoOfTiers 1 -SkipTierEndpointsPAW -TierOUName '_Tier' -GPOPrefix 'Template' -WindowsLAPSOnly
Creates the tieringstructure Tier0 and Tier1 with the custom base OU name "_Tier" instead of "Admin"
but with no TierEndpointsPAW and will only delegate and import GPOs for WindowsLAPS
and not legacy LAPS.
GPOs imported by the script will have the prefix "Template" instead of "Admin".
.EXAMPLE
Deploy-TSxADTiering.ps1 -CompanyName 'Template Inc' -Minimal -SkipImportGPOs
Creates the tieringstructure with Tier0 and Tier1 but no TierendpointsPAW OU,
no LAPS permission delegation, no TierEndpoints OU a minimal version of the Company OU.
Does not import GPO settings to created GPOs except SubOU under Servers in Tier1.

.NOTES
FileName: Deploy-TSxADTiering.ps1
Author: Truesec Cyber Security Incident Response Team

Version
1.0.0 - 2021-05-19
1.1.0 - 2023-09-15
1.1.1 - 2023-10-04
1.1.2 - 2023-11-02
1.1.3 - 2023-11-21
1.1.4 - 2024-03-28
1.1.5 - 2024-08-29
1.2.0 - 2024-10-29
1.2.1 - 2024-11-29

License Info:
MIT License
Copyright (c) 2024 Truesec

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the \"Software\"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
#>
#requires -RunAsAdministrator
#requires -Modules ActiveDirectory, GroupPolicy

[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true,
    ValueFromPipelineByPropertyName=$true,
    Position=0)]
    [string]$CompanyName,

  [Parameter(ValueFromPipelineByPropertyName=$true)]
    [string]$TierOUName='Admin',

  [Parameter(ValueFromPipelineByPropertyName=$true)]
    [AllowNull()]
    [ValidateRange(1,2)]
    [int]$NoOfTiers=2,

  [Parameter(ValueFromPipelineByPropertyName=$true)]
    [string]$Server,

  [Parameter(ValueFromPipelineByPropertyName=$true)]
    [string]$GPOPrefix='Admin',

  [switch]$SkipLAPS,

  [switch]$SkipTierEndpointsPAW,

  [switch]$SkipTierEndpoints,

  [switch]$SkipComputerRedirect,

  [switch]$SkipImportGPOs,

  [switch]$WindowsLAPSOnly,

  [switch]$Minimal
)

$Version = '1.2.1'

# Verify OS is Server 2016, Windows 10 or newer
$OS = Get-WmiObject -Class Win32_OperatingSystem | Select-Object Caption, BuildNumber, OSArchitecture
if ([int]$OS.BuildNumber -lt 14393) {
  Throw 'Unsupported OS! Only supported on Server 2016, Windows 10 or newer'
}

# Import TSxADTieringModule. Exit if it can't.
if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\TSxTieringModule\TSxTieringModule.psm1" -ErrorAction SilentlyContinue) {
  Import-Module "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\TSxTieringModule\TSxTieringModule.psm1" -Force
  Write-Verbose 'Imported functions from TSxADTieringModule'
}
else {
  Throw "Could not read the required file:""$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\TSxTieringModule\TSxADTieringModule.psm1""."
}

# Verify chosen server responds. Otherwise choose the PDC or another server that responds
if ($Server) {
  $SpecifiedServer = $Server
  $Server = Get-TSxVerifiedDomainController -Server $Server
}
else {
  $Server = Get-TSxVerifiedDomainController
}
if ($Server -eq $false) {
  Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
}
if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
  Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
}

# Get domain parameters
$ADDomain = Get-ADDomain -Server $Server
$DomainDN = $ADDomain.DistinguishedName
$DomainSID = $ADDomain.DomainSid.Value
$ForestDomain = (Get-ADDomain -Identity $ADDomain.Forest)

# Check if domain functional level is at least Server 2012 R2
if ((Get-ADObject -Identity $DomainDN -Properties msDS-Behavior-Version).'msDS-Behavior-Version' -lt 6) {
  Write-Output 'Domain functional level is not at least Server 2012 R2. Authentication policies and silos will not work.'
  $confirm = Read-Host -Prompt 'Do you still want to continue? (y/n)'
  if ($confirm -ne 'y') {
    return;
  }
}

# Check if current user is a member of the Domain Admins group or else exit
$CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
if ($CurrentUser.Groups -notcontains "$DomainSID-512") {
  Throw "$($CurrentUser.Name) needs to be member of the Domain Admins group to run this script successfully!"
}

# If minimal switch set then add skips and only 1 tier
if ($Minimal) {
  $NoOfTiers = 1
  $SkipLAPS = $true
  $SkipTierEndpointsPAW = $true
  $SkipTierEndpoints = $true
}
"Before LAPS check"
pause
# Check for LAPS extensions unless SkipLAPS or WindowsLAPSOnly set. Create if not enabled. Exit if fails.
if (!($SkipLAPS -or $WindowsLAPSOnly)) {
  if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\AdmPwd.PS\AdmPwd.PS.psd1" -ErrorAction SilentlyContinue) {
    Import-Module "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\AdmPwd.PS\AdmPwd.PS.psd1" -Force
  }
  else {
    Throw "Legacy LAPS powershell module required for legacy LAPS configuration. Make sure the AdmPwd.PS folder is in the same directory as the script."
  }
  
  if (!(Update-TSxLAPSSchema -Verbose:$VerbosePreference)) {
    Throw 'LAPS Schema extensions has not been added as current user is not a member of group "Schema Admins". Add user to this Schema Admins, logout and logon then rerun script'
  }
}
"Before WindowsLAPSOnly"
pause
# If WindowsLAPSOnly set verify schema is updated. Exit if fails.
if ($WindowsLAPSOnly -and !($SkipLAPS)) {
  if (!(Update-TSxLAPSSchema -WindowsLAPSOnly -Verbose:$VerbosePreference)) {
    Throw 'LAPS Schema extensions has not been added as current user is not a member of group "Schema Admins" or OS is not WindowsLAPS capable. Add user to this Schema Admins, logout and logon then rerun script'
  }
}

"Before tiering group policy"
pause
# Check if existing tiering group policy exist and exit if they use different prefix
$existingprefix = Get-TSxGPOPrefix -Server $Server
if ($existingprefix -ne 'DoesNotExist' -and $existingprefix -ne $GPOPrefix) {
  Throw "Existing GPOs with prefix $existingprefix found. Rerun script with -GPOPrefix $existingprefix or remove existing GPOs"
}

# If WindowsLAPSOnly is specified, check for incompabilities
if ($WindowsLAPSOnly) {
  # Check for older enabled operatingsystems and exit if found
  $WindowsLAPSIncompatibleOS = @()
  $ActiveADComputers = Get-ADComputer -Filter {Enabled -eq $true -and OperatingSystem -like 'Windows*'} -Properties OperatingSystem, OperatingSystemVersion, LastLogonDate -Server $Server
  foreach ($ActiveADComputer in $ActiveADComputers) {
    [int]$OperatingSystemVersion = ($ActiveADComputer.OperatingSystemVersion).Split('()')[1]
    if ($ActiveADComputer.OperatingSystem -like '*Server*' -and $OperatingSystemVersion -lt 17763) {
      $WindowsLAPSIncompatibleOS += $ActiveADComputer
    }
    elseif ($ActiveADComputer.OperatingSystem -notlike '*Server*' -and $OperatingSystemVersion -lt 19044) {
      $WindowsLAPSIncompatibleOS += $ActiveADComputer
    }
  }
  if ($WindowsLAPSIncompatibleOS) {
    Write-Output 'The following computers are running an older operating system and are not compatible with WindowsLAPS:'
    $WindowsLAPSIncompatibleOS | Sort-Object OperatingSystem | Format-Table -Property Name, OperatingSystem, OperatingSystemVersion, LastLogonDate
    Write-Output 'You should really upgrade these computers to Windows Server 2019 or Windows 10 22H2 or newer before running the script with the -WindowsLAPSOnly switch.'
    $confirm = Read-Host -Prompt 'Do you still want to continue? (y/n)'
    if ($confirm -ne 'y') {
      return;
    }
  }

  # Remove legacy LAPS group policy links if they exist in tiering structure
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  if (Get-ADOrganizationalUnit -Identity "OU=$TierOUName,$DomainDN" -ErrorAction SilentlyContinue -Server $Server) {
    $LegacyLAPSGPOLinks = Get-TSxLegacyLAPSGPOLinks -Identity "OU=$TierOUName,$DomainDN" -GPOPrefix $GPOPrefix -Server $Server
    if ($null -ne $LegacyLAPSGPOLinks.GpoId) {
      foreach ($LegacyLAPSGPOLink in $LegacyLAPSGPOLinks) {
        Remove-GPLink -Guid $LegacyLAPSGPOLink.GpoId -Target $LegacyLAPSGPOLink.Target -ErrorAction SilentlyContinue -Verbose:$VerbosePreference -Server $Server | Out-Null
      }
    }
  }
  if (Get-ADOrganizationalUnit -Identity "OU=$CompanyName,$DomainDN" -ErrorAction SilentlyContinue -Server $Server) {
    $LegacyLAPSGPOLinks = Get-TSxLegacyLAPSGPOLinks -Identity "OU=$CompanyName,$DomainDN" -GPOPrefix $GPOPrefix -Server $Server
    if ($null -ne $LegacyLAPSGPOLinks.GpoId) {
      foreach ($LegacyLAPSGPOLink in $LegacyLAPSGPOLinks) {
        Remove-GPLink -Guid $LegacyLAPSGPOLink.GpoId -Target $LegacyLAPSGPOLink.Target -ErrorAction SilentlyContinue -Verbose:$VerbosePreference -Server $Server | Out-Null
      }
    }
  }
  $ErrorActionPreference = $EAP
}
elseif (!($SkipLAPS)) {
  $EAP = $ErrorActionPreference
  $ErrorActionPreference = 'SilentlyContinue'
  if (Get-ADOrganizationalUnit -Identity "OU=$TierOUName,$DomainDN" -ErrorAction SilentlyContinue -Server $Server) {
    $TierWindowsLAPSGPLinks = Get-TSxWindowsLAPSGPOLinks -Identity "OU=$TierOUName,$DomainDN" -GPOPrefix $GPOPrefix -Server $Server
  }
  if (Get-ADOrganizationalUnit -Identity "OU=$CompanyName,$DomainDN" -ErrorAction SilentlyContinue -Server $Server) {
    $CompanyWindowsLAPSGPLinks = Get-TSxWindowsLAPSGPOLinks -Identity "OU=$CompanyName,$DomainDN" -GPOPrefix $GPOPrefix -Server $Server
  }
  $ErrorActionPreference = $EAP
  if ($TierWindowsLAPSGPLinks -or $CompanyWindowsLAPSGPLinks) {
    Throw 'WindowsLAPS GPOs found in structure. Rerun with -WindowsLAPSOnly or -SkipLAPS switch'
  }
}

# If TierOUName is not Admin, update TSxTieringModuleSettings.xml with the new TierOUName
if ($TierOUName -ne 'Admin') {
  if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\TSxTieringModule\TSxTieringModuleSettings.xml" -ErrorAction SilentlyContinue) {
    $TSxTieringModuleSettings = [xml](Get-Content -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\TSxTieringModule\TSxTieringModuleSettings.xml")
    $Configs = $TSxTieringModuleSettings.Settings.Configs.Config
    foreach ($Config in $Configs) {
      $Config.AccountOUDN = $Config.AccountOUDN -replace ',OU=Admin', ",OU=$TierOUName"
    }
    Write-Verbose 'Saved new TierOUName in TSxTieringModuleSettings.xml!'
    $TSxTieringModuleSettings.Save("$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\TSxTieringModule\TSxTieringModuleSettings.xml")
  }
}

# Read ExtraOrganizationalUnits csv-file.
if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\ExtraOrganizationalUnits.csv" -ErrorAction SilentlyContinue) {
  $extraous = Import-Csv -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\ExtraOrganizationalUnits.csv" -Delimiter ','
  Write-Verbose 'Read extra OU from ExtraOrganizationalUnits.csv'
}
if (!($extraous)) {
  'Name, Tier, Description
GenericServers,T0,
GenericServers,T1,
GenericServers,T2,
GenericEndpoints,TE,
' | Set-Content -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\ExtraOrganizationalUnits.csv"
  $extraous = Import-Csv -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\ExtraOrganizationalUnits.csv" -Delimiter ','
  Write-Verbose 'Read extra OU from ExtraOrganizationalUnits.csv'
}

# Add domain admins, administrators and enterprise admins to array
$adminaccountgroups = @()
$serviceaccountgroups = @()
$adminaccountgroups += (Get-ADGroup -Filter "SID -eq ""S-1-5-32-544""" -Server $Server).Name
$adminaccountgroups += (Get-ADGroup -Filter "SID -eq ""$DomainSID-512""" -Server $Server).Name
if ($DomainDN -eq $ForestDomain.DistinguishedName) {
  $adminaccountgroups += (Get-ADGroup -Filter "SID -eq ""$DomainSID-519""" -Server $Server).Name
}

# Create array to add gpo.s and groups to
$global:createdgroups = @()
$global:createdgpos = @()

"Create fine-grained password policies for admin accounts and service accounts."
pause
# Create fine-grained password policies for admin accounts and service accounts.
Try {
  $adminpwd = New-ADFineGrainedPasswordPolicy -Name PWDPolicy-AdminAccounts -Precedence 50 -ComplexityEnabled $true -ReversibleEncryptionEnabled $false -MinPasswordAge '0.00:00:00' -MaxPasswordAge '365.00:00:00' -MinPasswordLength 16 -PasswordHistoryCount 24 -LockoutObservationWindow '0.00:05:00' -LockoutDuration '0.00:05:00' -LockoutThreshold 50 -ProtectedFromAccidentalDeletion $true -Description 'Password Policy for Admin Accounts' -Server $Server -PassThru
  Write-Verbose 'Created fine-grained password policy for admin accounts.'
}
Catch {
  $adminpwd = Get-ADFineGrainedPasswordPolicy -Identity PWDPolicy-AdminAccounts -Server $Server
}
Try {
  $servicepwd = New-ADFineGrainedPasswordPolicy -Name PWDPolicy-ServiceAccounts -Precedence 100 -ComplexityEnabled $true -ReversibleEncryptionEnabled $false -MinPasswordAge '0.00:00:00' -MaxPasswordAge '0.00:00:00' -MinPasswordLength 24 -PasswordHistoryCount 24 -LockoutObservationWindow '0.00:05:00' -LockoutDuration '0.00:05:00' -LockoutThreshold 50 -ProtectedFromAccidentalDeletion $true -Description 'Password Policy for Servie Accounts' -Server $Server -PassThru
  Write-Verbose 'Created fine-grained password policy for service accounts.'
}
Catch {
  $servicepwd = Get-ADFineGrainedPasswordPolicy -Identity PWDPolicy-ServiceAccounts -Server $Server
}

"Creates all GPOs needed for Tiers"
pause
# Creates all GPOs needed for Tiers
Write-Output 'Creating GPOs...'
$enablerdpgpo = New-TSxGPO -Name "$GPOPrefix - Enable Remote Desktop w NLA Disabled" -Description 'Enables Remote Desktop with NLA disabled' -Server $Server -Verbose:$VerbosePreference
if (!($SkipLAPS -or $WindowsLAPSOnly)) {
  $lapssettingsgpo = New-TSxGPO -Name "$GPOPrefix - LAPS Settings" -Description 'Contains configuration settings for legacy LAPS' -Server $Server -Verbose:$VerbosePreference
  $lapsinstallgpo = New-TSxGPO -Name "$GPOPrefix - LAPS Install" -Description 'Contains installation settings for the LAPS agent' -Server $Server -Verbose:$VerbosePreference
  $global:createdgpos += $lapssettingsgpo,$lapsinstallgpo
}
if ($WindowsLAPSOnly -and !($SkipLAPS)) {
  $t0wlapssettingsgpo = New-TSxGPO -Name "$GPOPrefix - WindowsLAPS Settings - Tier0" -Description 'Contains configuration settings for WindowsLAPS in Tier0' -Server $Server -Verbose:$VerbosePreference
  $t1wlapssettingsgpo = New-TSxGPO -Name "$GPOPrefix - WindowsLAPS Settings - Tier1" -Description 'Contains configuration settings for WindowsLAPS in Tier1' -Server $Server -Verbose:$VerbosePreference
  if ($NoOfTiers -eq 2) {
    $t2wlapssettingsgpo = New-TSxGPO -Name "$GPOPrefix - WindowsLAPS Settings - Tier2" -Description 'Contains configuration settings for WindowsLAPS in Tier2' -Server $Server -Verbose:$VerbosePreference
    $global:createdgpos += $t2wlapssettingsgpo
  }
  if (!($SkipTierEndpoints)) {
    $tewlapssettingsgpo = New-TSxGPO -Name "$GPOPrefix - WindowsLAPS Settings - TierEndpoint" -Description 'Contains configuration settings for WindowsLAPS in TierEndpoint' -Server $Server -Verbose:$VerbosePreference
    $global:createdgpos += $tewlapssettingsgpo
  }
  $wlapssettingsgpo = New-TSxGPO -Name "$GPOPrefix - WindowsLAPS Settings - Legacy" -Description 'Contains configuration settings for WindowsLAPS in legacy structure' -Server $Server -Verbose:$VerbosePreference
  $global:createdgpos += $t0wlapssettingsgpo, $t1wlapssettingsgpo, $wlapssettingsgpo
}
$enforcerestricrdpgpo = New-TSxGPO -Name "$GPOPrefix - Enforce using Restricted Mode for RDP connections" -Description 'Enforce using restricted mode for RDP connections' -Server $Server -Verbose:$VerbosePreference
$restrictt0adminlogongpo = New-TSxGPO -Name "$GPOPrefix - Restrict Admin Logon T0" -Description 'Used to remove tatooed policies from Tier0 servers' -Server $Server -Verbose:$VerbosePreference
$restrictt1adminlogongpo = New-TSxGPO -Name "$GPOPrefix - Restrict Admin Logon T1" -Description 'Restricts high privileged groups, users and Tier0 accounts access for Tier1' -Server $Server -Verbose:$VerbosePreference
$rdprestrictedgpo = New-TSxGPO -Name "$GPOPrefix - Enable Remote Desktop w Restricted Admin Mode Enable" -Description 'Enables Remote Desktop with restricted admin mode enabled' -Server $Server -Verbose:$VerbosePreference
$t1jumpstationgroupsgpo = New-TSxGPO -Name "$GPOPrefix - Add Domain Tier1 Jumpstation AD Groups to Local Groups" -Description 'Adds Tier1 Jumpstations AD groups to local groups' -Server $Server -Verbose:$VerbosePreference
$t1jumpstationlimitedgroupsgpo = New-TSxGPO -Name "$GPOPrefix - Add Domain Tier1 JumpstationLimited AD Groups to Local Groups" -Description 'Adds Tier1 JumpstationLimited AD groups to local groups' -Server $Server -Verbose:$VerbosePreference
$disablesecdesktopgpo = New-TSxGPO -Name "$GPOPrefix - Disable Secure Desktop for UAC" -Description 'Disable Secure Desktop for UAC' -Server $Server -Verbose:$VerbosePreference
$removelegacycmpadminsgpo = New-TSxGPO -Name "$GPOPrefix - Remove Domain Legacy Computer Admins from Local Admin group" -Description 'Removes Domain Legacy Computer Admins group from local admin group' -Server $Server -Verbose:$VerbosePreference
$legacyadminlocaladmingpo = New-TSxGPO -Name "$GPOPrefix - Add Domain Legacy Computer Admins to Local Admin group" -Description 'Adds Legacy Computer admin group to local admin group' -Server $Server -Verbose:$VerbosePreference
if ($NoOfTiers -eq 2) {
  $restrictt2adminlogongpo = New-TSxGPO -Name "$GPOPrefix - Restrict Admin Logon T2" -Description 'Restricts high privileged groups, users, Tier0 and Tier1 accounts access for Tier2' -Server $Server -Verbose:$VerbosePreference
  $t2jumpstationgroupsgpo = New-TSxGPO -Name "$GPOPrefix - Add Domain Tier2 Jumpstation AD Groups to Local Groups" -Description 'Adds Tier2 Jumpstations AD Groups to local groups' -Server $Server -Verbose:$VerbosePreference
  $t2jumpstationlimitedgroupsgpo = New-TSxGPO -Name "$GPOPrefix - Add Domain Tier2 JumpstationLimited AD Groups to Local Groups" -Description 'Adds Tier2 JumpstationLimited AD Groups to local groups' -Server $Server -Verbose:$VerbosePreference
  $global:createdgpos += $restrictt2adminlogongpo,$t2jumpstationgroupsgpo,$t2jumpstationlimitedgroupsgpo
}
if (!($SkipTierEndpoints)) {
  $restrictteadminlogongpo = New-TSxGPO -Name "$GPOPrefix - Restrict Admin Logon TE" -Description 'Restricts high privileged groups, users, Tier0, Tier1 and Tier2 accounts access for TierEndpoints' -Server $Server -Verbose:$VerbosePreference
  $tejumpstationgroupsgpo = New-TSxGPO -Name "$GPOPrefix - Add Domain TierEndpoints Jumpstations AD Groups to Local Groups" -Description 'Adds TierEndpoints Jumpstations AD groups to local groups' -Server $Server -Verbose:$VerbosePreference
  $global:createdgpos += $restrictteadminlogongpo,$tejumpstationgroupsgpo
}
$dckerberosgpo = New-TSxGPO -Name "$GPOPrefix - Kerberos Settings for Domain Controllers" -Description 'Sets correct kerberos settings for domain controllers to use compound authentication' -Server $Server -Verbose:$VerbosePreference
$clientkerberosgpo = New-TSxGPO -Name "$GPOPrefix - Kerberos Settings for Clients" -Description 'Sets correct kerberos settings for jumpstations and PAWs to use compound authentication' -Server $Server -Verbose:$VerbosePreference
if (!($SkipTierEndpointsPAW)) {
  $restrictpahlogongpo = New-TSxGPO -Name "$GPOPrefix - Restrict Logon TierEndpointPAW Hosts" -Description 'Restricts high privileged groups, users and admin accounts access to TierEndpointPAW' -Server $Server -Verbose:$VerbosePreference
  $comphighperfgpo = New-TSxGPO -Name "$GPOPrefix - Set Computer Powerplan to High Performance" -Description 'Sets PAWHost computer powerplan to High Performance' -Server $Server -Verbose:$VerbosePreference
  $global:createdgpos += $restrictpahlogongpo,$comphighperfgpo
}
$global:createdgpos += $enablerdpgpo,$enforcerestricrdpgpo,$restrictt0adminlogongpo,$restrictt1adminlogongpo,$rdprestrictedgpo,$t1jumpstationgroupsgpo,$t1jumpstationlimitedgroupsgpo,$disablesecdesktopgpo,$removelegacycmpadminsgpo,$legacyadminlocaladmingpo,$dckerberosgpo,$clientkerberosgpo

"Creates base OU.s for Tier and Company."
pause
# Creates base OU.s for Tier and Company.
$tierou = New-TSxADOrganizationalUnit -Name $TierOUName -Path $DomainDN -Description "All tier admin accounts, service accounts, PAWs, servers and admingroups. Version: $Version" -Server $Server -Verbose:$VerbosePreference
if ($tierou.Description -notlike "*Version: $Version") {
  if ($tierou.Description -like "*Version*") {
    $currenttierouversion = ($tierou.Description -split " Version:")[1]
    $newtieroudescription = $tierou.Description -replace ("Version:$currenttierouversion","Version: $Version")
  }
  else {
    $newtieroudescription = $tierou.Description + " Version: $Version"
  }
  Set-ADOrganizationalUnit -Identity $tierou.DistinguishedName -Description $newtieroudescription -Server $Server
}
$conaccou = New-TSxADOrganizationalUnit -Name 'ConnectionAccounts' -Path $tierou.DistinguishedName -Description 'Accounts used for connecting remotely' -Server $Server -Verbose:$VerbosePreference
if (!($SkipTierEndpoints -and $SkipComputerRedirect)) {
  $companyou = New-TSxADOrganizationalUnit -Name $CompanyName -Path $DomainDN -Description "BaseOU for $CompanyName" -Server $Server -Verbose:$VerbosePreference
}

# Create and set default Computers OU.
if (!($SkipTierEndpoints -and $SkipComputerRedirect)) {
  $computerqou = New-TSxADOrganizationalUnit -Name ComputerQuarantine -Path $companyou.DistinguishedName -Description 'Default location for computer objects' -Server $Server -Verbose:$VerbosePreference
}
if (!($SkipComputerRedirect)) {
  & redircmp.exe $computerqou.DistinguishedName
  Write-Verbose "Computer default OU redirected to $($computerqou.DistinguishedName)"
}

# Blocks creating GPO Links in base OU.s
if (!($SkipTierEndpoints -and $SkipComputerRedirect)) {
  Set-TSxOUPermission -OrganizationalUnitDN $companyou.DistinguishedName -GroupName Everyone -ObjectType DenyGPLink -Server $Server -Verbose:$VerbosePreference
}
Set-TSxOUPermission -OrganizationalUnitDN $tierou.DistinguishedName -GroupName Everyone -ObjectType DenyGPLink -Server $Server -Verbose:$VerbosePreference

"Tier0"
pause
Write-Output 'Creating Tier0...'
# Creates all Tier0 OU.s
$t0ou = New-TSxADOrganizationalUnit -Name Tier0 -Path $tierou.DistinguishedName -Description 'Tier0 admin accounts, service accounts, PAWs, servers and groups' -Server $Server -Verbose:$VerbosePreference
New-TSxADOrganizationalUnit -Name AdminAccounts -Path $t0ou.DistinguishedName  -Description 'Tier0 admin accounts' -Server $Server -Verbose:$VerbosePreference -NoOut
New-TSxADOrganizationalUnit -Name ServiceAccounts -Path $t0ou.DistinguishedName  -Description 'Tier0 service accounts' -Server $Server -Verbose:$VerbosePreference -NoOut
$t0jumpou = New-TSxADOrganizationalUnit -Name JumpStations -Path $t0ou.DistinguishedName  -Description 'Tier0 jumpstation management servers' -Server $Server -Verbose:$VerbosePreference
$t0pawou = New-TSxADOrganizationalUnit -Name PrivilegedAccessWorkstations -Path $t0ou.DistinguishedName -Description 'Tier0 privileged access workstations' -Server $Server -Verbose:$VerbosePreference
$t0groupou = New-TSxADOrganizationalUnit -Name Groups -Path $t0ou.DistinguishedName -Description 'Tier0 groups' -Server $Server -Verbose:$VerbosePreference
$t0serverou = New-TSxADOrganizationalUnit -Name Servers -Path $t0ou.DistinguishedName -Description 'Tier0 servers' -Server $Server -Verbose:$VerbosePreference
foreach ($extraou in $extraous | Where-Object {$_.Tier -eq 'T0'}) {
  New-TSxSubOU -Tier T0 -Name $extraou.Name -Description $extraou.Description -TierOUName $TierOUName -CompanyName $CompanyName -GPOPrefix $GPOPrefix -SkipImportGPOs:$SkipImportGPOs -SkipLAPS:$SkipLAPS -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference
}

# Block GPO inheritance for Tier0 PAW and Jumpstations
Write-Verbose 'Blocking GPO inheritance for PAW and Jumpstations in Tier0'
Set-GPInheritance -Target $t0pawou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null
Set-GPInheritance -Target $t0jumpou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null

# Creates all GPO Links for Tier0
New-TSxGPLink -Id ($enablerdpgpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($restrictt0adminlogongpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($restrictt0adminlogongpo.Id).Guid -Target $t0serverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($restrictt0adminlogongpo.Id).Guid -Target "OU=Domain Controllers,$DomainDN" -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
if (!($SkipLAPS -or $WindowsLAPSOnly)) {
  New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $t0serverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $t0serverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
}
if ($WindowsLAPSOnly -and !($SkipLAPS)) {
  New-TSxGPLink -Id ($t0wlapssettingsgpo.Id).Guid -Target $t0serverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($t0wlapssettingsgpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
}
New-TSxGPLink -Id ($enforcerestricrdpgpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($rdprestrictedgpo.Id).Guid -Target $t0serverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($removelegacycmpadminsgpo.Id).Guid -Target $t0serverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($rdprestrictedgpo.Id).Guid -Target "OU=Domain Controllers,$DomainDN" -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null 
New-TSxGPLink -Id ($dckerberosgpo.Id).Guid -Target "OU=Domain Controllers,$DomainDN" -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $t0jumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $t0pawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($enforcerestricrdpgpo.Id).Guid -Target $t0pawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
New-TSxGPLink -Id ($restrictt0adminlogongpo.Id).Guid -Target $t0pawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null

"Tier0 groups"
pause
# Creates Tier0 managed groups.
$t1admingroup = New-TSxADGroup -Name 'Domain Tier1 OU Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members are admins under the Tier1 OU structure' -Server $Server -Verbose:$VerbosePreference
$adminaccountgroups += $t1admingroup.Name
$t0servicegroup = New-TSxADGroup -Name 'Domain Tier0 Service accounts' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Tier0 Service accounts' -Server $Server -Verbose:$VerbosePreference
$serviceaccountgroups += $t0servicegroup.Name
$legacygroupgroup = New-TSxADGroup -Name 'Domain Legacy Group Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Delegated permissions to group objects in legacy OU structure' -Server $Server -Verbose:$VerbosePreference
$legacycomputergroup = New-TSxADGroup -Name 'Domain Legacy Computer Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Delegated permissions to computer objects in legacy OU structure' -Server $Server -Verbose:$VerbosePreference
$legacyusergroup = New-TSxADGroup -Name 'Domain Legacy User Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Delegated permissions to user objects in legacy OU structure' -Server $Server -Verbose:$VerbosePreference
if ($WindowsLAPSOnly) {
  $legacywlapsdecrypt = New-TSxADGroup -Name "Domain Legacy Computer WindowsLAPS Password Decryptors" -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members can decrypt WindowsLAPS passwords in legacy computer structure" -Server $Server -Verbose:$VerbosePreference
  Add-ADGroupMember -Identity $legacywlapsdecrypt -Members $legacycomputergroup,"$DomainSID-512" -Server $Server
  $global:createdgroups += $legacywlapsdecrypt
}
$conaccgroup = New-TSxADGroup -Name 'Domain ConnectionAccounts User Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members can add members to connectionaccounts group and create, delete and administer connection accounts' -Server $Server -Verbose:$VerbosePreference
$connectionaccgroup = New-TSxADGroup -Name 'Domain ConnectionAccounts' -Path $conaccou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'All connectionaccounts' -Server $Server -Verbose:$VerbosePreference
$t0pawdjoingroup = New-TSxADGroup -Name 'Domain Tier0 PrivilegedAccessWorkstations DomainJoin' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members can domain join Tier0 privileged access workstations' -Server $Server -Verbose:$VerbosePreference
$global:createdgroups += $t1admingroup,$t0servicegroup,$legacygroupgroup,$legacycomputergroup,$legacyusergroup,$conaccgroup,$connectionaccgroup,$t0pawdjoingroup
if ($NoOfTiers -eq 2) {
  $t2admingroup = New-TSxADGroup -Name 'Domain Tier2 OU Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members are admins under the Tier2 OU structure' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $t2admingroup.Name
  $global:createdgroups += $t2admingroup
}
if (!($SkipTierEndpoints)) {
  $teadmingroup = New-TSxADGroup -Name 'Domain TierEndpoints OU Admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members are admins under the TierEndpoint OU structure' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $teadmingroup.Name
  $helpdeskgroup = New-TSxADGroup -Name 'Domain Helpdesk operator' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members can add members to groups, update user information, get endpoint bitlocker keys and reset user accounts password under the Company OU' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $helpdeskgroup.Name
  $companyendpointadmingroup = New-TSxADGroup -Name 'Domain Company Endpoint admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members have admin permissions on computer objects in the Company Endpoints OU' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $companyendpointadmingroup.Name
  $companyuseradmingroup = New-TSxADGroup -Name 'Domain Company User admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members have admin permissions on users and contact objects in the Company Users OU' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $companyuseradmingroup.Name
  $global:createdgroups += $teadmingroup,$helpdeskgroup,$companyendpointadmingroup,$companyuseradmingroup
}
if (!($SkipTierEndpointsPAW)) {
  $t0pawadmingroup = New-TSxADGroup -Name 'Domain TierEndpointPAW PrivilegedAccessHosts admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'TierEndpointPAW privileged access hosts admins' -Server $Server -Verbose:$VerbosePreference
  $global:createdgroups += $t0pawadmingroup
}

# Sets Tier0 LAPS self permissions unless SkipLAPS set.
if (!($SkipLAPS)) {
  Write-Verbose 'Setting LAPS computer self permissions in Tier0'
  Set-TSxAdmPwdComputerSelfPermission -Identity $t0jumpou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
  Set-TSxAdmPwdComputerSelfPermission -Identity $t0serverou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
}

# Sets Tier0 OU permissions
Set-TSxOUPermission -OrganizationalUnitDN $t0pawou.DistinguishedName -GroupName $t0pawdjoingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
Set-TSxOUPermission -OrganizationalUnitDN $conaccou.DistinguishedName -GroupName $conaccgroup.Name -ObjectType UsersCreate -Server $Server -Verbose:$VerbosePreference
Set-TSxOUPermission -OrganizationalUnitDN $conaccou.DistinguishedName -GroupName $conaccgroup.Name -ObjectType GroupsMembers -Server $Server -Verbose:$VerbosePreference
if (!($SkipTierEndpoints -and $SkipComputerRedirect)) {
  Set-TSxOUPermission -OrganizationalUnitDN $computerqou.DistinguishedName -GroupName $legacycomputergroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
}

# Create Tier0 AuthenticationPolicySilo
New-TSxAuthenticationPolicy -Tier T0 -Server $Server -Verbose:$VerbosePreference


"Tiers"
pause
# Create Tiers
foreach ($i in 1..$NoOfTiers) {
  Write-Output "Creating Tier$i..."
    pause
  # Creates all Tier OU.s
  $txou = New-TSxADOrganizationalUnit -Name Tier$i -Path $tierou.DistinguishedName -Description "Tier$i admin accounts, service accounts, PAWs, servers and groups" -Server $Server -Verbose:$VerbosePreference
  $txadminou = New-TSxADOrganizationalUnit -Name AdminAccounts -Path $txou.DistinguishedName -Description "Tier$i admin accounts" -Server $Server -Verbose:$VerbosePreference
  $txserviceou = New-TSxADOrganizationalUnit -Name ServiceAccounts -Path $txou.DistinguishedName  -Description "Tier$i service accounts" -Server $Server -Verbose:$VerbosePreference
  $txjumpou = New-TSxADOrganizationalUnit -Name JumpStations -Path $txou.DistinguishedName  -Description "Tier$i jumpstation management servers" -Server $Server -Verbose:$VerbosePreference
  $txjumplimitedou = New-TSxADOrganizationalUnit -Name JumpStationsLimited -Path $txou.DistinguishedName  -Description "Tier$i jumpstationlimited management servers" -Server $Server -Verbose:$VerbosePreference
  $txpawou = New-TSxADOrganizationalUnit -Name PrivilegedAccessWorkstations -Path $txou.DistinguishedName -Description "Tier$i privileged access workstations" -Server $Server -Verbose:$VerbosePreference
  $txgroupou = New-TSxADOrganizationalUnit -Name Groups -Path $txou.DistinguishedName -Description "Tier$i groups" -Server $Server -Verbose:$VerbosePreference
  $txserverou = New-TSxADOrganizationalUnit -Name Servers -Path $txou.DistinguishedName -Description "Tier$i servers" -Server $Server -Verbose:$VerbosePreference
  foreach ($extraou in $extraous | Where-Object {$_.Tier -eq "T$i"}) {
    New-TSxSubOU -Tier "T$i" -Name $extraou.Name -Description $extraou.Description -TierOUName $TierOUName -CompanyName $CompanyName -GPOPrefix $GPOPrefix -SkipImportGPOs:$SkipImportGPOs -SkipLAPS:$SkipLAPS -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference
  }

  # Block GPO inheritance for Tier PAW and Jumpstations
  Write-Verbose "Blocking GPO inheritance for PAW and Jumpstations in Tier$i"
  Set-GPInheritance -Target $txpawou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null
  Set-GPInheritance -Target $txjumpou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null
  Set-GPInheritance -Target $txjumplimitedou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null

  # Creates all GPO Links for Tier
  New-TSxGPLink -Id ($enablerdpgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($enablerdpgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  if (!($SkipLAPS -or $WindowsLAPSOnly)) {
    New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  }
  New-TSxGPLink -Id ($enforcerestricrdpgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($enforcerestricrdpgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($rdprestrictedgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($removelegacycmpadminsgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  if ($i -eq 1) {
    New-TSxGPLink -Id ($restrictt1adminlogongpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($restrictt1adminlogongpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($restrictt1adminlogongpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($t1jumpstationgroupsgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($t1jumpstationlimitedgroupsgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($restrictt1adminlogongpo.Id).Guid -Target $txpawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    if ($WindowsLAPSOnly -and !($SkipLAPS)) {
      New-TSxGPLink -Id ($t1wlapssettingsgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
      New-TSxGPLink -Id ($t1wlapssettingsgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
      New-TSxGPLink -Id ($t1wlapssettingsgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    }
  } 
  if ($i -eq 2) {
    New-TSxGPLink -Id ($restrictt2adminlogongpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($restrictt2adminlogongpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($restrictt2adminlogongpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($t2jumpstationgroupsgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($t2jumpstationlimitedgroupsgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($restrictt2adminlogongpo.Id).Guid -Target $txpawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    if ($WindowsLAPSOnly -and !($SkipLAPS)) {
      New-TSxGPLink -Id ($t2wlapssettingsgpo.Id).Guid -Target $txserverou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
      New-TSxGPLink -Id ($t2wlapssettingsgpo.Id).Guid -Target $txjumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
      New-TSxGPLink -Id ($t2wlapssettingsgpo.Id).Guid -Target $txjumplimitedou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    }

  }
  New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $txpawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($enforcerestricrdpgpo.Id).Guid -Target $txpawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  
  # Creates Tier managed groups.
  $txpawdjoingroup = New-TSxADGroup -Name "Domain Tier$i PrivilegedAccessWorkstations DomainJoin" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members can domain join Tier$i privileged access workstations" -Server $Server -Verbose:$VerbosePreference
  $txservicegroup = New-TSxADGroup -Name "Domain Tier$i Service accounts" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Tier$i service accounts" -Server $Server -Verbose:$VerbosePreference
  $serviceaccountgroups += $txservicegroup.Name
  $txjumprdpgroup = New-TSxADGroup -Name "Domain Tier$i Jumpstation remote desktop users" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members are added to Tier$i jumpstation local remote desktop users group" -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $txjumprdpgroup.Name
  $txjumpadmingroup = New-TSxADGroup -Name "Domain Tier$i Jumpstation Admins" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members are added to Tier$i jumpstation local administrators group" -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $txjumpadmingroup.Name
  $txjumplimitedrdpgroup = New-TSxADGroup -Name "Domain Tier$i JumpstationLimited remote desktop users" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members are added to Tier$i jumpstationlimited local remote desktop users group" -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $txjumplimitedrdpgroup.Name
  $txjumplimitedadmingroup = New-TSxADGroup -Name "Domain Tier$i JumpstationLimited Admins" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members are added to Tier$i jumpstationlimited local administrators group" -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $txjumplimitedadmingroup.Name
  $global:createdgroups += $txpawdjoingroup,$txservicegroup,$txjumprdpgroup,$txjumpadmingroup,$txjumplimitedrdpgroup,$txjumplimitedadmingroup
  if ($i -eq 1) {
    Add-ADGroupMember -Identity $txjumpadmingroup -Members $t1admingroup -Server $Server
    Add-ADGroupMember -Identity $txjumplimitedadmingroup -Members $t1admingroup -Server $Server
  }
  if ($i -eq 2) {
    Add-ADGroupMember -Identity $txjumpadmingroup -Members $t2admingroup -Server $Server
    Add-ADGroupMember -Identity $txjumplimitedadmingroup -Members $t2admingroup -Server $Server
  }
  if ($WindowsLAPSOnly) {
    $txwlapsdecrypt = New-TSxADGroup -Name "Domain Tier$i WindowsLAPS Password Decryptors" -Path $txgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members can decrypt WindowsLAPS passwords in Tier$i structure" -Server $Server -Verbose:$VerbosePreference
    Add-ADGroupMember -Identity $txwlapsdecrypt -Members $txjumpadmingroup, $txjumplimitedadmingroup,"$DomainSID-512" -Server $Server
    $global:createdgroups += $txwlapsdecrypt
  }
  
  # Sets Tier LAPS self permissions unless SkipLAPS set.
  if (!($SkipLAPS)) {
    Write-Verbose "Setting LAPS computer self permissions in $Tier$i"
    Set-TSxAdmPwdComputerSelfPermission -Identity $txjumpou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdComputerSelfPermission -Identity $txjumplimitedou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdComputerSelfPermission -Identity $txserverou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    
    Set-TSxAdmPwdReadPasswordPermission -Identity $txjumpou.DistinguishedName -AllowedPrincipals $txjumpadmingroup.Name -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdReadPasswordPermission -Identity $txjumplimitedou.DistinguishedName -AllowedPrincipals $txjumplimitedadmingroup.Name -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
  }

  # Sets Tier OU permissions
  Set-TSxOUPermission -OrganizationalUnitDN $txpawou.DistinguishedName -GroupName $txpawdjoingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  
  if ($i -eq 1) {
    Set-TSxOUPermission -OrganizationalUnitDN $txserverou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txserverou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txjumpou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txjumplimitedou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    if (!($SkipTierEndpoints -and $SkipComputerRedirect)) {
      Set-TSxOUPermission -OrganizationalUnitDN $computerqou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
    }
    Set-TSxOUPermission -OrganizationalUnitDN $txadminou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType UsersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txgroupou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType GroupsCreate -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txserviceou.DistinguishedName -GroupName $t1admingroup.Name -ObjectType UsersCreate -Server $Server -Verbose:$VerbosePreference
  }

  if ($i -eq 2) {
    Set-TSxOUPermission -OrganizationalUnitDN $txserverou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txserverou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txjumpou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txjumplimitedou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    if (!($SkipTierEndpoints -and $SkipComputerRedirect)) {
      Set-TSxOUPermission -OrganizationalUnitDN $computerqou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
    }
    Set-TSxOUPermission -OrganizationalUnitDN $txadminou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType UsersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txgroupou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType GroupsCreate -Server $Server -Verbose:$VerbosePreference
    Set-TSxOUPermission -OrganizationalUnitDN $txserviceou.DistinguishedName -GroupName $t2admingroup.Name -ObjectType UsersCreate -Server $Server -Verbose:$VerbosePreference
  }

  # Create Tier AuthenticationPolicySilo and give permissions to tier admin group if domain is forest root
  $txauthsilo = New-TSxAuthenticationPolicy -Tier T$i -ReturnObject -Server $Server -Verbose:$VerbosePreference
  $txlauthsilo = New-TSxAuthenticationPolicy -Tier "T$($i)Limited" -ReturnObject -Server $Server -Verbose:$VerbosePreference

  if ($DomainDN -eq $ForestDomain.DistinguishedName) {
    if ($i -eq 1) {
      if ($txauthsilo) {
        Set-TSxOUPermission -OrganizationalUnitDN $txauthsilo.DistinguishedName -GroupName $t1admingroup.Name -ObjectType SiloMembers -Server $Server -Verbose:$VerbosePreference
      }
      if ($txlauthsilo) {
        Set-TSxOUPermission -OrganizationalUnitDN $txlauthsilo.DistinguishedName -GroupName $t1admingroup.Name -ObjectType SiloMembers -Server $Server -Verbose:$VerbosePreference
      }
    }
    if ($i -eq 2) {
      if ($txauthsilo) {
        Set-TSxOUPermission -OrganizationalUnitDN $txauthsilo.DistinguishedName -GroupName $t2admingroup.Name -ObjectType SiloMembers -Server $Server -Verbose:$VerbosePreference
      }
      if ($txlauthsilo) {
        Set-TSxOUPermission -OrganizationalUnitDN $txlauthsilo.DistinguishedName -GroupName $t2admingroup.Name -ObjectType SiloMembers -Server $Server -Verbose:$VerbosePreference
      }
    }
  }
}


if (!($SkipTierEndpoints)) {
  Write-Output 'Creating TierEndpoints...'
  # Creates all TierEndpoint OU.s
  $tetierou = New-TSxADOrganizationalUnit -Name TierEndpoints -Path $tierou.DistinguishedName -Description 'TierEndpoints admin accounts, service accounts, PAWs and groups' -Server $Server -Verbose:$VerbosePreference
  $teadminou = New-TSxADOrganizationalUnit -Name AdminAccounts -Path $tetierou.DistinguishedName -Description 'TierEndpoints admin accounts' -Server $Server -Verbose:$VerbosePreference
  $teserviceou = New-TSxADOrganizationalUnit -Name ServiceAccounts -Path $tetierou.DistinguishedName -Description 'TierEndpoints service accounts' -Server $Server -Verbose:$VerbosePreference
  $tejumpou = New-TSxADOrganizationalUnit -Name JumpStations -Path $tetierou.DistinguishedName  -Description 'TierEndpoints jumpstations management servers' -Server $Server -Verbose:$VerbosePreference
  $tegroupou = New-TSxADOrganizationalUnit -Name Groups -Path $tetierou.DistinguishedName -Description 'TierEndpoints groups' -Server $Server -Verbose:$VerbosePreference
  $tepawou = New-TSxADOrganizationalUnit -Name PrivilegedAccessWorkstations -Path $tetierou.DistinguishedName -Description 'TierEndpoints privileged access workstations' -Server $Server -Verbose:$VerbosePreference
  $compendpointou = New-TSxADOrganizationalUnit -Name Endpoints -Path $companyou.DistinguishedName -Description 'All user computers and endpoints' -Server $Server -Verbose:$VerbosePreference
  $composdou = New-TSxADOrganizationalUnit -Name OSDeploy -Path $compendpointou.DistinguishedName -Description 'OS deployment temporary endpoints' -Server $Server -Verbose:$VerbosePreference
  $compusergroupou = New-TSxADOrganizationalUnit -Name UserGroups -Path $companyou.DistinguishedName -Description 'All user groups' -Server $Server -Verbose:$VerbosePreference
  $compendpointgroupou = New-TSxADOrganizationalUnit -Name EndpointGroups -Path $companyou.DistinguishedName -Description 'All endpoint groups' -Server $Server -Verbose:$VerbosePreference
  $compcontactsou = New-TSxADOrganizationalUnit -Name Contacts -Path $companyou.DistinguishedName  -Description 'All contacts' -Server $Server -Verbose:$VerbosePreference
  New-TSxADOrganizationalUnit -Name DistributionGroups -Path $compusergroupou.DistinguishedName -Description 'All user distribution groups' -Server $Server -Verbose:$VerbosePreference -NoOut
  New-TSxADOrganizationalUnit -Name AzureADReplicatedSecurityGroups -Path $compusergroupou.DistinguishedName -Description 'All user AzureAD replicated user groups' -Server $Server -Verbose:$VerbosePreference -NoOut
  New-TSxADOrganizationalUnit -Name SecurityGroups -Path $compusergroupou.DistinguishedName -Description 'All user security groups' -Server $Server -Verbose:$VerbosePreference -NoOut
  New-TSxADOrganizationalUnit -Name AzureADReplicatedSecurityGroups -Path $compendpointgroupou.DistinguishedName -Description 'All endpoint AzureAD replicated user groups' -Server $Server -Verbose:$VerbosePreference -NoOut
  New-TSxADOrganizationalUnit -Name SecurityGroups -Path $compendpointgroupou.DistinguishedName -Description 'All endpoint security groups' -Server $Server -Verbose:$VerbosePreference -NoOut
  $compuserou = New-TSxADOrganizationalUnit -Name UserAccounts -Path $companyou.DistinguishedName  -Description 'All users' -Server $Server -Verbose:$VerbosePreference
  New-TSxADOrganizationalUnit -Name DisabledUsers -Path $compuserou.DistinguishedName  -Description 'All disabled users' -Server $Server -Verbose:$VerbosePreference -NoOut
  New-TSxADOrganizationalUnit -Name EnabledUsers -Path $compuserou.DistinguishedName  -Description 'All enabled users' -Server $Server -Verbose:$VerbosePreference -NoOut
  New-TSxADOrganizationalUnit -Name ResourceUsers -Path $compuserou.DistinguishedName  -Description 'All resource users' -Server $Server -Verbose:$VerbosePreference -NoOut
  
  foreach ($extraou in $extraous | Where-Object {$_.Tier -eq 'TE'}) {
    New-TSxSubOU -Tier TE -Name $extraou.Name -Description $extraou.Description -TierOUName $TierOUName -CompanyName $CompanyName -GPOPrefix $GPOPrefix -SkipImportGPOs:$SkipImportGPOs -SkipLAPS:$SkipLAPS -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference
  }

  # Block GPO inheritance for TierEndpoints PAW, Jumpstations and OSDeploy
  Write-Verbose "Blocking GPO inheritance for PAW, Jumpstations and OSDeploy in TierEndpoints"
  Set-GPInheritance -Target $tepawou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null
  Set-GPInheritance -Target $tejumpou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null
  Set-GPInheritance -Target $composdou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null

  # Creates all GPO Links for TierEndpoints
  New-TSxGPLink -Id ($enablerdpgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  if (!($SkipLAPS -or $WindowsLAPSOnly)) {
    New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapssettingsgpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($lapsinstallgpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  }
  if ($WindowsLAPSOnly -and !($SkipLAPS)) {
    New-TSxGPLink -Id ($tewlapssettingsgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($tewlapssettingsgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($tewlapssettingsgpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  }
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $composdou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($restrictteadminlogongpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($restrictteadminlogongpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($restrictteadminlogongpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($restrictteadminlogongpo.Id).Guid -Target $composdou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($tejumpstationgroupsgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $tejumpou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($removelegacycmpadminsgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $tepawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($enforcerestricrdpgpo.Id).Guid -Target $tepawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($restrictteadminlogongpo.Id).Guid -Target $tepawou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  $ErrorActionPreference = 'SilentlyContinue'
  if (Get-ADOrganizationalUnit -Identity "OU=RemoteDesktopSessionEndpoints,$($compendpointou.DistinguishedName)" -Server $Server) {
    New-TSxGPLink -Id ($rdprestrictedgpo.Id).Guid -Target "OU=RemoteDesktopSessionEndpoints,$($compendpointou.DistinguishedName)" -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    if ((Get-ADOrganizationalUnit -Identity "OU=RemoteDesktopBackendServers,$(($txserverou.DistinguishedName))" -Server $Server) -or (Get-ADOrganizationalUnit -Identity "OU=RemoteDesktopBackendServers,$(($txserverou.DistinguishedName) -replace 'Tier2','Tier1')" -Server $Server)) {
      $rdsbackendsrvgpos = Get-GPO -All -Server $Server | Where-Object {$_.DisplayName -like '* Admin - RemoteDesktopBackendServers to Local Admin group'} 
      foreach ($rdsbackendsrvgpo in $rdsbackendsrvgpos) {
        New-TSxGPLink -Id ($rdsbackendsrvgpo.Id).Guid -Target "OU=RemoteDesktopSessionEndpoints,$($compendpointou.DistinguishedName)" -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
      }
    }
  }
  $ErrorActionPreference = 'Continue'

  # Creates TierEndpoints managed groups.
  $tepawdjoingroup = New-TSxADGroup -Name 'Domain TierEndpoints PrivilegedAccessWorkstations DomainJoin' -Path $tegroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members can domain join TierEndpoints privileged access workstations' -Server $Server -Verbose:$VerbosePreference
  $teservicegroup = New-TSxADGroup -Name 'Domain TierEndpoints Service accounts' -Path $tegroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'TierEndpoints service accounts' -Server $Server -Verbose:$VerbosePreference
  $serviceaccountgroups += $teservicegroup
  $tejumprdpgroup = New-TSxADGroup -Name 'Domain TierEndpoints Jumpstation remote desktop users' -Path $tegroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members are added to TierEndpoints jumpstation local remote desktop users group' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $tejumprdpgroup.Name
  $tejumpadmingroup = New-TSxADGroup -Name 'Domain TierEndpoints Jumpstation Admins' -Path $tegroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members are added to TierEndpoints jumpstation local administrators group' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $tejumprdpgroup.Name
  if ($WindowsLAPSOnly) {
    $tewlapsdecrypt = New-TSxADGroup -Name "Domain TierEndpoints WindowsLAPS Password Decryptors" -Path $tegroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description "Members can decrypt WindowsLAPS passwords in TierEndpoint and Company structure" -Server $Server -Verbose:$VerbosePreference
    Add-ADGroupMember -Identity $tewlapsdecrypt -Members $tejumpadmingroup,$tejumprdpgroup,"$DomainSID-512" -Server $Server
    $global:createdgroups += $tewlapsdecrypt
  }
  $global:createdgroups += $tepawdjoingroup,$teservicegroup,$tejumprdpgroup,$tejumpadmingroup
  Add-ADGroupMember -Identity $tejumpadmingroup -Members $teadmingroup -Server $Server

  # Sets TierEndpoints LAPS self permissions unless SkipLAPS is set.
  if (!($SkipLAPS)) {
    Write-Verbose 'Setting LAPS computer self permissions in TierEndpoints'
    Set-TSxAdmPwdComputerSelfPermission -Identity $tejumpou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdComputerSelfPermission -Identity $compendpointou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdComputerSelfPermission -Identity $computerqou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdComputerSelfPermission -Identity $composdou.DistinguishedName -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
    Set-TSxAdmPwdReadPasswordPermission -Identity $tejumpou.DistinguishedName -AllowedPrincipals $teadmingroup.Name -WindowsLAPSOnly:$WindowsLAPSOnly -Server $Server -Verbose:$VerbosePreference | Out-Null
  }

  # Sets TierEndpoints OU permissions
  Set-TSxOUPermission -OrganizationalUnitDN $tepawou.DistinguishedName -GroupName $tepawdjoingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  
  Set-TSxOUPermission -OrganizationalUnitDN $compuserou.DistinguishedName -GroupName $helpdeskgroup.Name -ObjectType Users -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointou.DistinguishedName -GroupName $helpdeskgroup.Name -ObjectType BitLocker -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compusergroupou.DistinguishedName -GroupName $helpdeskgroup.Name -ObjectType GroupsMembers -Server $Server -Verbose:$VerbosePreference

  Set-TSxOUPermission -OrganizationalUnitDN $computerqou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointgroupou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType GroupsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointgroupou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference

  Set-TSxOUPermission -OrganizationalUnitDN $compusergroupou.DistinguishedName -GroupName $companyuseradmingroup.Name -ObjectType GroupsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compusergroupou.DistinguishedName -GroupName $companyuseradmingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compuserou.DistinguishedName -GroupName $companyuseradmingroup.Name -ObjectType UsersCreateGPLink -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compuserou.DistinguishedName -GroupName $companyuseradmingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compcontactsou.DistinguishedName -GroupName $companyuseradmingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compcontactsou.DistinguishedName -GroupName $companyuseradmingroup.Name -ObjectType ContactsCreate -Server $Server -Verbose:$VerbosePreference
  
  Set-TSxOUPermission -OrganizationalUnitDN $teadminou.DistinguishedName -GroupName $teadmingroup.Name -ObjectType UsersCreateGPLink -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $teserviceou.DistinguishedName -GroupName $teadmingroup.Name -ObjectType UsersCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $tegroupou.DistinguishedName -GroupName $teadmingroup.Name -ObjectType GroupsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $tejumpou.DistinguishedName -GroupName $teadmingroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
  
  $ErrorActionPreference = 'SilentlyContinue'
  if (Get-ADOrganizationalUnit -Identity "OU=RemoteDesktopSessionEndpoints,$($compendpointou.DistinguishedName)" -Server $Server) {
    $rdsbackendgroups = Get-ADGroup -Filter {Name -like '* Admin - RemoteDesktopBackendServers'} -Server $Server
    foreach ($rdsbackendgroup in $rdsbackendgroups) { 
      Set-TSxOUPermission -OrganizationalUnitDN "OU=RemoteDesktopSessionEndpoints,$($compendpointou.DistinguishedName)" -GroupName $rdsbackendgroup.Name -ObjectType ComputersCreateGPLink -Server $Server -Verbose:$VerbosePreference
    }
  }
  $ErrorActionPreference = 'Continue'
}


if (!($SkipTierEndpointsPAW)) {
  Write-Output 'Creating TierEndpointsPAW...'
  #Creates all TierEndpointsPAW OU.s
  $tepou = New-TSxADOrganizationalUnit -Name TierEndpointsPAW -Path $tierou.DistinguishedName -Description 'PAW hosts groups, user accounts and PAW Hosts' -Server $Server -Verbose:$VerbosePreference
  $tepgroupou = New-TSxADOrganizationalUnit -Name Groups -Path $tepou.DistinguishedName -Description 'PAW hosts groups' -Server $Server -Verbose:$VerbosePreference
  $teppahou = New-TSxADOrganizationalUnit -Name PrivilegedAccessHosts -Path $tepou.DistinguishedName -Description 'PAW privileged access hosts' -Server $Server -Verbose:$VerbosePreference
  $tepusersou = New-TSxADOrganizationalUnit -Name UserAccounts -Path $tepou.DistinguishedName -Description 'PAW hosts user accounts' -Server $Server -Verbose:$VerbosePreference

  #Block GPO inheritance for TierEndpointsPAW PAW Hosts
  Write-Verbose "Blocking GPO inheritance for PAWHosts in TierEndpointsPAW"
  Set-GPInheritance -Target $teppahou.DistinguishedName -IsBlocked Yes -Server $Server | Out-Null

  #Creates TierEndpointsPAW managed groups.
  $teppahdjoingroup = New-TSxADGroup -Name 'Domain TierEndpointsPAW PrivilegedAccessHosts DomainJoin' -Path $tepgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members can domain join TierEndpointsPAW privileged access hosts' -Server $Server -Verbose:$VerbosePreference
  $tepawhostusrgroup = New-TSxADGroup -Name 'Domain TierEndpointsPAW PrivilegedAccessHosts users' -Path $tepgroupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'TierEndpointsPAW hosts user accounts' -Server $Server -Verbose:$VerbosePreference
  $global:createdgroups += $teppahdjoingroup,$tepawhostusrgroup

  #Sets TierEndpointsPAW OU permissions
  Set-TSxOUPermission -OrganizationalUnitDN $teppahou.DistinguishedName -GroupName $t0pawadmingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $teppahou.DistinguishedName -GroupName $teppahdjoingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $tepgroupou.DistinguishedName -GroupName $t0pawadmingroup.Name -ObjectType GroupsCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $tepusersou.DistinguishedName -GroupName $t0pawadmingroup.Name -ObjectType UsersCreate -Server $Server -Verbose:$VerbosePreference

  #Creates all GPO Links for EndpointPAW
  New-TSxGPLink -Id ($restrictpahlogongpo.Id).Guid -Target $teppahou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($clientkerberosgpo.Id).Guid -Target $teppahou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($comphighperfgpo.Id).Guid -Target $teppahou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null

  #Create TierEndpointsPAW AuthenticationPolicySilo
  New-TSxAuthenticationPolicy -Tier TP -Server $Server -Verbose:$VerbosePreference
}


# Creates CompanyOU if Minimal set
if ($Minimal) {
  $companyou = New-TSxADOrganizationalUnit -Name $CompanyName -Path $DomainDN -Description "BaseOU for $CompanyName" -Server $Server -Verbose:$VerbosePreference
  $compendpointou = New-TSxADOrganizationalUnit -Name Endpoints -Path $companyou.DistinguishedName -Description 'All User Endpoints' -Server $Server -Verbose:$VerbosePreference
  New-TSxADOrganizationalUnit -Path $compendpointou -Name 'GenericEndpoints' -Description 'TierEndpoints GenericEndpoints' -Server $Server -Verbose:$VerbosePreference -NoOut

  $companyendpointadmingroup = New-TSxADGroup -Name 'Domain Company Endpoint admins' -Path $t0groupou.DistinguishedName -GroupCategory Security -GroupScope Global -Description 'Members have admin permissions on computer objects in the Company Endpoints OU' -Server $Server -Verbose:$VerbosePreference
  $adminaccountgroups += $companyendpointadmingroup.Name
  $global:createdgroups += $companyendpointadmingroup
  
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType ComputersCreate -Server $Server -Verbose:$VerbosePreference
  Set-TSxOUPermission -OrganizationalUnitDN $compendpointou.DistinguishedName -GroupName $companyendpointadmingroup.Name -ObjectType OUsCreate -Server $Server -Verbose:$VerbosePreference
  
  New-TSxGPLink -Id ($restrictt1adminlogongpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  New-TSxGPLink -Id ($removelegacycmpadminsgpo.Id).Guid -Target $compendpointou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  if (!($SkipComputerRedirect)) {
    New-TSxGPLink -Id ($restrictt1adminlogongpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
    New-TSxGPLink -Id ($disablesecdesktopgpo.Id).Guid -Target $computerqou.DistinguishedName -LinkEnabled Yes -Server $Server -Verbose:$VerbosePreference | Out-Null
  }
}

# Assign created admin and service account groups to password policies
Write-Verbose 'Adding all admin and service account groups to fine-grained password policies'
Add-ADFineGrainedPasswordPolicySubject -Identity $adminpwd.Name -Subjects $adminaccountgroups -Server $Server
Add-ADFineGrainedPasswordPolicySubject -Identity $servicepwd.Name -Subjects $serviceaccountgroups -Server $Server

# Unless SkipImportGPOs is set run Import-TSxGPO.ps1 script
if (!($SkipImportGPOs)) {
  Write-Verbose 'Importing GPOs from GPOBackup.zip'
  if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Import-TSxGPO.ps1" -ErrorAction SilentlyContinue) {
    & "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Import-TSxGPO.ps1" -GPOPrefix $GPOPrefix -TierOUName $TierOUName -Server:$Server -Verbose:$VerbosePreference
  }
}

# Export created gpos and groups to CSV
if (!(Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Report" -PathType Container -ErrorAction SilentlyContinue)) {
  New-Item -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Report" -ItemType Directory | Out-Null
}
$global:createdgpos | Select-Object @{Name='Group Policy Name';Expression={$($_.DisplayName)}}, Description | Export-Csv -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Report\ADTieringGPOsCreated.csv" -NoTypeInformation -Delimiter ';'
$global:createdgroups | Select-Object @{Name='GroupName';Expression={$($_.Name)}}, Description, SamAccountName, DistinguishedName | Export-Csv -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Report\ADTieringGroupsCreated.csv" -NoTypeInformation -Delimiter ';'
Write-Verbose "Wrote csv output of GPOs and groups created to ""$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\Report"""

# If RetryCommand.ps1 file was modified less than 5 minutes ago tell the user it has been created.
$5minago = (Get-Date).AddMinutes(-5)
if (Test-Path -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\RetryCommand.ps1" -ErrorAction SilentlyContinue) {
  if ((Get-Item -Path "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)\RetryCommand.ps1" -ErrorAction SilentlyContinue).LastWriteTime -ge $5minago) {
    Write-Output 'RetryCommand.ps1 has been created in the same directory as this script. If any errors occurred during the script run, run this script to retry the failed commands.'
  }
}

Write-Output '' 'Done!'
