﻿[CmdletBinding()]
Param(
  [string]$Path,
  [string]$GPOPrefix = 'Admin',
  [string]$TierOUName = 'Admin',
  [string]$Server
)

if (!($Path)) {
  $Path = "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)"
}
else {
  $Path = (Get-Item -Path $Path).FullName # This works with .\ type paths aswell
}

# Verify chosen server responds. Otherwise choose the PDC or another server that responds
if ($Server) {
  $SpecifiedServer = $Server
  $Server = Get-TSxVerifiedDomainController -Server $Server
}
else {
  $Server = Get-TSxVerifiedDomainController
}
if ($Server -eq $false) {
  Throw "Unable to find a responding domain controller. Please try again or specify server with -Server parameter."
}
if ($SpecifiedServer -ne $Server -and $null -ne $SpecifiedServer) {
  Write-Warning "User specified server ""$SpecifiedServer"", but it was not reachable. Responding domain controller ""$Server"" will be used instead."
}

# Get parameters and localized group names
$ADDomain = Get-ADDomain -Server $Server
$NewShortDomainName = $ADDomain.NetBIOSName
$NewFQDNDomainName = $ADDomain.DnsRoot
$ForestFQDN = $ADDomain.Forest
$DomainSID= $ADDomain.DomainSid.Value
$OS = Get-WmiObject -Class Win32_OperatingSystem | Select-Object Caption, BuildNumber, OSArchitecture
if ($NewFQDNDomainName -ne $ForestFQDN) {
  $ForestRootDomain = Get-ADDomain -Identity $ForestFQDN
  $ForestRootDomainSID = $ForestRootDomain.DomainSid.Value
  $ForestRootDomainPDC = $ForestRootDomain.PDCEmulator
  $ForestRootShortDomainName = $ForestRootDomain.NetBIOSName
  $SchemaAdminsGroup = (Get-ADGroup -Filter "SID -eq ""$ForestRootDomainSID-518""" -Server $ForestRootDomainPDC).Name
  $EnterpriseAdminGroup = (Get-ADGroup -Filter "SID -eq ""$ForestRootDomainSID-519""" -Server $ForestRootDomainPDC).Name
}
else {
  $SchemaAdminsGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-518""").Name
  $EnterpriseAdminGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-519""").Name
}
$DCDomainGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-516""").Name
$AdministratorUser = (Get-ADUser -Filter "SID -eq ""$DomainSID-500""").Name
$DomainAdminGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-512""").Name
$DomainUsersGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-513""").Name
$GPOCreatorGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-520""").Name
$KeyAdminGroup = (Get-ADGroup -Filter "SID -eq ""$DomainSID-526""").Name
$CryptoOpGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-569""").Name
$PrintOpGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-550""").Name
$BackupOpGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-551""").Name
$ServerOpGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-549""").Name
$AccountOpGroup = (Get-ADGroup -Filter "SID -eq ""S-1-5-32-548""").Name

# Extract GPOExport.zip if not extracted
$Path = $Path.TrimEnd('\')
if (!(Test-Path $Path\GPOBackup -PathType Container)) {
  if (Test-Path $Path\GPOBackup.zip -PathType Leaf) {
    Try {
      Expand-Archive $Path\GPOBackup.zip -DestinationPath $Path -Force -ErrorAction Stop
    }
    Catch {
      Add-Type -Assembly "System.IO.Compression.Filesystem"
      [System.IO.Compression.ZipFile]::ExtractToDirectory("$Path\GPOBackup.zip", $Path)
    }
  }
  else {
    Write-Error "Could not find $Path\GPOBackup folder or $Path\GPOBackup.zip. Specify path manually!" -Verbose
    Exit
  }
} 

# Update groups.xml GPO Preference for each GPO with new domain and group SID
$PrefGroupXMLs = Get-ChildItem -Path $Path -Recurse -Filter groups.xml
Write-Warning 'NOTE! Errors of the type "group not found" might be expected depending on tiers created!'
foreach ($PrefGroupXML in $PrefGroupXMLs){
  [XML]$XMLFile = Get-Content -Path $PrefGroupXML.FullName
  foreach($Member in $XMLFile.Groups.Group.Properties.Members.Member){
    $Object = $Member.name.Replace("AD\","$NewShortDomainName\")
    $Member.name = $Object

    $GroupName = $Object.Replace("$NewShortDomainName\","")

    if ($GroupName -like '*Domain Admins') {
      $GroupName = $GroupName.Replace("Domain Admins","$DCDomainGroup")
    }
    if ($GroupName -like '*Domain Users') {
      $GroupName = $GroupName.Replace("Domain Users","$DomainUsersGroup")
    }

    if ($GroupName -like '*Enterprise Admins' -or $GroupName -like '*Schema Admins' -and $ForestRootDomainPDC) {
      if ($GroupName -like '*Enterprise Admins') {
        $GroupName = $GroupName.Replace("Enterprise Admins","$EnterpriseAdminGroup")
      }
      if ($GroupName -like '*Schema Admins') {
        $GroupName = $GroupName.Replace("Schema Admins","$SchemaAdminsGroup")
      }

      $Object = $Member.name.Replace("$NewShortDomainName\","$ForestRootShortDomainName")
      $NewSid = (Get-ADObject -Filter 'Name -EQ $GroupName' -Properties objectSid -Server $ForestRootDomainPDC).objectSid.value
    }
    else {
      if ($GroupName -like '*Enterprise Admins') {
        $GroupName = $GroupName.Replace("Enterprise Admins","$EnterpriseAdminGroup")
      }
      if ($GroupName -like '*Schema Admins') {
        $GroupName = $GroupName.Replace("Schema Admins","$SchemaAdminsGroup")
      }
      
      $NewSid = (Get-ADObject -Filter 'Name -EQ $GroupName' -Properties objectSid).objectSid.value
    }
    
    if ($NewSid) {
      $Member.sid = $NewSid
    }
    else {
      Write-Warning "Could not find group: $GroupName" -Verbose
    }
  }
  $XMLFile.Save($PrefGroupXML.FullName)
}

# Update migration table with new NETBIOS and domain name
$MigTable = Get-Content -Path $Path\GPOBackup\MigTable.migtable
$MigTable = $MigTable -replace "<Destination>Enterprise Admins@customer.domain.fqdn", "<Destination>$EnterpriseAdminGroup@$ForestFQDN"
$MigTable = $MigTable -replace "<Destination>Schema Admins@customer.domain.fqdn", "<Destination>$SchemaAdminsGroup@$ForestFQDN"
$MigTable = $MigTable -replace "customer.domain.fqdn", "$NewFQDNDomainName"
$MigTable = $MigTable -replace "DOMAIN_NETBIOS", "$NewShortDomainName"
$MigTable = $MigTable -replace "<Destination>Domain Controllers", "<Destination>$DCDomainGroup"
$MigTable = $MigTable -replace "<Destination>Domain Admins", "<Destination>$DomainAdminGroup"
$MigTable = $MigTable -replace "<Destination>Domain Users", "<Destination>$DomainUsersGroup"
$MigTable = $MigTable -replace "<Destination>Print Operators", "<Destination>$PrintOpGroup"
$MigTable = $MigTable -replace "<Destination>Group Policy Creator Owners", "<Destination>$GPOCreatorGroup"
$MigTable = $MigTable -replace "<Destination>Backup Operators", "<Destination>$BackupOpGroup"
$MigTable = $MigTable -replace "<Destination>Server Operators", "<Destination>$ServerOpGroup"
$MigTable = $MigTable -replace "<Destination>Account Operators", "<Destination>$AccountOpGroup"
$MigTable = $MigTable -replace "<Destination>Key Admins", "<Destination>$KeyAdminGroup"
$MigTable = $MigTable -replace "<Destination>Cryptograpic Operators", "<Destination>$CryptoOpGroup"
$MigTable = $MigTable -replace "<Destination>Administrator", "<Destination>$AdministratorUser"
Write-Verbose 'Updated migration table with current active directory group names'

# Remove Tier 2 groups from migration table if it does not exist
$DomainDistinguishedName = (Get-ADDomain).DistinguishedName
$EAP = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
$Tier2OU = Get-ADOrganizationalUnit -Identity "OU=Tier2,OU=$TierOUName,$DomainDistinguishedName" -Server $Server
$ErrorActionPreference = $EAP
if (!($Tier2OU)) {
  $rows = $MigTable -match "^    <Destination>Domain Tier2"
  foreach ($row in $rows) {
    $MigTable = $MigTable -replace "$row", "    <DestinationNone />"
  }
}

# Write new migration table
$MigTable | Set-Content -Path $Path\GPOBackup\UpdatedMigTable.migtable -Encoding UTF8

# Import GPOs with new migration table
$GPOs = Get-GPO -All
$GPOBackups = Get-ChildItem -Path $Path\GPOBackup -Directory
$CurrentGPOBackup = New-Item -Path $Path\Backup$(Get-Date -Format "yyyyMMdd_HHmm") -ItemType Directory
foreach ($GPO in $GPOs){
  if ($GPO.DisplayName -like "$GPOPrefix*") {
    $GPOBackupName = $GPO.DisplayName -replace $GPOPrefix, 'Admin'
  }
  else {
    $GPOBackupName = $GPO.DisplayName
  }
  $GPOBackup = $GPOBackups | Where-Object Name -eq $GPOBackupName
  if ($GPOBackup) {
    if ($GPO.User.DSVersion -ne 0 -or $GPO.Computer.DSVersion -ne 0) {
      $CurrentGPOBackupPath = New-Item -Path "$($CurrentGPOBackup.FullName)\$($GPO.DisplayName)" -ItemType Directory -ErrorAction Stop
      Backup-GPO -Guid $GPO.Id -Path $CurrentGPOBackupPath -Verbose:$VerbosePreference
      Write-Warning "Existing GPO ""$($GPO.DisplayName)"" has been modified after creation.`nThe GPO was overwritten but a backup of the old GPO was created in:`n""$CurrentGPOBackupPath"""
    }
    Import-GPO -Path $GPOBackup.fullname -BackupGpoName $GPOBackup.Name -MigrationTable $Path\GPOBackup\UpdatedMigTable.migtable -TargetName $GPO.DisplayName -ErrorAction SilentlyContinue -Verbose:$VerbosePreference
  }
}

# Replace group names in WindowsLAPS GPOs
$WindowsLAPSGPOs = $GPOs | Where-Object DisplayName -like '*WindowsLAPS*'

foreach ($WindowsLAPSGPO in $WindowsLAPSGPOs) {
  $LAPSGroup = (Get-GPRegistryValue -Name $WindowsLAPSGPO.DisplayName -Key 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\LAPS' -ValueName ADPasswordEncryptionPrincipal -ErrorAction SilentlyContinue -Server $Server).Value
  if ($LAPSGroup) {
    $LAPSGroupName = $LAPSGroup.Replace('AD\','')
    if ($OS.BuildNumber -lt 26100) {
      $LAPSGroupName = $LAPSGroupName -replace ".$"
    }
    $EAP = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    $LAPSGroupSID = (Get-ADGroup -Identity $LAPSGroupName -ErrorAction SilentlyContinue -Server $Server).SID.Value
    $ErrorActionPreference = $EAP
    if ($LAPSGroupSID) {
      Set-GPRegistryValue -Guid ($WindowsLAPSGPO.Id).Guid -Key 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\LAPS' -ValueName ADPasswordEncryptionPrincipal -Value $LAPSGroupSID -Type String -Server $Server | Out-Null
    }
    else {
      Write-Warning "Could not find group: $LAPSGroupName. Update GPO $($WindowsLAPSGPO.DisplayName) manually!" -Verbose
    }
  }
}

# Remove GPO Backup folder if empty
if ((Get-ChildItem -Path $CurrentGPOBackup -Recurse).Count -lt 1) {
  Remove-Item -Path $CurrentGPOBackup -Force
}
